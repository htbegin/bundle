#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <dirent.h>
#include <errno.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

static int l_dir(lua_State *L)
{
	DIR *dir = NULL;
	struct dirent *entry = NULL;
	int i = 0;
	const char *path = luaL_checkstring(L, 1);

	/* open directory */
	dir = opendir(path);
	if (dir == NULL)
	{
		lua_pushnil(L);
		lua_pushstring(L, strerror(errno));
		return 2; /* number of results */
	}

	/* create result table */
	lua_newtable(L);
	i = 1;

	while ((entry = readdir(dir)) != NULL)
	{
		/* push key */
		/*lua_pushnumber(L, i++);*/
		/* push value */
		/*lua_pushstring(L, entry->d_name);*/
		/*lua_settable(L, -3);*/

		lua_pushstring(L, entry->d_name);
		lua_rawseti(L, -2, i++);
	}

	closedir(dir);
	return 1;
}

static const struct luaL_Reg mylib[] =
{
	{"dir", l_dir},
	{NULL, NULL}, /* sentinel */
};

int luaopen_sunlib(lua_State *L)
{
	luaL_register(L, "sunlib", mylib);
	return 1;
}

