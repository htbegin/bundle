#!/usr/bin/env lua

local double_iterator

local function allwords (first, sec)
	local fstate = {fd = io.open(first, "r"), pos = 1}
	local sstate = {fd = io.open(sec, "r"), pos = 1}
	local state = {first = fstate, sec = sstate}

	return double_iterator, state
end

local function iterator (state)
	if not state.content then
		state.content = state.fd:read("*all")
	end

	while state.content do
		local s, e = string.find(state.content, "%w+", state.pos)
		if s then
			state.pos = e + 1
			return string.sub(state.content, s, e)
		else
			break
		end
	end
	return nil 						-- no more lines: end loop
end

function double_iterator (state)
	fword = iterator(state.first)
	sword = iterator(state.sec)

	if (fword == nil) and (sword == nil) then
		return nil, nil, nil
	else
		return true, fword, sword
	end
end

for noend, f, s in allwords("compare.lua", "allwords.lua") do
	print(f, s)
end
