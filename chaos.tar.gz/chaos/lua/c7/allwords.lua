#!/usr/bin/env lua

--[[
local iterator

function allwords ()
	local state = {line = io.read(), pos = 1}
	return iterator, state
end

function iterator (state)
	while state.line do				-- repeat while there are lines
		-- search for next word
		local s, e = string.find(state.line, "%w+", state.pos)
		if s then					-- found a word ?
			-- update next position (after the word)
			state.pos = e + 1
			return string.sub(state.line, s, e)
		else						-- word not found
			state.line = io.read()	-- try next line
			state.pos = 1			-- from first position
		end
	end
	return nil 						-- no more lines: end loop
end

for word in allwords() do
	print(word)
end
--]]

local function cur_value (t, idx)
	if t[idx] ~= nil then
		return t[idx]
	else
		return nil
	end
end

function values (t)
	return cur_value, t, 1
end

for val in values({10, 20, 30}) do
	print(val)
end
