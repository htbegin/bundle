#!/usr/bin/env lua

local Account = {balance = 0}

function Account:new (o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	return o
end

function Account:withdraw (v)
	if v > self.balance then
		error("insufficient funds")
	end
	self.balance = self.balance - v
end

function Account:deposit (v)
	self.balance = self.balance + v
end

SpecialAccount = Account:new()

function SpecialAccount:withdraw (v)
	if v - self.balance >= self:getLimit() then
		error("insufficient funds")
	end
	self.balance = self.balance - v
end

function SpecialAccount:getLimit ()
	return self.limit or 0
end

-- look up for 'k' in list of tables 'plist'
local function search (k, plist)
	for i=1, #plist do
		local v = plist[i][k]
		if v then return v end
	end
end

function createClass (...)
	local c = {}		 -- new class
	local parents = {...}

	-- class will search for each method in the list of its parents
	setmetatable(c, {__index = function (t, k) return search(k, parents) end})

	-- prepare 'c' to be the metatable of its instances
	c.__index = c

	-- define a new constructor for this new class
	function c:new (o)
		o = o or {}
		setmetatable(o, c)
		return o
	end

	return c
end

local Named = {}

function Named:getname ()
	return self.name
end

function Named:setname (n)
	self.name = n
end

function newAccount (initialBalance)
	-- the state table
	local self = {balance = initialBalance}

	local withdraw = function (v)
						self.balance = self.balance -v
					end

	local deposit = function (v)
						self.balance = self.balance + v
					end
	local getBalance = function () return self.balance end

	-- return the interface table
	return {
		withdraw = withdraw,
		deposit = deposit,
		getBalance = getBalance
	}
end

-- inheritance examples
a = Account:new()
print(a.balance)
a:deposit(100)
print(a.balance)

b = Account:new()
print(b.balance)
b:deposit(200)
print(b.balance)

print(a.balance)

s = SpecialAccount:new({limit=1000.00})
s:withdraw(100)
print(s.balance)

-- multiple inheritance examples
NamedAccout = createClass(Account, Named)
na = NamedAccout:new({name = "paul"})
print(na:getname())
na:deposit(10000)
print(na.balance)

function NamedAccout:getname ()
	return "nothing"
end

print(na:getname())

-- privacy
pa = newAccount(1000)
pa.withdraw(100)
pa.deposit(500)
print(pa.getBalance())
