#!/usr/bin/env lua

require("lproc")

lproc.start('lproc.send("s_one", 1);')
lproc.start('print(lproc.receive("s_one")); lproc.send("m_one", 2)')
print(lproc.receive("m_one"))
lproc.exit()
