#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

#define LXP_METATABLE_NAME "Expat"

typedef struct Proc
{
	lua_State *L;
	pthread_t thread;
	pthread_cond_t cond;
	const char *channel;
	struct Proc *prev;
	struct Proc *next;
}Proc;

static Proc *waitsend = NULL;
static Proc *waitreceive = NULL;
static pthread_mutex_t kernel_access = PTHREAD_MUTEX_INITIALIZER;

int luaopen_lproc(lua_State *L);

static Proc *searchmatch(const char *channel, Proc **list)
{
	Proc *node = *list;

	if (node == NULL)
	{
		return NULL;
	}

	do
	{
		if (strcmp(channel, node->channel) == 0)
		{
			/* this node is the first element */
			if (*list == node)
			{
				*list = (node->next == node) ? NULL : node->next;
			}
			node->prev->next = node->next;
			node->next->prev = node->prev;
			return node;
		}
		node = node->next;
	} while (node != *list);

	return NULL;
}

static Proc *getself(lua_State *L)
{
	Proc *p;

	lua_getfield(L, LUA_REGISTRYINDEX, "_SELF");
	p = (Proc *)lua_touserdata(L, -1);
	lua_pop(L, 1);
	return p;
}

static void movevalues(lua_State *send, lua_State *rec)
{
	int n = lua_gettop(send);
	int i;

	/* the first value is the channel */
	for (i = 2; i <= n; i++)
	{
		lua_pushstring(rec, lua_tostring(send, i));
	}
}

static void waitonlist(lua_State *L, const char *channel, Proc **list)
{
	Proc *p = getself(L);

	/* link itself at the end of the list */
	if (*list == NULL)
	{
		*list = p;
		p->prev = p->next = p;

	}
	else
	{
		p->prev = (*list)->prev;
		p->next = *list;
		p->prev->next = p->next->prev = p;
	}

	p->channel = channel;

	do
	{
		pthread_cond_wait(&p->cond, &kernel_access);
	} while (p->channel);
}

static int ll_send(lua_State *L)
{
	Proc *p;
	const char *channel = luaL_checkstring(L, 1);

	pthread_mutex_lock(&kernel_access);
	p = searchmatch(channel, &waitreceive);
	if (p)
	{
		movevalues(L, p->L);
		p->channel = NULL;
		pthread_cond_signal(&p->cond);
	}
	else
	{
		waitonlist(L, channel, &waitsend);
	}
	pthread_mutex_unlock(&kernel_access);

	return 0;
}

static int ll_receive(lua_State *L)
{
	Proc *p;
	const char *channel = luaL_checkstring(L, 1);
	lua_settop(L, 1);

	pthread_mutex_lock(&kernel_access);
	p = searchmatch(channel, &waitsend);
	if (p)
	{
		/* get values from sender */
		movevalues(p->L, L);
		p->channel = NULL;
		pthread_cond_signal(&p->cond);
	}
	else
	{
		waitonlist(L, channel, &waitreceive);
	}
	pthread_mutex_unlock(&kernel_access);

	/* return all stack values but channel */
	return lua_gettop(L) - 1;
}

static int ll_exit(lua_State *L)
{
	pthread_exit(NULL);
	return 0;
}

static void registerlib(lua_State *L, const char *name, lua_CFunction f)
{
	lua_getglobal(L, "package");
	/* get 'package.prepload' */
	lua_getfield(L, -1, "preload");
	lua_pushcfunction(L, f);
	/* package.preload[name] = f */
	lua_setfield(L, -2, name);
	/* pop 'package' and 'preload' tables */
	lua_pop(L, 2);
}

static void openlibs(lua_State *L)
{
	lua_cpcall(L, luaopen_base, NULL);
	lua_cpcall(L, luaopen_package, NULL);

	registerlib(L, "io", luaopen_io);
	registerlib(L, "os", luaopen_os);
	registerlib(L, "table", luaopen_table);
	registerlib(L, "string", luaopen_string);
	registerlib(L, "math", luaopen_math);
	registerlib(L, "debug", luaopen_debug);
}

static void *ll_thread(void *arg)
{
	lua_State *L = (lua_State *)arg;

	pthread_detach(pthread_self());

	/* use openlibs instead */
	/*luaL_openlibs(L);*/
	openlibs(L);

	/* open lproc library */
	lua_cpcall(L, luaopen_lproc, NULL);
	/* no argument, no result, no error handle */
	if (lua_pcall(L, 0, 0, 0) != 0)
	{
		fprintf(stderr, "thread error: %s\n", lua_tostring(L, -1));
	}
	pthread_cond_destroy(&getself(L)->cond);
	lua_close(L);

	return NULL;
}

static int ll_start(lua_State *L)
{
	pthread_t thread;
	const char *chunk = luaL_checkstring(L, 1);
	lua_State *L1 = luaL_newstate();

	if (L1 == NULL)
	{
		luaL_error(L, "unable to create new state\n");
	}

	if (luaL_loadstring(L1, chunk) != 0)
	{
		luaL_error(L, "error starting thread: %s\n", lua_tostring(L1, -1));
	}

	if (pthread_create(&thread, NULL, ll_thread, L1) != 0)
	{
		luaL_error(L, "unable to create new thread\n");
	}

	return 0;
}

static const struct luaL_Reg ll_funcs[] =
{
	{"start", ll_start},
	{"send", ll_send},
	{"receive", ll_receive},
	{"exit", ll_exit},
	{NULL, NULL},
};

int luaopen_lproc(lua_State *L)
{
	/* create own control block */
	Proc *self = (Proc *)lua_newuserdata(L, sizeof(Proc));

	lua_setfield(L, LUA_REGISTRYINDEX, "_SELF");
	self->L = L;
	self->thread = pthread_self();
	self->channel = NULL;
	pthread_cond_init(&self->cond, NULL);

	luaL_register(L, "lproc", ll_funcs);

	return 1;
}

