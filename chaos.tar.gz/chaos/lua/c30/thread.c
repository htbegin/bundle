#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

static void test_foo(lua_State *L)
{
	int ret;

	lua_getglobal(L, "foo1");
	lua_pushinteger(L, 20);
	ret = lua_resume(L, 1);
	printf("resume return %d\n", ret);

	printf("%d\n", lua_gettop(L));
	printf("%d\n", lua_tointeger(L, 1));
	printf("%d\n", lua_tointeger(L, 2));

	ret = lua_resume(L, 0);
	printf("resume return %d\n", ret);
	printf("%d\n", lua_gettop(L));
	printf("%d\n", lua_tointeger(L, 1));
}

static void test_bar(lua_State *L)
{
	int ret;

	lua_getglobal(L, "bar");
	lua_pushinteger(L, 30);
	ret = lua_resume(L, 1);
	printf("resume bar return %d\n", ret);

	printf("%d\n", lua_gettop(L));
	printf("%d\n", lua_tointeger(L, 1));
	printf("%d\n", lua_tointeger(L, 2));

	lua_pushinteger(L, 20);
	ret = lua_resume(L, 0);
	printf("resume bar return %d\n", ret);

	printf("%d\n", lua_gettop(L));
}

static void load(lua_State *L, const char *fname)
{
	if (luaL_loadfile(L, fname) || lua_pcall(L, 0, 0, 0))
	{
		luaL_error(L, "cannot run config. file: %s\n", lua_tostring(L, -1));
	}
}

int main(int argc, char **argv)
{
	if (argc == 2)
	{
		lua_State *L = luaL_newstate();
		lua_State *L1 = lua_newthread(L);

		printf("%d\n", lua_gettop(L1));
		printf("%d\n", lua_gettop(L));
		printf("%s\n", luaL_typename(L, -1));

		luaL_openlibs(L);

		load(L, argv[1]);

		test_foo(L1);

		test_bar(L1);

		lua_close(L);
	}
	else
	{
		printf("usage: %s script\n", argv[0]);
		exit(1);
	}

	return 0;
}
