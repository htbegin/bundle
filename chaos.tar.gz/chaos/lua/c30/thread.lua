#!/usr/bin/env lua

function foo (x) coroutine.yield(10, x) end
function foo1 (x) foo(x + 1); return 3 end

function bar (x) print("lua: ", coroutine.yield(10, x)) end
