#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

#define BITS_PER_WORD (CHAR_BIT * sizeof(unsigned int))
#define I_WORD(i)     ((unsigned int)(i) / BITS_PER_WORD)
#define I_BIT(i)      (1 << ((unsigned int)(i) % BITS_PER_WORD))

#define BARRAY_METATABLE_NAME "LuaBook.barray"

#define checkarray(L) (NumArray *)luaL_checkudata(L, 1, BARRAY_METATABLE_NAME)

typedef struct NumArray
{
	int size;
	/* variable part */
	unsigned int values[1];
}NumArray;

static int newarray(lua_State *L)
{
	int i;
	int n;
	size_t nbytes;
	NumArray *a;

	n = luaL_checkint(L, 1);
	luaL_argcheck(L, n >= 1, 1, "invalid size");
	nbytes = sizeof(NumArray) + I_WORD(n - 1) * sizeof(unsigned int);

	a = (NumArray *)lua_newuserdata(L, nbytes);
	a->size = n;
	for (i = 0; i <= I_WORD(n - 1); i++)
	{
		a->values[i] = 0;
	}

	luaL_getmetatable(L, BARRAY_METATABLE_NAME);
	/* the stack position of the new userdatum is -2 */
	lua_setmetatable(L, -2);

	return 1;
}

static unsigned int *getindex(lua_State *L, unsigned int *mask)
{
	NumArray *a = checkarray(L);
	int index = luaL_checkint(L, 2) - 1;

	luaL_argcheck(L, 0 <= index && index < a->size, 2, "index out of range");

	*mask = I_BIT(index);
	return &a->values[I_WORD(index)];
}

static int setarray(lua_State *L)
{
	unsigned int mask = 0;
	unsigned int *entry = getindex(L, &mask);

	luaL_checkany(L, 3);

	if (lua_toboolean(L, 3))
	{
		*entry |= mask;
	}
	else
	{
		*entry &= ~mask;
	}

	return 0;
}

static int getarray(lua_State *L)
{
	unsigned int mask = 0;
	unsigned int *entry = getindex(L, &mask);

	lua_pushboolean(L, *entry & mask);

	return 1;
}

static int getsize(lua_State *L)
{
	NumArray *a = checkarray(L);
	lua_pushinteger(L, a->size);
	return 1;
}

static int barray2string(lua_State *L)
{
	NumArray *a = checkarray(L);
	lua_pushfstring(L, "array(%d)", a->size);
	return 1;
}

static const struct luaL_Reg barraylib_f[] =
{
	{"new", newarray},
	{NULL, NULL}, /* sentinel */
};

static const struct luaL_Reg barraylib_m[] =
{
	{"set", setarray},
	{"get", getarray},
	{"size", getsize},
	{"__tostring", barray2string},
	{NULL, NULL}, /* sentinel */
};

int luaopen_barray(lua_State *L)
{
	luaL_newmetatable(L, BARRAY_METATABLE_NAME);

	/* metatable.__index = metatable */
	lua_pushvalue(L, -1); /* duplicate the metatable */
	lua_setfield(L, -2, "__index");

	luaL_register(L, NULL, barraylib_m);

	luaL_register(L, "barray", barraylib_f);

	return 1;
}

