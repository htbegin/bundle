#!/usr/bin/env lua

require("barray")

a = barray.new(1000)
for i=1,a:size() do
	a:set(i, i%5 == 0)
end
print(a:get(10))
print(a)
