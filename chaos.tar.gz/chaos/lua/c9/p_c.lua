#!/usr/bin/env lua

function receive ()
	local status, value = coroutine.resume(producer)
	return value
end

function consumer ()
	while true do
		local x = receive()
		if x then
			io.write(x, "\n")
		else
			break
		end
	end
end

function send(x)
	coroutine.yield(x)
end

producer = coroutine.create(
	function ()
		while true do
			local x = io.read()
			send(x)
			if not x then
				break
			end
		end
	end)

consumer()
