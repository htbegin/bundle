#!/usr/bin/env lua

function receive (prod)
	local status, value = coroutine.resume(prod)
	return status and value
end

function send(x)
	coroutine.yield(x)
end

function consumer (prod)
	while true do
		local x = receive(prod)
		if x then
			io.write(x, "\n")
		else
			break
		end
	end
end

function producer ()
	return coroutine.create(function ()
		while true do
			local x = io.read()
			send(x)
			if not x then
				break
			end
		end
	end)
end

function filter (prod)
	return coroutine.create(function ()
		for line = 1, math.huge do
			local x = receive(prod)
			if x then
				x = string.format("%d %s", line, x)
				send(x)
			else
				break
			end
		end
	end)
end

consumer(filter(producer()))
