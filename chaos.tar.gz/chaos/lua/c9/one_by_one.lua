#!/usr/bin/env lua

require("socket")

function receive (connection)
	return connection:receive(2^10)
end

function download (host, file)
	local c = assert(socket.connect(host, 80))
	local count = 0
	c:send("GET " .. file .. " HTTP/1.0\r\n\r\n")
	while true do
		local s, status, partial = receive(c)
		count = count + #(s or partial)
		if status == "closed" then
			break
		end
	end
	c:close()
	print(file, count)
end

host = "www.w3.org"
files = {"/TR/html401/html40.txt", "/TR/2002/REC-xhtml1-20020801/xhtml1.pdf", "/TR/REC-html32.html", "/TR/2000/REC-DOM-Level-2-Core-20001113/DOM2-Core.txt"}
for index,file in ipairs(files) do
	download(host, file)
end
