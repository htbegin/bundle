#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <errno.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

static int l_map(lua_State *L)
{
	int i;
	int n;

	/* 1st argument must be a table (t) */
	luaL_checktype(L, 1, LUA_TTABLE);

	/* 2nd argument must be a function (f) */
	luaL_checktype(L, 2, LUA_TFUNCTION);

	/* get size of table */
	n = lua_objlen(L, 1);

	for (i = 1; i <= n; i++)
	{
		/* push f */
		lua_pushvalue(L, 2);
		/* push t[i] */
		lua_rawgeti(L, 1, i);
		/* call f(t[i]): 1 argument, 1 result */
		lua_call(L, 1, 1);
		/* ti[i] = result */
		lua_rawseti(L, 1, i);
	}

	/* no results */
	return 0;
}

static int l_split(lua_State *L)
{
	const char *s = luaL_checkstring(L, 1);
	const char *seq = luaL_checkstring(L, 2);
	const char *e;
	int i;

	lua_newtable(L);

	i = 1;
	/* repeat for each separator */
	while ((e = strchr(s, *seq)) != NULL)
	{
		/* push substring */
		lua_pushlstring(L, s, e - s);
		lua_rawseti(L, -2, i++);
		s = e + 1;
	}

	/* push last substring */
	lua_pushstring(L, s);
	lua_rawseti(L, -2, i);

	/* return the table */
	return 1;
}

static int l_upper(lua_State *L)
{
	size_t len;
	size_t i;
	luaL_Buffer b;
	const char *s = luaL_checklstring(L, 1, &len);

	luaL_buffinit(L, &b);
	for (i = 0; i < len; i++)
	{
		luaL_addchar(&b, toupper((unsigned char)(s[i])));
	}
	luaL_pushresult(&b);
	return 1;
}

static int l_counter(lua_State *L)
{
	int val = lua_tointeger(L, lua_upvalueindex(1));

	/* new value */
	lua_pushinteger(L, ++val);
	/* duplicate it */
	lua_pushvalue(L, -1);
	/* update upvalue */
	lua_replace(L, lua_upvalueindex(1));

	return 1;
}

static int l_newCounter(lua_State *L)
{
	lua_pushinteger(L, 0);
	/* the number of upvalues: 1*/
	lua_pushcclosure(L, &l_counter, 1);
	return 1;
}

static const struct luaL_Reg morelib[] =
{
	{"map", l_map},
	{"split", l_split},
	{"new_upper", l_upper},
	{"newCounter", l_newCounter},
	{NULL, NULL}, /* sentinel */
};

int luaopen_more(lua_State *L)
{
	luaL_register(L, "more", morelib);
	return 1;
}

