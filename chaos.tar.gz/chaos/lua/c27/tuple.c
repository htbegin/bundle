#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <errno.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

static int t_tuple(lua_State *L)
{
	/* the 1th argument, if it's absent or nil, return 0 */
	int op = luaL_optint(L, 1, 0);

	/* no arguments */
	if (op == 0)
	{
		int i;

		/* push each valid upvalue onto the stack */
		for (i = 1; !lua_isnone(L, lua_upvalueindex(i)); i++)
		{
			lua_pushvalue(L, lua_upvalueindex(i));
		}

		/* number of values in the stack */
		return i - 1;
	}
	else
	{
		/* the checked argument is the first argument */
		luaL_argcheck(L, 0 < op, 1, "index out of range");
		if (lua_isnone(L, lua_upvalueindex(op)))
		{
			/* no such field */
			return 0;
		}
		lua_pushvalue(L, lua_upvalueindex(op));
		return 1;
	}
}

static int t_new(lua_State *L)
{
	/* the number of upvalues: the arguments count pass to t_new */
	lua_pushcclosure(L, t_tuple, lua_gettop(L));
	return 1;
}

static const struct luaL_Reg tuplelib[] =
{
	{"new", t_new},
	{NULL, NULL}, /* sentinel */
};

int luaopen_tuple(lua_State *L)
{
	luaL_register(L, "tuple", tuplelib);
	return 1;
}

