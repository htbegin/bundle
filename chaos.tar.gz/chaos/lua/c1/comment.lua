#!/usr/bin/env lua

--[=[
print(false)
print(2.4)
--[[
print(10)
print("a")
print(nil)
--]]
print(true)
-- print({})
print(function () return 1 end)
--]=]
print(coroutine.create(function () return 2 end))
