#!/usr/bin/env lua

local i = 0
local cnt = 4

while arg[i] ~= nil do
	print(arg[i])
	i = i + 1
end
print(...)
