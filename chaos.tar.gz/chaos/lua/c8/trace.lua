#!/usr/bin/env lua

function foo (str)
	if type(str) ~= "string" then
		error("string expected")
	end
	print(str)
end

function test ()
	foo({x=1})
end

--test()

---[[
local ok, err = xpcall(test, debug.traceback)
if not ok then
	print(err)
end
---]]

print("end")
