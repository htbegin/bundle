-- define window size
width = 200
height = 300

background = MAGENTA
