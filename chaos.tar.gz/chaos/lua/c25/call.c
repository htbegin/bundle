#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

static void error(lua_State *L, const char *fmt, ...)
{
	va_list argp;

	va_start(argp, fmt);
	vfprintf(stderr, fmt, argp);
	va_end(argp);

	lua_close(L);
	exit(EXIT_FAILURE);
}

static double f(lua_State *L, double x, double y)
{
	double z;

	/* push functions and arguments */
	lua_getglobal(L, "f");
	lua_pushnumber(L, x);
	lua_pushnumber(L, y);

	/* do the call (2 arguments, 1 result, no error handle) */
	if (lua_pcall(L, 2, 1, 0) != 0)
	{
		error(L, "error running function 'f': %s", lua_tostring(L, -1));
	}

	/* retrieve result */
	if (!lua_isnumber(L, -1))
	{
		error(L, "function 'f' must return a number\n");
	}

	z = lua_tonumber(L, -1);
	/* pop returned value */
	lua_pop(L, 1);

	return z;
}

static void call_va(lua_State *L, const char *func, const char *sig, ...)
{
	va_list vl;
	int narg = 0;
	int nres = 0;

	va_start(vl, sig);

	lua_getglobal(L, func);

	for (narg = 0; *sig; narg++)
	{
		/* check stack space */
		/* Grows the stack size to "top + sz" elements, raising an error if the stack cannot grow to that size. */
		luaL_checkstack(L, 1, "too many arguments");

		/* first "++", then "*" */
		switch (*sig++)
		{
			case 'd':
			{
				lua_pushnumber(L, va_arg(vl, double));
				break;
			}
			case 'i':
			{
				lua_pushinteger(L, va_arg(vl, int));
				break;
			}
			case 's':
			{
				lua_pushstring(L, va_arg(vl, char *));
				break;
			}
			case '>':
			{
				goto endargs;
			}
			default:
			{
				error(L, "invalid option (%c)\n", *(sig - 1));
				break;
			}
		}
	}

endargs:
	nres = strlen(sig);

	if (lua_pcall(L, narg, nres, 0) != 0)
	{
		error(L, "error calling '%s': %s\n", func, lua_tostring(L, -1));
	}

	/* stack index of first result */
	nres = -nres;

	while (*sig)
	{
		switch (*sig++)
		{
			case 'd':
			{
				if (!lua_isnumber(L, nres))
				{
					error(L, "wrong result type\n");
				}
				*va_arg(vl, double *) = lua_tonumber(L, nres);
				break;
			}
			case 'i':
			{
				if (!lua_isnumber(L, nres))
				{
					error(L, "wrong result type\n");
				}
				*va_arg(vl, int *) = lua_tointeger(L, nres);
				break;
			}
			case 's':
			{
				if (!lua_isstring(L, nres))
				{
					error(L, "wrong result type\n");
				}
				*va_arg(vl, const char **) = lua_tostring(L, nres);
				break;
			}
			default:
			{
				error(L, "invalid option (%c)\n", *(sig - 1));
				break;
			}
		}
		nres++;
	}

	va_end(vl);

	return;
}

static void load(lua_State *L, const char *fname)
{
	if (luaL_loadfile(L, fname) || lua_pcall(L, 0, 0, 0))
	{
		error(L, "cannot run config. file: %s\n", lua_tostring(L, -1));
	}
}

int main (int argc, char **argv)
{
	if (argc == 2)
	{
		lua_State *L = luaL_newstate();
		double double_ret;

		luaL_openlibs(L);
		load(L, argv[1]);

		/*printf("%.3f\n", f(L, 3.0, 4.0));*/
		call_va(L, "f", "dd>d", 3.0, 4.0, &double_ret);
		/* pop the return value */
		lua_pop(L, 1);
		printf("%.3f\n", double_ret);

		lua_close(L);
	}
	else
	{
		printf("usage: %s script\n", argv[0]);
		exit(1);
	}

	return 0;
}
