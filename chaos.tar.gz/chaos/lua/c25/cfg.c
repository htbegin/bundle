#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

#define MAX_COLOR 255

struct ColorTable
{
	char *name;
	unsigned char red;
	unsigned char green;
	unsigned char blue;
};

struct ColorTable colortable[] =
{
	{"WHITE", MAX_COLOR, MAX_COLOR, MAX_COLOR},
	{"RED", MAX_COLOR, 0, 0},
	{"GREEN", 0, MAX_COLOR, 0},
	{"BLUE", 0, 0, MAX_COLOR},
	{"BLACK", 0, 0, 0},
	{NULL, 0, 0, 0}, /* sentinel */
};

static void error(lua_State *L, const char *fmt, ...)
{
	va_list argp;

	va_start(argp, fmt);
	vfprintf(stderr, fmt, argp);
	va_end(argp);

	lua_close(L);
	exit(EXIT_FAILURE);
}

/* assume that table is at the top */
static int getfield(lua_State *L, const char *key)
{
	int result;

	/* get background[key] */
	/* lua_pushstring(L, key); */
	/* lua_gettable(L, -2); */

	lua_getfield(L, -1, key);
	if (!lua_isnumber(L, -1))
	{
		error(L, "invalid component in background color\n");
	}

	result = (int)(lua_tonumber(L, -1) * MAX_COLOR);

	lua_pop(L, 1); /* remove number */

	return result;
}

/* assume that table is at the top */
static void setfield(lua_State *L, const char *index, int value)
{
	/*lua_pushstring(L, index);*/
	/*lua_pushnumber(L, (double)(value/MAX_COLOR));*/
	/*lua_settable(L, -3);*/

	lua_pushnumber(L, (double)(value/MAX_COLOR));
	lua_setfield(L, -2, index);
}

static void load(lua_State *L, const char *fname, int *w, int *h)
{
	int red = 0;
	int green = 0;
	int blue = 0;

	if (luaL_loadfile(L, fname) || lua_pcall(L, 0, 0, 0))
	{
		error(L, "cannot run config. file: %s\n", lua_tostring(L, -1));
	}

	lua_getglobal(L, "width");
	lua_getglobal(L, "height");

	if (!lua_isnumber(L, -2))
	{
		error(L, "'width' should be a number\n");
	}
	if (!lua_isnumber(L, -1))
	{
		error(L, "'height' should be a number\n");
	}

	*w = lua_tointeger(L, -2);
	*h = lua_tointeger(L, -1);

	/* push the "background" to the stack */
	lua_getglobal(L, "background");
	if (!lua_istable(L, -1))
	{
		error(L, "'background' is not a table\n");
	}

	red = getfield(L, "r");
	green = getfield(L, "g");
	blue = getfield(L, "b");

	printf("r %d g %d b %d\n", red, green, blue);
}

static void setcolor(lua_State *L, struct ColorTable *ct)
{
	lua_newtable(L);
	setfield(L, "r", ct->red);
	setfield(L, "g", ct->green);
	setfield(L, "b", ct->blue);
	lua_setglobal(L, ct->name);
}

static void definecolors(lua_State *L)
{
	int i = 0;

	while (colortable[i].name != NULL)
	{
		setcolor(L, &colortable[i++]);
	}
}

int main (int argc, char **argv)
{
	if (argc == 2)
	{
		lua_State *L = luaL_newstate();
		int w = 0;
		int h = 0;

		definecolors(L);

		/*luaL_openlibs(L);*/
		load(L, argv[1], &w, &h);
		printf("width: %d, height: %d\n", w, h);
		lua_close(L);
	}
	else
	{
		printf("usage: %s cfg\n", argv[0]);
		exit(1);
	}

	return 0;
}
