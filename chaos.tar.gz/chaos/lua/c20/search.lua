#!/usr/bin/env lua

function search (modname, path)
	modname = string.gsub(modname, "%.", "/")
	for c in string.gmatch(path, "[^;]+") do
		local fname = string.gsub(c, "?", modname)
		local f = io.open(fname)

		if f then
			f:close()
			return fname
		end
	end
	return nil -- not found
end

function toxml (s)
	s = string.gsub(s, "\\(%a+)(%b{})", function (tag, body)
					body = string.sub(body, 2, -2)
					body = toxml(body)
					return string.format("<%s>%s</%s>", tag, body, tag)
				end)
	return s
end

print(toxml("\\title{The \\bold{big} problem}"))

function escape (s)
	s = string.gsub(s, "[&=+%%%c]", function (c)
			return string.format("%%%02X", string.byte(c))
		end)
	s = string.gsub(s, " ", "+")
	return s
end

function unescape (s)
	s = string.gsub(s, "+", " ")
	s = string.gsub(s, "%%(%x%x)", function (h)
			return string.char(tonumber(h, 16))
		end)
	return s
end

function encode (t)
	local b = {}
	for k,v in pairs(t) do
		b[#b + 1] = (escape(k) .. "=" .. escape(v))
	end
	return table.concat(b, "&")
end

function decode (s)
	local k, v
	local b = {}
	for k, v in string.gmatch(s, "([^=&]+)=([^=&]+)") do
		k = unescape(k)
		v = unescape(v)
		b[k] = v
	end
	return b
end

t = {name = "al", query = "a+b = c", q = "yes or no"}
s = encode(t)
print(s)
dt = decode(s)
for k,v in pairs(dt) do
	print(k, v)
end

function expandTabs (s, tab)
	tab = tab or 8
	local corr = 0
	s = string.gsub(s, "()\t", function (p)
			-- print(p)
			local sp = tab - (p - 1 + corr)%tab
			corr = corr - 1 + sp
			return string.rep(" ", sp)
		end)
	return s
end

print(expandTabs("\tABC\tabc"))

function unexpandTabs (s, tab)
	tab = tab or 8
	s = expandTabs(s)
	local pat = string.rep(".", tab)
	s = string.gsub(s, pat, "%0\1")
	s = string.gsub(s, " +\1", "\t")
	s = string.gsub(s, "\1", "")
	return s
end

function code (s)
	return (string.gsub(s, "\\(.)", function (x)
		return string.format("\\%03d", string.byte(x))
	end))
end

function decode (s)
	return (string.gsub(s, "\\(%d%d%d)", function (d)
		return "\\" .. string.char(d)
	end))
end

s = [[follows a\1typical string: "This is \"greater\"!".]]

print(decode(string.gsub(code(s), '".-"', string.upper)))
