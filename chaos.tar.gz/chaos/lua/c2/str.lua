#!/usr/bin/env lua

f_str =  "alo\n123\""
s_str = '\97lo\10\04923"'
-- t_str = '\97lo\10\4923"'

-- the first newline is ignored, the last newline isn't.
long_str = [[
\a\b\f\n\r\t\v\\\"\'\255
]]

print(f_str == s_str)
print(#f_str)
print(long_str)
print(#long_str)
