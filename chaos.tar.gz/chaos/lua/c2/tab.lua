#!/usr/bin/env lua

-- constructor expression
a = {}
k = "x"

a[k] = 10
a[20] = "great"
print(a["x"])

k = 20
print(a[k])
a["x"] = a["x"] + 1
-- a.name as syntactic sugar for a["name"], but it seems that name should be a valid identity
print(a.x)

-- getn or the length operator # only work for an array or list
print("len:", table.getn(a))

b = {}
x = "y"
b[x] = 10
print(b[x])
print(b.y)
print(b.x)

a = {}
for i=1,10 do
	a[#a + 1] = i
end
