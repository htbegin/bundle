entry{
	title = "Tecgraf",
	org = "Computer Graphics Technology Group, PUC-Rio",
	url = "http://www.tecgraf.puc-rio.br/",
	contact = "Waldemar Celes",
	description = [[
	Tecgraf is the result of a partnership between PUC-Rio,
	the Pontifical Catholic University of Rio de Janeiro,
	and <a HREF="http://www.petrobras.com.br/">PETROBRAS</a>,
	the Brazilian Oil Company.
	Tecgraf is Lua’s birthplace,
	and the language has been used there since 1993.
	Currently, more than thirty programmers in Tecgraf use
	Lua regularly; they have written more than two hundred
	thousand lines of code, distributed among dozens of
	final products.]]
}

