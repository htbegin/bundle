#!/usr/bin/env lua

require("dir")

for fname in dir(".") do
	print(fname)
end

-- require("lxp")
require("ref_lxp")
lxp = ref_lxp

local count = 0
callbacks = {
	StartElement = function (parser, tagname)
		io.write("+ ", string.rep("  ", count), tagname, "\n")
		count = count + 1
	end,

	EndElement = function(parser, tagname)
		count = count - 1
		io.write("- ", string.rep("  ", count), tagname, "\n")
	end
}

p = lxp.new(callbacks)
assert(p:parse("<to> <yes/> </to>"))
assert(p:parse())
p:close()

