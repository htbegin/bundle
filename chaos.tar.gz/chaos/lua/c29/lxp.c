#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>

#include <expat.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

#define LXP_METATABLE_NAME "Expat"

/* "LXP" stands for "Lua XML Parser" */
typedef struct lxp_userdata
{
	lua_State *L;
	XML_Parser parser;
}lxp_userdata;

static void f_CharData(void *ud, const char *s, int len)
{
	lxp_userdata *xpu = (lxp_userdata *)ud;
	lua_State *L = xpu->L;

	lua_getfield(L, 3, "CharacterData");
	/* no handler */
	if (lua_isnil(L, -1))
	{
		lua_pop(L, 1);
		return;
	}

	/* push the parser ('self') */
	lua_pushvalue(L, 1);
	lua_pushlstring(L, s, len);
	/* 2 args, no result */
	lua_call(L, 2, 0);
}

static void f_EndElement(void *ud, const char *name)
{
	lxp_userdata *xpu = (lxp_userdata *)ud;
	lua_State *L = xpu->L;

	lua_getfield(L, 3, "EndElement");
	/* no handler */
	if (lua_isnil(L, -1))
	{
		lua_pop(L, 1);
		return;
	}

	/* push the parser ('self') */
	lua_pushvalue(L, 1);
	lua_pushstring(L, name);
	/* 2 args, no result */
	lua_call(L, 2, 0);
}

static void f_StartElement(void *ud, const char *name, const char **atts)
{
	lxp_userdata *xpu = (lxp_userdata *)ud;
	lua_State *L = xpu->L;

	lua_getfield(L, 3, "StartElement");
	/* no handler */
	if (lua_isnil(L, -1))
	{
		lua_pop(L, 1);
		return;
	}

	/* push the parser ('self') */
	lua_pushvalue(L, 1);
	lua_pushstring(L, name);

	/* create and file the attribute table */
	lua_newtable(L);
	for (; *atts; atts += 2)
	{
		/* table[*atts] = *(atts+1) */
		lua_pushstring(L, *(atts + 1));
		lua_setfield(L, -2, *atts);
	}

	/* 3 args, no result */
	lua_call(L, 3, 0);
}

static int lxp_close(lua_State *L)
{
	lxp_userdata *xpu = (lxp_userdata *)luaL_checkudata(L, 1, LXP_METATABLE_NAME);

	/* free Expat parser (if there is one) */
	if (xpu->parser)
	{
		XML_ParserFree(xpu->parser);
	}
	xpu->parser = NULL;
	return 0;
}

static int lxp_parse(lua_State *L)
{
	int status;
	size_t len;
	const char *s;
	lxp_userdata *xpu;

	xpu = (lxp_userdata *)luaL_checkudata(L, 1, LXP_METATABLE_NAME);

	/* get second argument (a string) */
	s = luaL_optlstring(L, 2, NULL, &len);

	/* prepare environment for handlers: */
	/* put callback table at stack index 3 */
	lua_settop(L, 2); /* fill nil if no second argument */
	lua_getfenv(L, 1);
	xpu->L = L;

	status = XML_Parse(xpu->parser, s, (int)len, s == NULL);

	lua_pushboolean(L, status);

	return 1;
}

static int lxp_make_parser(lua_State *L)
{
	XML_Parser p;
	lxp_userdata *xpu;

	/* create a parser object */
	xpu = (lxp_userdata *)lua_newuserdata(L, sizeof(*xpu));

	xpu->parser = NULL;

	/* set its metatable */
	luaL_getmetatable(L, LXP_METATABLE_NAME);
	lua_setmetatable(L, -2);

	p = xpu->parser = XML_ParserCreate(NULL);
	if (!p)
	{
		luaL_error(L, "XML_ParserCreate failed");
	}

	luaL_checktype(L, 1, LUA_TTABLE);
	/* put the table on the stack top */
	lua_pushvalue(L, 1);
	/* set it as the environment for udata */
	lua_setfenv(L, -2);

	XML_SetUserData(p, xpu);
	XML_SetElementHandler(p, f_StartElement, f_EndElement);
	XML_SetCharacterDataHandler(p, f_CharData);

	return 1;
}

static const struct luaL_Reg lxp_meths[] =
{
	{"parse", lxp_parse},
	{"close", lxp_close},
	{"__gc", lxp_close},
	{NULL, NULL},
};

static const struct luaL_Reg lxp_funcs[] =
{
	{"new", lxp_make_parser},
	{NULL, NULL},
};

int luaopen_lxp(lua_State *L)
{
	luaL_newmetatable(L, LXP_METATABLE_NAME);

	/* metatable.__index = metatable */
	lua_pushvalue(L, -1);
	lua_setfield(L, -2, "__index");

	/* register methods */
	luaL_register(L, NULL, lxp_meths);

	/* register functions */
	luaL_register(L, "lxp", lxp_funcs);

	return 1;
}
