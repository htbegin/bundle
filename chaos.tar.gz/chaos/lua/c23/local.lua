#!/usr/bin/env lua

function foo (a, b)
	local x
	-- c is already out of scope when getlocal is called
	do local c = a - b end
	local a = 1
	while true do
		--[[
		when getlocal is called, name and value are not yet in scope.
		because the local variables are only visible after their initialization code
		--]]
		local name, value = debug.getlocal(1, a)
		if not name then break end
		print(name, value)
		a = a + 1
	end
end

foo(10, 20)
