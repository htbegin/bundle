#!/usr/bin/env lua

co = coroutine.create(function ()
	local x = 10
	coroutine.yield()
	error("some error")
	end)

coroutine.resume(co)
print(debug.traceback(co))
print(coroutine.resume(co))
-- the coroutine doesn't unwind its stack when it raises an error
print(debug.traceback(co))
-- what does the level one stands for ? the coroutine itself
print(debug.getlocal(co, 1, 1))
-- what does the level two stands for ? nothing
-- print(debug.getlocal(co, 2, 1))

-- does coroutine has upvalues ? no

--[[
function up_co ()
	local m = 10
	local co
	co = coroutine.create(function ()
		local x = 10
		coroutine.yield()
		error("some error")
		end)
	return co
end

co = up_co()
coroutine.resume(co)
print(debug.traceback(co))
print(coroutine.resume(co))
print(debug.traceback(co))
print(debug.getlocal(co, 1, 1))
print(debug.getupvalue(co, 1))
--]]
