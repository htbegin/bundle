#!/usr/bin/env lua

require("List")

list = List.new()
List.pushfirst(list, 3)
List.pushfirst(list, 2)
List.pushfirst(list, 1)

print(List.popfirst(list), List.popfirst(list), List.popfirst(list))
