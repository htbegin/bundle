#!/usr/bin/env lua

local key = {} -- unique key
local mt = {__index = function (t) return t[key] end}
function setDefault (t, d)
	t[key] = d
	setmetatable(t, mt)
end

tab = {x=10, y=20}
print(tab.x, tab.z)
setDefault(tab, 0)
print(tab.x, tab.z)

sec_tab = {m=10, n=20}
setDefault(sec_tab, 100)
print(sec_tab.z)

