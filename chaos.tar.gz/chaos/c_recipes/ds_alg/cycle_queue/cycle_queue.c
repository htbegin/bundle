// set a flag to indicate whether or not 
// the queue is empty or full
// flag=0:empty,else full
#define MAX 100
static int x[MAX];
#ifdef _METHOD_1
static int flag;
#endif

int init( )
{
#ifdef _METHOD_1
	rindex=windex=0;
	flag=0;
#endif
#ifdef _METHOD_2
	// think when (rindex+1)%MAX == windex ,the queue is empty
	// when windex==rindex,the queue is full
	rindex=0;windex=1;
#endif
#ifdef _METHOD_3
	// when rindex==windex,the queue is empty
	// when (windex+1)%MAX==rindex,the queue is full
	rindex=0,windex=0;
#endif
}

int write(int value)
{
	int rval=-1;
#ifdef _METHOD_1
	if(windex!=rindex || flag==0)
	{
		x[windex]=value;
		windex=(windex+1)%MAX;
		if(windex==rindex) flag=1;
		rval=0;
	}
#endif	
#ifdef _METHOD_2
	if(windex!=rindex)
	{
		x[windex]=value;
		windex=(windex+1)%MAX;
		rval=0;
	}
#endif
#ifdef _METHOD_3
	if( (windex+1)%MAX != rindex )
	{
		x[windex]=value;
		windex=(windex+1)%MAX;
		rval=0;
	}	
#endif
}

int read(int * value_ptr)
{
	int rval=-1;
#ifdef _METHOD_1
	if(rindex!=windex || flag==1)
	{
		*value_ptr=x[rindex];
		rindex=(rindex+1)%MAX;
		if(rindex==windex) flag=0;
		rval=0;
	}
#endif	
#ifdef _METHOD_2
	int tmp=(rindex+1)%MAX;
	if( tmp != windex)
	{
		*value_ptr=x[tmp];
		rindex=tmp;
		rval=0;
	}
#endif
#ifdef _METHOD_3
	if(rindex!=windex)
	{
		*value_ptr=x[rindex];
		rindex=(rindex+1)%MAX;
		rval=0;
	}
#endif
}
