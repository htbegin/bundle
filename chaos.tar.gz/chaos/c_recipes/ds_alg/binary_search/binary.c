/*
Description:
   try to find a target value in a sorted vector
   return the index of the element in the vector which
   is the first element greater or equals with the target
   if the target value is greater than all elements in the 
   vector,then -1 should be returned
   */
/* 
   but how to prove it's correct?
   the Loop Invariant?
   the Beautiful Test?
*/
int lower_bound(int * vector,int len,int target)
{
	int mid=0,low=0,high=len;

	// no need for low == high
	// because when high=mid, position high has been matched
	// if let low=high,then mid=high,but high has been matched before
	while(low<high)
	{
		mid=low+(high-low)/2;
		if(vector[mid]<target) low=mid+1;
		else high=mid;
	}
	if(high==len) high=-1;
	return high;
}

int uppder_bound(int * vector,int len,int target)
{
	int mid=0,low=-1,high=len-1;

	// no need for low == high
	// because when high=mid, position high has been matched
	// if let low=high,then mid=high,but high has been matched before
	while(low<high)
	{
		mid=low+(high-low)/2;
		if(vector[mid]<target) high=mid-1;
		else low=mid;
	}
	if(low==-1) low=-1;
	return low;
}

/*
   [floor,ceiling]
   the index of the last entry that is smaller than floor
   the index of the first entry that is greater than ceiling
*/
