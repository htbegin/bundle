#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// m表示选择邮票时的最大张数
// n表示邮票面值的种类
static unsigned int m,n;
// maxl表示最大邮资的上界
// maxint表示无符号整数的最大值
// maxvalue表示当前的最大邮资区间的最大值
static unsigned int maxl,maxint,maxvalue;
// y[k]表示当前取得邮资k所需要的最少的邮票数目,长度为maxl+1
// x[k]/bestx[k]表示第k种邮票的面值为x[k]/best[k],长度为n+1
static unsigned int *x,*y,*bestx;
static const unsigned int uint_size=sizeof(unsigned int);

static int init(unsigned int most,unsigned int count,unsigned int max_value)
{
	int i=0;
	m=most;
	n=count;
	maxl=max_value;
	maxint=UINT_MAX;
	maxvalue=0;
	x=malloc(uint_size*(n+1));
	if(x==NULL) return -1; 
	y=malloc(uint_size*(maxl+1));
	if(y==NULL) return -1;
	bestx=malloc(uint_size*(n+1));
	if(bestx==NULL) return -1;
	
	for(i=0;i<=n;i++)
	{
		x[i]=0;
		bestx[i]=0;
	}	
	for(i=0;i<=maxl;i++)
		y[i]=maxint;
	 
	x[1]=1;
	y[0]=0;	
	return 0;
}

static void destroy()
{
	if(bestx)
		free(bestx);
	if(y)
		free(y);
	if(x)
		free(x);
}

static int Stamp_Backtrack(int i,int r)
{
	int j=0,k=0,max_range=x[i-2]*(m-1),tmp_index=0;
	if(r>=maxl)
	{
		printf("the value of maxl is too small!\n");
		exit(-2);
	}
	for(j=0;j<=max_range;j++)
	{
		if(j>=maxl)
		{
			printf("the value of maxl is too small!\n");
			exit(-2);
		}
		if(y[j]<m)
		{
			for(k=1;k<=m-y[j];k++)
			{
				tmp_index=j+k*x[i-1];
				if(tmp_index>=maxl)
				{
					printf("the value of maxl is too small!\n");
					exit(-2);
				}
				if(y[j]+k<y[tmp_index])
				{
					y[tmp_index]=y[j]+k;
				}
			}
		}
	}
	// 求出r-1最大连续邮资区间的最大值
	while(y[r]<maxint) r++;
	
	if(i>n)
	{
		if(r-1 > maxvalue)
		{
			maxvalue=r-1;
			for(j=1;j<=n;j++)
			{
				bestx[j]=x[j];
			}
		}
		return 0;
	}
	// 计算出 x[i]的取值范围
	int *z=malloc(uint_size*(maxl+1));
	if(z==NULL) exit(-1);
	for(k=0;k<=maxl;k++)
		z[k]=y[k];

	for(j=x[i-1]+1;j<=r;j++)
	{
		x[i]=j;
		Stamp_Backtrack(i+1,r);
		for(k=0;k<=maxl;k++)
			y[k]=z[k];
	}
	free(z);
	return 0;
}

static void ShowBestResult()
{
	int i=0;
	printf("%d kinds of stamp and just %d pieces\n",n,m);
	printf("the best value of each stamp is:");
	for(i=1;i<=n;i++)
	{
		printf("%d,",bestx[i]);;
	}
	printf("the maximum value is %d\n",maxvalue);
}

int main(int argc,char ** argv)
{
	int rval=0;
	rval=init(6,7,2400);
	if(rval>=0)
	{
		Stamp_Backtrack(2,1);
		ShowBestResult();
	}
	destroy();
	return rval;
}

