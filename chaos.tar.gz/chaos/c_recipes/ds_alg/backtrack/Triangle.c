#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int n=0,cnt=0,plus_cnt=0,half_cnt=0,total_cnt=0;
static int ** x=NULL;
static int size=sizeof(int);

static int init(int count)
{
	int i=0;
	n=count;
	cnt=0,plus_cnt=0;
	x=(int**)malloc(sizeof(int*)*n);
	if(!x)
	{
		printf("malloc error\n");
		return -1;
	}
	memset(x,0,sizeof(int*)*n);
	for(i=0;i<n;i++)
	{
		x[i]=(int*)malloc(size*(n-i));
		if(!x[i])
		{
			printf("malloc error\n");
			return -1;
		}
		memset(x[i],0,size*(n-i));
	}
	return 0;
}

static void destroy( )
{
	int i=0;
	if(x)
	{	
		for(i=0;i<n;i++)
		{
			if(x[i]) free(x[i]);
		}
		free(x);
		x=NULL;
	}
}

static void Show_Result( )
{
	printf("the number of symbol triangle in which the count of '+' equals to the count of '-' is %d\n",cnt);
}

// 子集树问题：似乎都可以先生成所有子集S[k],然后对S[k]进行计算所需要的值.
// 一般都是在生成的过程中计算,到生成了一个子集S[k],那么在S[k]上所需要的值就
// 计算出来了.
// 第1行的第1列可以作为第1层,一共有n层进行取值
static int Preprocess(int count)
{
	total_cnt=(count*(count+1))>>1;
	if(total_cnt%2!=0)
	{
		printf("preprocess failed!\n");
		return -1;
	}
	half_cnt=total_cnt>>1;
	return 0;
}

static int Triangle(int i)
{
	int k=0,j=0;
	if(i>=n)
	{
		cnt++;
	}
	else
	{
		for(k=0;k<2;k++)
		{
			plus_cnt+=k;
			x[0][i]=k;
			// x[0][0-i]构成的Triangle一共有i+1层
			for(j=1;j<=i;j++)
			{
				x[j][i-j]=x[j-1][i-j]^x[j-1][i-j+1];
				plus_cnt+=x[j][i-j];
			}
			// 是否有更好的剪枝函数呢?
			// 如果说有一个结论:在一个n层的符号三角塔中至少有N个+号,
			// 至多有M个+号.这个结论在剪枝里面好像用不到.
			if(plus_cnt<=half_cnt && (((i+2)*(i+1))>>1)-plus_cnt<=half_cnt)
			{
				Triangle(i+1);
			}
			for(j=1;j<=i;j++)
			{
				plus_cnt-=x[j][i-j];
			}
			plus_cnt-=k;
		}
	}
	return 0;
}

int main(int argc,char **argv)
{
	if(argc!=2)
	{
		printf("usage: %s number\n",argv[0]);
		return -1;
	}
	char * tmp=NULL;
	int count=strtol(argv[1],&tmp,10);
	if(*tmp!=0)
	{
		printf("usage: %s number\n",argv[0]);
		return -1;
	}
	if(Preprocess(count)>=0)
	{
		if(init(count)>=0)
		{
			Triangle(0);
			Show_Result();
		}
		destroy();
	}
	return 0;
}

