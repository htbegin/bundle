#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<errno.h>

// Combination Backtrack 
// 不仅要装下，而且要船1上留下的可用重量最小
// 后一个条件是否可以搞出一个限界函数出来？可以的!
static int *x=NULL,*bestx=NULL,*w=NULL;
static int cur_c1=0,c1=0,cur_c2=0,c2=0,n=0,best_c1=0,best_c2=0,left=0;
static int all_node=0;

static int init(int a1,int a2,int * weight,int count)
{
	int i=0;
	cur_c1=0;c1=a1;cur_c2=0;c2=a2;w=weight;n=count;
	best_c1=-1;best_c2=0;
	for(left=0,i=0;i<count;i++) left+=weight[i];
	
	if(x==NULL)
	{
		x=(int*)malloc(sizeof(int)*n);
		if(!x) return -1;
	}	
	if(bestx==NULL)
	{
		bestx=(int*)malloc(sizeof(int)*n);
		if(!bestx) return -1;
	}
	memset(x,0,sizeof(int)*n);
	memset(bestx,0,sizeof(int)*n);
	return 0;
}

static void destroy()
{
	if(x) { free(x);x=NULL;}
	if(bestx) { free(bestx);bestx=NULL;}
}

static void Show_Result()
{
	int i=0;
	
	if(best_c1!=-1)
	{
		for(i=0;i<n;i++)
		{
			if(bestx[i]==0)
			{
				printf("%d ",i);
			}
		}
		printf("in boat 1 whose ability is %d,and total weight is %d,other is in boat 2 \
whose ability is %d,and totaol weight is %d\n",c1,best_c1,c2,best_c2);
	}
	else
	{
		printf("no result for the problem!\n");
	}
}
// 统计遍历的树上有多少节点时，只需要统计第[0,n-1]层的节点数目，
// 不需要统计第n层的节点数目。没有统计第n层的节点。
static int Load_Backtrack(int i)
{
	int tmp=0,remain=0,k=0;

	if(i>=n)
	{
		for(k=0;k<n;k++)
		{
			bestx[k]=x[k];
		}
		best_c1=cur_c1;
		best_c2=cur_c2;
		Show_Result();
	}	
	else
	{
		all_node+=2;
		// x[i] is load to boat_1 whose ability is c1
		tmp=w[i];
		x[i]=0;
		remain=c1-cur_c1-tmp;
		if(remain>=0) 
		{
			cur_c1+=tmp;
			Load_Backtrack(i+1);
			cur_c1-=tmp;
		}
		x[i]=1;
		remain=c2-cur_c2-tmp;
		if(remain>=0) 
		{
			cur_c2+=tmp;
			Load_Backtrack(i+1);
			cur_c2-=tmp;
		}
	}
	return 0;
}

// 限界函数的逻辑正确的话，如果同时有多个最佳的解，那么最后的结果应该是第一个最佳解？
// 这个限界函数？
static int Load_Backtrack_WithBound_1(int i)
{
	int tmp=0,remain=0,k=0;
	if(i>=n)
	{
		for(k=0;k<n;k++)
		{
			bestx[k]=x[k];
		}
		best_c1=cur_c1;
		best_c2=cur_c2;
	}	
	else
	{
		all_node+=2;
		// x[i] is load to boat_1 whose ability is c1
		tmp=w[i];
		if(cur_c1+left>best_c1)
		{
			left-=tmp;
			x[i]=0;
			remain=c1-cur_c1-tmp;
			if(remain>=0) 
			{
				cur_c1+=tmp;
				Load_Backtrack_WithBound_1(i+1);
				cur_c1-=tmp;
			}
			x[i]=1;
			remain=c2-cur_c2-tmp;
			if(remain>=0) 
			{
				cur_c2+=tmp;
				Load_Backtrack_WithBound_1(i+1);
				cur_c2-=tmp;
			}
			left+=tmp;
		}
	}
	return 0;
}

static int Load_Backtrack_WithBound_2(int i)
{
	int tmp=0,remain=0,k=0;
	if(i>=n)
	{
		for(k=0;k<n;k++)
		{
			bestx[k]=x[k];
		}
		best_c1=cur_c1;
		best_c2=cur_c2;
	}	
	else
	{
		all_node+=2;
		// x[i] is load to boat_1 whose ability is c1
		tmp=w[i];
		//if(cur_c1+left>best_c1)
		//{
			left-=tmp;
			x[i]=0;
			remain=c1-cur_c1-tmp;
			if(remain>=0) 
			{
				cur_c1+=tmp;
				Load_Backtrack_WithBound_2(i+1);
				cur_c1-=tmp;
			}
			x[i]=1;
			remain=c2-cur_c2-tmp;
			if(remain>=0 && cur_c1+left>best_c1) 
			{
				cur_c2+=tmp;
				Load_Backtrack_WithBound_2(i+1);
				cur_c2-=tmp;
			}
			left+=tmp;
		//}
	}
	return 0;
}

// x[i]=1 first, then x[i]=0,the logic will be the same ?
// 如果只在x[i]=0中进行限界，那么这种限界的逻辑是错误的，但是依然可以求出最佳解。
// 因为我觉得需要得正确的限界逻辑会在左子和右子中都进行限界判断。
// 如果依然和先取x[i]=0后取x[i]=1的限界逻辑一样，那么这种逻辑(只是在x[i]=1中进行限界)是正确的。
static int Load_Backtrack_WithBound_3(int i)
{
	int tmp=0,remain=0,k=0;
	if(i>=n)
	{
		for(k=0;k<n;k++)
		{
			bestx[k]=x[k];
		}
		best_c1=cur_c1;
		best_c2=cur_c2;
	}	
	else
	{
		all_node+=2;
		tmp=w[i];
		left-=tmp;
		x[i]=1;
		remain=c2-cur_c2-tmp;
		if(remain>=0 && cur_c1+left>best_c1) 
		{
			cur_c2+=tmp;
			Load_Backtrack_WithBound_3(i+1);
			cur_c2-=tmp;
		}
		x[i]=0;
		remain=c1-cur_c1-tmp;
		if(remain>=0) 
		{
			cur_c1+=tmp;
			Load_Backtrack_WithBound_3(i+1);
			cur_c1-=tmp;
		}
		left+=tmp;
	}
	return 0;
}

// 在左子节点也进行限界是没有必要的。因为在右子上的限界＋其他的条件可以保证
// 第i层的左子节点如果满足约束条件的话，那么它也是隐式的满足限界条件。详细的证明
// 可以参考算法的笔记本。结论就是Load_Backtrack_WithBound_4是没有必要的。
static int Load_Backtrack_WithBound_4(int i)
{
	int tmp=0,remain=0,k=0;
	if(i>=n)
	{
		for(k=0;k<n;k++)
		{
			bestx[k]=x[k];
		}
		best_c1=cur_c1;
		best_c2=cur_c2;
	}	
	else
	{
		all_node+=2;
		// x[i] is load to boat_1 whose ability is c1
		tmp=w[i];
		//if(cur_c1+left>best_c1)
		//{
			left-=tmp;
			x[i]=0;
			remain=c1-cur_c1-tmp;
			if(remain>=0 && ((i>0 && x[i-1]==0)?(cur_c1+left+tmp>best_c1):1))
			{	
				cur_c1+=tmp;
				Load_Backtrack_WithBound_4(i+1);
				cur_c1-=tmp;
			}
			x[i]=1;
			remain=c2-cur_c2-tmp;
			if(remain>=0 && cur_c1+left>best_c1) 
			{
				cur_c2+=tmp;
				Load_Backtrack_WithBound_4(i+1);
				cur_c2-=tmp;
			}
			left+=tmp;
		//}
	}
	return 0;
}

static int set_bestx=0,exit_flag=0;
// 改变设置bestx的方法,使得复杂度从O(n* 2^n)到O(2^n)
static int Load_Backtrack_2n_1(int i)
{
	int tmp=0,remain=0,k=0;
	
	if(i>=n)
	{
		if(set_bestx==1)
		{
			for(k=0;k<n;k++)
			{
				bestx[k]=x[k];
			}
			// 已经得到了问题的第一个最佳解，所以没有必要再去取其他的最佳解了
			set_bestx=0;
			exit_flag=1;
		}
		best_c1=cur_c1;
		best_c2=cur_c2;
	}	
	else
	{
		all_node++;
		// x[i] is load to boat_1 whose ability is c1
		if(exit_flag==1) return 0;

		tmp=w[i];
		left-=tmp;
		x[i]=0;
		remain=c1-cur_c1-tmp;
		if(remain>=0) 
		{
			cur_c1+=tmp;
			Load_Backtrack_2n_1(i+1);
			cur_c1-=tmp;
		}
		if(exit_flag==1) return 0;

		x[i]=1;
		remain=c2-cur_c2-tmp;
		if(remain>=0 && ((set_bestx==1)?cur_c1+left>=best_c1:cur_c1+left>best_c1))
		{
			cur_c2+=tmp;
			Load_Backtrack_2n_1(i+1);
			cur_c2-=tmp;
		}
		left+=tmp;
	}
	return 0;
}

// 改变设置bestx的方法,使得复杂度从O(n* 2^n)到O(2^n)
// 在取得最佳解后，设置一个标志，从第i层往上回溯时，根据标志来确定是否需要将
// bestx[j]设置为x[j]
// 因为第i层是否需要将best[i]设置为x[i]，只与第i+1层的set_bestx相关，所以在第i层开始
// 往下回溯前，先将set_bestx设置为0
//
static int Load_Backtrack_2n_2(int i)
{
	int tmp=0,remain=0,left_bestx=0;

	if(i>=n)
	{
		best_c1=cur_c1;
		best_c2=cur_c2;
		set_bestx=1;
	}	
	else
	{
		all_node+=2;
		left_bestx=0;
		// no need to set set_bestx as zero
		//set_bestx=0;
		if(set_bestx==1)
			printf("god,I am wrong!\n");
		tmp=w[i];
		left-=tmp;

		// x[i] is load to boat_1 whose ability is c1
		x[i]=0;
		remain=c1-cur_c1-tmp;
		if(remain>=0) 
		{
			cur_c1+=tmp;
			Load_Backtrack_2n_2(i+1);
			cur_c1-=tmp;
			if(set_bestx==1) 
			{
				bestx[i]=x[i];
				left_bestx=1;
			}
		}

		set_bestx=0;
		x[i]=1;
		remain=c2-cur_c2-tmp;
		if(remain>=0 && cur_c1+left>best_c1) 
		{
			cur_c2+=tmp;
			Load_Backtrack_2n_2(i+1);
			cur_c2-=tmp;
			if(set_bestx==1) bestx[i]=x[i];
		}
		left+=tmp;
		if(set_bestx==1 || left_bestx==1)
			set_bestx=1;
	}
	return 0;
}

static int bestx_level=-1;
static int Load_Backtrack_2n_3(int i)
{
	int tmp=0,remain=0;

	if(i>=n)
	{
		best_c1=cur_c1;
		best_c2=cur_c2;
		bestx_level=n-1;
	}	
	else
	{
		all_node+=2;
		tmp=w[i];
		left-=tmp;

		// x[i] is load to boat_1 whose ability is c1
		x[i]=0;
		remain=c1-cur_c1-tmp;
		if(remain>=0) 
		{
			cur_c1+=tmp;
			Load_Backtrack_2n_3(i+1);
			cur_c1-=tmp;
			if(bestx_level==i) 
			{
				bestx[i]=x[i];
				bestx_level--;
			}
		}

		x[i]=1;
		remain=c2-cur_c2-tmp;
		if(remain>=0 && cur_c1+left>best_c1) 
		{
			cur_c2+=tmp;
			Load_Backtrack_2n_3(i+1);
			cur_c2-=tmp;
			if(bestx_level==i)
			{
				bestx[i]=x[i];
				bestx_level--;
			}
		}
		left+=tmp;
	}
	return 0;
}

// 如何计算遍历节点的个数？
// 通过i++！两种方式：
// 1 通过i++,all_node+=2。但这样第一次的那个节点就没有被记录
// 2 每遍历一个节点就all_node++
// flag[i]是用来表示当前遍历的第i层的节点的前一个节点是否往下搜索了
// left_bestx[i]是用来表示当前遍历的第i层的节点的前一个节点是否进行了最佳解的设置
static int Load_Backtrack_Iterative_1(int i)
{
	int remain=0,tmp=0;
	int * flag=(int*)malloc(sizeof(int)*n);
	int * left_bestx=(int*)malloc(sizeof(int)*n);
	
	if( !flag || !left_bestx )
	{
		printf("malloc error:%s\n",strerror(errno));
		if(flag) free(flag);
		return -1;
	}
	tmp=i;
	for(i=0;i<n;i++)
		flag[i]=0;
	i=tmp;

	while(i>=0)
	{
		if(i>=n)
		{
			best_c1=cur_c1;
			best_c2=cur_c2;
			set_bestx=1;
			i--;
			//all_node-=2;
		}
		//else
		//{
			tmp=w[i];
			if(x[i]==0)
			{
				all_node++;
				left-=tmp;
				set_bestx=0;
				left_bestx[i]=0;
				x[i]++;
				remain=c1-cur_c1-tmp;
				if(remain>=0)
				{
					flag[i]=1;
					cur_c1+=tmp;
					i++;
					//all_node+=2;
				}
			}
			//左子遍历结束
			else if(x[i]==1)
			{
				all_node++;
				if(flag[i]==1)
				{
					cur_c1-=tmp;
					flag[i]=0;
				}
				if(set_bestx==1)
				{
					left_bestx[i]=1;
					bestx[i]=x[i]-1;
				}
				set_bestx=0;
				x[i]++;
				remain=c2-cur_c2-tmp;
				if(remain>=0 && left+cur_c1>best_c1)
				{
					flag[i]=1;
					cur_c2+=tmp;
					i++;
					//all_node+=2;
				}
			}
			else
			{
				if(flag[i]==1)
				{
					cur_c2-=tmp;
					flag[i]=0;
				}
				if(set_bestx==1)
				{
					bestx[i]=x[i]-1;
				}
				x[i]=0;
				left+=tmp;
				if(set_bestx==1 || left_bestx[i]==1)
					set_bestx=1;
				i--;
			}
		//}
	}
	free(left_bestx);
	free(flag);
	return 0;
}

// 这种解法类似于二叉树的迭代遍历
// 遍历过的结构为一棵树，统计这棵树上有多少节点。
// 泛化的思考
// 计算总共遍历的节点数目的方法与
// Load_Backtrack_Iteratice_1类似
static int Load_Backtrack_Iterative_2(int i)
{
	int k=0;
	while(1)
	{
		// 遍历到第i层
			// 先从左子节点开始 
		while(i<n && cur_c1+w[i]<=c1)
		{
			all_node++;
			left-=w[i];
			cur_c1+=w[i];
			x[i]=0;
			i++;
			//all_node+=2;
		}
		//到达叶子节点，处理结束后也需要回到第i-1层并且判断
		//应该再从第i-1层的哪一个节点开始
		if(i>=n)
		{
			//all_node-=2;
			for(k=0;k<n;k++)
				bestx[k]=x[k];
			best_c1=cur_c1;
			best_c2=cur_c2;
		}
		//第i层的左子不再满足约束条件，被剪去
		else
		{
			all_node++;
			//开始遍历第i层的右子节点
			left-=w[i];
			cur_c2+=w[i];
			x[i]=1;
			all_node++;
			i++;
		}
		// 判断第i层右子节点是否满足约束条件和限界函数
			// 不满足，开始回溯
		while(cur_c2>c2 || cur_c1+left<=best_c1)
		{
			i--;
			//回到第i层，判断应该从第i层的哪一个节点开始继续
				// 如果第i层的右子节点也被遍历过了，那么就继续回溯，回到第i-1层
				// 需要恢复left和cur_c2的值(将它们恢复到第i-1层时的值)
			while(i>=0 && x[i])
			{
				left+=w[i];
				cur_c2-=w[i];
				i--;
			}
			// 整棵树都遍历结束
			if(i<0)
			{
				return 0;
			}
			// 第i层的左子节点被遍历过了，应该开始遍历右子节点
			// left保持不变，cur_c1应该减去w[i]，cur_c2加上w[i]
			// 将cur_c1恢复到第i-1层时的值
			// 继续判断第i层右子节点是否满足约束条件和限界函数，
			// 就是那个while循环
			else
			{
				cur_c1-=w[i];
				cur_c2+=w[i];
				x[i]=1;
				i++;
				all_node++;
			}
		}
		//all_node+=2;
		// 第i层右子节点满足约束条件和限界函数,进入到第i+1层
		// 这个应该就是为何先i++，然后再判断是否满足约束条件和
		// 限界函数的原因。这时才算进入下一层，所以这时才all_node++。
	}
}

// 修改设置bestx的方法
// 我不知道是哪个地方的逻辑出现了问题。
static int Load_Backtrack_Iterative_3(int i)
{
	int * left_bestx=(int*)malloc(n*sizeof(int));
	if(left_bestx==NULL)
	{
		printf("malloc error:%s\n",strerror(errno));
		return -1;
	}
	memset(left_bestx,0,n*sizeof(int));

	while(1)
	{
		// 遍历到第i层
			// 先从左子节点开始 
		while(i<n && cur_c1+w[i]<=c1)
		{
			left_bestx[i]=0;
			all_node++;
			left-=w[i];
			cur_c1+=w[i];
			x[i]=0;
			i++;
			//all_node+=2;
		}
		//到达叶子节点，处理结束后也需要回到第i-1层并且判断
		//应该再从第i-1层的哪一个节点开始
		if(i>=n)
		{
			//all_node-=2;
			set_bestx=1;
			best_c1=cur_c1;
			best_c2=cur_c2;
		}
		//第i层的左子不再满足约束条件，被剪去
		else
		{
			set_bestx=0;
			all_node++;
			//开始遍历第i层的右子节点
			left-=w[i];
			cur_c2+=w[i];
			x[i]=1;
			all_node++;
			i++;
		}
		// 判断第i层右子节点是否满足约束条件和限界函数
			// 不满足，开始回溯
		while(cur_c2>c2 || cur_c1+left<=best_c1)
		{
			i--;
			//回到第i层，判断应该从第i层的哪一个节点开始继续
				// 如果第i层的右子节点也被遍历过了，那么就继续回溯，回到第i-1层
				// 需要恢复left和cur_c2的值(将它们恢复到第i-1层时的值)
			while(i>=0 && x[i])
			{
				if(set_bestx==1) bestx[i]=x[i];
				else if(left_bestx[i]==1) set_bestx=1;
				left+=w[i];
				cur_c2-=w[i];
				i--;
			}
			// 整棵树都遍历结束
			if(i<0)
			{
				return 0;
			}
			// 第i层的左子节点被遍历过了，应该开始遍历右子节点
			// left保持不变，cur_c1应该减去w[i]，cur_c2加上w[i]
			// 将cur_c1恢复到第i-1层时的值
			// 继续判断第i层右子节点是否满足约束条件和限界函数，
			// 就是那个while循环
			else
			{
				if(set_bestx==1) 
				{
					bestx[i]=x[i];
					left_bestx[i]=1;
				}
				set_bestx=0;
				cur_c1-=w[i];
				cur_c2+=w[i];
				x[i]=1;
				i++;
				all_node++;
			}
		}
		//all_node+=2;
		// 第i层右子节点满足约束条件和限界函数,进入到第i+1层
		// 这个应该就是为何先i++，然后再判断是否满足约束条件和
		// 限界函数的原因。这时才算进入下一层，所以这时才all_node++。
	}
}

typedef int (*Bt_Method)(int i);

int main(int argc,char ** argv)
{
	int rval=0;
	int weight[10]={2,10,14,20,24,34,44,54,65,67};
	Bt_Method all_method[]={NULL,
							Load_Backtrack,
							Load_Backtrack_WithBound_1,Load_Backtrack_WithBound_2,
							Load_Backtrack_WithBound_3,Load_Backtrack_WithBound_4,
							Load_Backtrack_2n_1,Load_Backtrack_2n_2,Load_Backtrack_2n_3,
							Load_Backtrack_Iterative_1,Load_Backtrack_Iterative_2,
							Load_Backtrack_Iterative_3,
							NULL};
	rval=init(301,65,weight,10);
	if(rval>=0)
	{	
		all_node=0;
		//set_bestx=0;
		bestx_level=-1;
		all_method[8](0);
		printf("node is %d\n",all_node);
		Show_Result();
	}
	else 
	{
		printf("init error\n");
	}
	destroy();
	return 0;
}

