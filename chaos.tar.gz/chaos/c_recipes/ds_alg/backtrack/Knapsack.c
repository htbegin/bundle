#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int init(int count)
{
	return 0;
}

static void destroy( )
{
}

static int Knapsack(int i)
{
	return 0;
}

static void Show_Result( )
{
}

int main(int argc,char **argv)
{
	return 0;
}

