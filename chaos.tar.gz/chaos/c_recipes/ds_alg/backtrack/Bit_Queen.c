#include <stdio.h>
#include <stdlib.h>

static int upperlim;
static int sum;
//应该也是可以利用对称，将搜索时间缩小一半。
static int Backtrack(int column,int ld,int rd)
{
	int pos=0,p=0;
	if(column!=upperlim)
	{
		pos=upperlim &  ~(column | ld | rd);
		while(pos!=0)
		{
			//最右边的第一个1
			p=pos & -pos;
			pos=pos-p;
			Backtrack(column+p,(ld+p)<<1,(rd+p)>>1);
		}
	}
	else
	{
		sum++;
	}
	return 0;
}

int main(int argc,char ** argv)
{
	if(argc!=2)
	{
		printf("usage: %s number[1-32]\n",argv[0]);
		return -1;
	}
	char * tmp=NULL;
	int  count=strtol(argv[1],&tmp,10);
	if(*tmp!=0)
	{
		printf("usage: %s number[1-32]\n",argv[0]);
		return -1;
	}
	if(count<=0 || count>32)
	{
		printf("usage: %s number[1-32]\n",argv[0]);
		return -1;
	}
	upperlim=(1<<count)-1;
	sum=0;
	Backtrack(0,0,0);
	fprintf(stdout,"there are %d solutions for %d-Queen Problem\n",sum,count);
	return 0;
}

