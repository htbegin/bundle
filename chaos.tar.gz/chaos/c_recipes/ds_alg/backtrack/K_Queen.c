#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

// input: m*n的棋盘 [x,y]个皇后
// m*n : [0,150] x,y : [0,50]
// k*k的棋盘 k个皇后,CNT种放置方法
// (k+i)*(k+j) k个皇后,多少种放置方法?
typedef long long i64;

i64 s[151][151][51];
int m, n, x, y;
int MASK;
i64 ans;

void dfs(int m, int n, int row, int ld, int rd, int num, int p, int index)
{
	if(num == p)
		ans++;
	else if(index < m)
	{
		if(num + m - index > p)
			dfs(m, n, row, ld << 1, rd >> 1, num, p, index + 1);
		int pos = MASK & ~(row | rd | ld);
		while(pos != 0)
		{
			int pp = pos & -pos;
			pos = pos - pp;
			dfs(m, n, row + pp, (ld + pp) << 1, (rd + pp) >> 1, num + 1, p,
				index + 1);
		}
	}
}

i64 solve(int m, int n, int p)
{
	if(s[m][n][p] != -1)
		return s[m][n][p];
	if(p > n)
		return 0;

	i64 ret = 0;
	int j;
	for(j = 0; j < n; j++)
	{
		int pos = 1 << (n - 1 - j);
		ans = 0;
		dfs(m, n, pos, pos << 1, pos >> 1, 1, p, 1);
		ret += ans;
	}

	s[m][n][p] = ret;

	return ret;
}

int main()
{
	int i, j;
	memset(s, -1, sizeof(s));

	while(scanf("%d%d%d%d", &m, &n, &x, &y) == 4)
	{
		if(m < n && n > 31)
		{
			int t = m;
			m = n;
			n = t;
		}
		if(y > n)
			y = n;
		MASK = (1 << n) - 1;
		i64 res = 0;
		if(x == 0)
			res++, x = 1;
		for(i = x; i <= y; i++)
		{
			for(j = i; j <= m; j++)
				res += solve(j, n, i);
		}
		printf("%lld\n", res);
	}

	return 0;
}
