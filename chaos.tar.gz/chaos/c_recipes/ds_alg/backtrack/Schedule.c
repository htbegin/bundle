#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

static int n=0,f1=0,f2=0,f=0,best_f=0,bestx_level=0;
static int *x=NULL,*bestx=NULL;
static int *a=NULL,*b=NULL;

static int init(int * time_a,int * time_b,int count)
{
	int i=0;
	n=count,a=time_a,b=time_b;
	x=(int*)malloc(sizeof(int)*n);
	if(!x)
	{
		perror("malloc error\n");
		return -1;
	}
	bestx=(int*)malloc(sizeof(int)*n);
	if(!bestx) 
	{
		perror("malloc error\n");
		return -1;
	}
	for(i=0;i<n;i++) 
	{
		x[i]=i;
		bestx[i]=i;
	}
	// how to set the initial value of best_f
	// set best_f to the value of the first sequence
	i=0;
	f1=0,f2=0,f=0;
	while(i<n)
	{
		f1+=a[x[i]];
		f2=((f2>f1)?f2:f1)+b[x[i]];
		f+=f2;
		i++;
	}
	best_f=f;
	printf("init best value is %d\n",best_f);
	f1=0,f2=0,f=0;
	bestx_level=-1;
	return 0;
}

static void destroy( )
{
	if(x) { free(x); x=NULL;}
	if(bestx) { free(bestx); bestx=NULL;}
}

static void Swap(int *a,int *b)
{
	int tmp=0;
	tmp=*a;
	*a=*b;
	*b=tmp;
}

// 描述清楚这个问题：求所有Job从最开始(不是从Job在机器1上被处理开始)到被机器2
// 处理完所花时间的总和最少。
// 假设第i-1个作业在机器1、机器2上从最开始到被处理结束所花的时间为f1、f2，
// 假设第i个作业在机器1、机器2上从最开始到被处理结束所花的时间为g1、g2也容易得到
// 求1--i个作业从最开始到被机器2处理完所花时间也容易求得

// 使用old_f2,就相当于增加了O(n)的空间，还可以不使用old_f2，直接使用f2[0-n-1]
// 初始值f2[i]=0,i<-[0,n-1],在第i层对f2的处理就变为
// f2[i]=((((i>0)?f2[i-1]:0)>f1)?f2[i-1]:f1)+b[x[k]],
// f+=f2[i]; f-=f2[i];去掉f2=old_f2
static int Schedule(int i)
{
	int k=0,old_f2=0;
	if(i>n-1)
	{
		best_f=f;
		bestx_level=n-1;
	}
	else
	{
		for(k=i;k<n;k++)
		{
			//使用x[k]作为第i层的节点
			f1+=a[x[k]];
			old_f2=f2;	
			f2=((f2>f1)?f2:f1)+b[x[k]];
			f+=f2;
			if(f<best_f)
			{
				Swap(x+i,x+k);
				Schedule(i+1);
				if(bestx_level==i)
				{
					bestx[i]=x[i];
					bestx_level--;
				}
				Swap(x+i,x+k);
			}
			f-=f2;
			f2=old_f2;
			f1-=a[x[k]];
		}
	}
	return 0;
}

static void Show_Result( )
{
	int i=0;
	printf("the minimum time is %d\n",best_f);
	printf("the best schedule sequence is: ");
	for(i=0;i<n-1;i++)
		printf("%d,",bestx[i]);
	printf("%d\n",bestx[n-1]);
}

int main(int argc,char **argv)
{
	int time_a[3]={2,3,2},time_b[3]={1,1,3},rval=0;
	rval=init(time_a,time_b,3);
	if(rval>=0)
	{
		Schedule(0);
		Show_Result();
	}
	destroy( );
	return 0;
}

