#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define _METHOD_2_
#define _USE_SYMMETRY_
static int cnt=0,result_cnt=0;
static int *column_pos=NULL;

// 在使用第2种用空间换取时间的算法时,column_pos[i]为0表示第i列没有任何棋子,
// 为1时,表示第i列有棋子.
// up_cross_line[i]为0时,表示往上去的第i条对角线(以左下角到右上角)上没有任何棋子
// 以左下角为第0行第0列
// down_cross_line为从左上角到右下角
// 两种对角线 m*n的棋盘 每一种对角线的条数为m+n-1
#ifdef _METHOD_2_
static int * up_cross_line=NULL,* down_cross_line=NULL;
#endif

static int init(int count)
{
	cnt=count;
	result_cnt=0;
	column_pos=(int*)malloc(sizeof(int)*count);
	if(!column_pos)
	{
		perror("malloc error");
		return -1;
	}
	memset(column_pos,0,sizeof(int)*count);
#ifdef _METHOD_2_
	up_cross_line=(int*)malloc(sizeof(int)*(2*count-1));
	if(!up_cross_line)
	{
		perror("malloc error");
		return -1;
	}
	memset(up_cross_line,0,sizeof(int)*(2*count-1));

	down_cross_line=(int*)malloc(sizeof(int)*(2*count-1));
	if(!down_cross_line)
	{
		perror("malloc error");
		return -1;
	}
	memset(down_cross_line,0,sizeof(int)*(2*count-1));
#endif
	return 0;
}

static void destroy( )
{
	if(column_pos)
	{ free(column_pos);column_pos=NULL;}
#ifdef _METHOD_2_
	if(up_cross_line)
	{ free(up_cross_line);up_cross_line=NULL;}
	if(down_cross_line)
	{ free(down_cross_line);down_cross_line=NULL;}
#endif
}

/**
 * Return
 * 0: the ith queen could not be placed here
 * 1: no problem to place the ith Queen in here
 */
static int no_death(int l,int c)
{
#ifdef _METHOD_2_
	if( column_pos[c]==1 || up_cross_line[l+c]==1 
			|| down_cross_line[c-l+cnt-1]==1)
		return 0;
#else
	int k=0;
	for(k=0;k<l;k++)
	{
		if( column_pos[k]==c || abs(l-k)==abs(c-column_pos[k]) )
			return 0;
	}
#endif	
	return 1; 
}

#ifdef _METHOD_2_
void update_status(int l,int c,int value)
{
	column_pos[c]=value;
	up_cross_line[l+c]=value;
	down_cross_line[c-l+cnt-1]=value;
}
#endif

static void Show_Result( )
{
	fprintf(stdout,"there are %d solutions for %d-Queen Problem\n",result_cnt,cnt);
}

// 这里i应该表示在第i行应该如何放置皇后(从第0行开始)
// 从第0列开始试.
static int Queen(int i)
{
	int k=0;
	if(i>=cnt)
	{
		result_cnt++;
	}
	else
	{
		for(k=0;k<cnt;k++)
		{
#ifdef _USE_SYMMETRY_
			if(i==0)
			{
				if( k==(cnt>>1) )
				{
					result_cnt*=2;
					if( cnt==(k<<1))
					{
						break;
					}
				}
				else if( k>(cnt>>1) )
				{
					break;
				}
			}
#endif
			if(no_death(i,k))
			{
#ifdef _METHOD_2_
				update_status(i,k,1);
#else
				column_pos[i]=k;
#endif
				Queen(i+1);
#ifdef _METHOD_2_
				update_status(i,k,0);
#endif
			}
		}
	}
	return 0;
}

static int Queen_Iterative(int i)
{
	int j=0;
	for(j=0;j<cnt;j++)
		column_pos[j]=-1;
	while(i>=0)
	{
		++column_pos[i];
		while( column_pos[i]<cnt && (!no_death(i,column_pos[i])) )
		   	++column_pos[i];
		if( column_pos[i]<cnt)
		{
			if(i==cnt-1)
				result_cnt++;
			else
				i++;
		}
		else
		{
			column_pos[i]=-1;
			i--;
		}
	}
	return 0;
}

// 有一个用空间换取时间的算法
// 在第1行放置皇后时,有一半的列可以不用放置.根据y轴的对称
// 是否可以根据x轴的对称,来去掉一些解呢?我觉得不能.
// 能否将旋转后的解也给去掉
int main(int argc,char **argv)
{
	if(argc!=2)
	{
		printf("usage: %s Queen_Number\n",argv[0]);
		return -1;
	}
	char * tmp=NULL;
	int count=strtol(argv[1],&tmp,10);
	if(*tmp!=0 || tmp==argv[1])
	{
		printf("usage: %s number\n",argv[0]);
		return -1;
	}
	if(init(count)>=0)
	{
		//Queen_Iterative(0);
		Queen(0);
		Show_Result( );
	}
	destroy( );
	return 0;
}
