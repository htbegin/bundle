static int n;
static int * x;

//Subset tree
static void Backtrack_Recursive_S(int level)
{	
	// level start from 1
	if(level>n) Output(x);
	else
	{
		int k=0;
		for(k=f(level,n);k<=g(level,n);k++)
		{
			x[level]=h(k);
			if(Constraint(level) && Bound(level)) Backtrack_Recursive_S(level+1);
		}
	}
}

// Permutation tree
static void Backtrack_Recursive_P(int i)
{
	// no need to wait for i>n
	if(i>=n) Output(x);
	else
	{
		int k=0;
		for(k=i;k<=n;k++)
		{
			Swap(x+k,x+i);
			if(Constraint(i) && Bound(i)) Backtrack_Recursive_P(i+1);
			Swap(x+k,x+i);
		}
	}
}		

// Combination tree
static void Backtrack_Recursive_C(int i)
{
	if(i>n) Output(x);
	else
	{
		// x[i] has only two value:  0 or 1
		x[i]=0;
		Backtrack_Recursive_C(i+1);
		x[i]=1;
		Backtrack_Recursive_C(i+1);
	}
}
// Subset tree Iterative
// 迭代的来说结束条件是什么?
// 如何往下和往上回溯?
// 结束条件为(从第一层开始的)向第0层回溯!
static void Backtrack_Iterative_S(int i)
{
	int k=0,end=0;
	int * start_value=(int*)malloc((n+1)*sizeof(int));

	for(k=1;k<=n;k++)
		start_value[k]=f(i,n);

	while(i>=1)
	{	
		while(i<=n)
		{
			end=g(i,n);
			// 在第i层 继续往下或者往上
			for(k=start_value[i];k<=end;k++)
			{
				x[i]=k;
				//往下
				if(Constraint(i) && Bound(i))
				{
					start_value[i]=k+1;
					++i;
					break;
				}
			}
			// 往上
			--i;
			break;
		}
		Output(x);
		--i;
	}
}

