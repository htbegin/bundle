#include "apue.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

static int create_dir(const char *dir, unsigned int level)
{
	const char *sub_dir = "ABCD";
	int idx = 0;
	char *full_path = NULL;
	int path_size = 0;

	if (chdir(dir) != 0) {
		err_sys("chdir fail");
	}

	while (idx++ < level) {
		if (mkdir(sub_dir, DIR_MODE) != 0) {
			err_sys("mkdir fail at level %u", idx);
		}
		if (chdir(sub_dir) != 0) {
			err_sys("chdir fail at level %u", idx);
		}
	}

	if (creat("file", FILE_MODE) < 0) {
		err_sys("create fail");
	}

	full_path = path_alloc(&path_size);
	while (1) {
		if (getcwd(full_path, path_size) != NULL) {
			break;
		} else {
			err_ret("getcwd fail, size: %d", path_size);

			path_size += 1024;
			if (path_size > 8192) {
				err_quit("giving up");
			}
			if ((full_path = realloc(full_path, path_size)) == NULL) {
				err_sys("realloc faill");
			}
		}
	}

	printf("length:%d\npath:%s\n", strlen(full_path), full_path);

	return 0;
}

int main(int argc, char **argv)
{
	char *start_dir = NULL;
	unsigned int level = 0;
	struct stat buf = {0};

	if (argc != 3) {
		err_quit("Usage: %s start_dir level", argv[0]);
	}

	start_dir = argv[1];
	level = strtoul(argv[2], NULL, 10);

	if (stat(start_dir, &buf) != 0) {
		err_sys("stat %s fail", start_dir);
	}

	if (!S_ISDIR(buf.st_mode)) {
		err_quit("%s isn't a directory", start_dir);
	}

	if (level <= 0) {
		err_quit("invalid level %u\n", level);
	}

	return create_dir(start_dir, level);
}

