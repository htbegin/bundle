#include "apue.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char **argv)
{
	const char *fname = "/dev/zero";
	int fd = 0;
	int rval = 0;

	fd = open(fname, O_RDWR);
	if (fd >= 0)
	{
		rval = writew_lock(fd, 0, SEEK_SET, 1);
		if (rval == 0)
		{
			err_msg("lock %s succeeded", fname);
			sleep(10);
		}
		else
		{
			err_sys("lock %s failed", fname);
		}

		close(fd);
	}
	else
	{
		err_sys("open %s failed", fname);
	}

	return 0;
}

