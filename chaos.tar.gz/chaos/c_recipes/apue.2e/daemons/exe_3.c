#include "apue.h"
#include <syslog.h>

int main(int argc, char **argv)
{
	char *name = NULL;

	daemonize("test");

	name = getlogin();
	syslog(LOG_ERR, "login name is %s\n", name);

	return 0;
}
