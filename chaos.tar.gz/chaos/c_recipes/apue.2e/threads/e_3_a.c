#include "apue.h"
#include <pthread.h>

#define WORK_THREAD_CNT 10
#define WORK_CNT 40

struct queue {
	pthread_t q_job_id;
	pthread_mutex_t q_job_mutex;
	pthread_cond_t q_job_cond;
};

static int exit_flag = 0;

static struct queue *create_queue(void)
{
	struct queue *qp = NULL;

	qp = calloc(1, sizeof(*qp));
	if (qp != NULL) {
		qp->q_job_id = 0;
		pthread_mutex_init(&qp->q_job_mutex, NULL);
		pthread_cond_init(&qp->q_job_cond, NULL);
	}

	return qp;
}

static void *work_thread_func(void *arg)
{
	struct queue *qp = arg;
	pthread_t tid = pthread_self();

	while (!exit_flag) {
		pthread_mutex_lock(&qp->q_job_mutex);
		while (!exit_flag && qp->q_job_id != tid) {
			pthread_cond_wait(&qp->q_job_cond, &qp->q_job_mutex);
		}
		if (exit_flag) {
			pthread_mutex_unlock(&qp->q_job_mutex);
			break;
		}
		if (qp->q_job_id == tid) {
			qp->q_job_id = 0;
		}
		pthread_mutex_unlock(&qp->q_job_mutex);

		err_msg("thread %lu finish a work", (unsigned long)tid);
	}

	pthread_exit(NULL);
}

static void dispatch_job(struct queue *qp, int wcnt, pthread_t *tids, int tcnt)
{
	int widx = 0;
	int tidx = 0;

	srandom((unsigned int)time(NULL));

	for (widx = 0; widx < wcnt; ++widx) {
		tidx = random() % tcnt;
		pthread_mutex_lock(&qp->q_job_mutex);
		if (qp->q_job_id == 0) {
			qp->q_job_id = tids[tidx];
		} else {
		}
		pthread_mutex_unlock(&qp->q_job_mutex);
		pthread_cond_broadcast(&qp->q_job_cond);
	}
}

int main(int argc, char **argv)
{
	int rval = 0;
	struct queue *qp = NULL;
	int idx = 0;
	int thread_cnt = WORK_THREAD_CNT;
	int work_cnt = WORK_CNT;
	pthread_t tids[WORK_THREAD_CNT] = {0};

	qp = create_queue();
	if (qp == NULL) {
		err_quit("create queue error");
	}

	for (idx = 0; idx < thread_cnt; ++idx) {
		rval = pthread_create(tids + idx, NULL, work_thread_func, qp);
		if (rval != 0) {
			err_sys("pthread_create error");
		}
	}

	dispatch_job(qp, work_cnt, tids, thread_cnt);

	wait_job_done(qp);

	for (idx = 0; idx < thread_cnt; ++idx) {
		rval = pthread_join(tids[idx], NULL);
		if (rval == 0) {
			err_msg("thread %lu exit", (unsigned long)tids[idx]);
		} else {
			err_sys("pthread_join error");
		}
	}

	return 0;
}
