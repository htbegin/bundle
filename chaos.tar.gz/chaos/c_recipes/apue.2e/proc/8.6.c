#include "apue.h"

#define CMD_LEN 512

int main(int argc, char **argv)
{
	pid_t pid = 0;
	char cmd[CMD_LEN] = {0};
	int ret = 0;

	if ((pid = fork()) < 0) {
		err_sys("fork error");
	} else if (pid == 0) {
		exit(0);
	}

	sleep(5);

	snprintf(cmd, sizeof(cmd), "ps -p %d -o state= | grep Z >/dev/null", pid);

	ret = system(cmd);
	if (ret != -1 && WIFEXITED(ret) && WEXITSTATUS(ret) == 0) {
		printf("child process %d is an zombie\n", pid);
	} else {
		pr_exit(ret);
	}

	return 0;
}
