#include "apue.h"

int main(int argc, char **argv)
{
	const int min_len = 8;
	const int max_len = 8;

	printf("%-*.*s\n", min_len, max_len, "abcd");
	printf("%-*.*s\n", min_len, max_len, "abcdefgh");
	printf("%-*.*s\n", min_len, max_len, "abcdefghi");

	printf("%*.*s\n", min_len, max_len, "abcd");
	printf("%*.*s\n", min_len, max_len, "abcdefgh");
	printf("%*.*s\n", min_len, max_len, "abcdefghi");

	return 0;
}
