#include "apue.h"

int		glob = 6;		/* external variable in initialized data */

int
main(void)
{
	int printf_ret;
	int write_ret;
	int		var;		/* automatic variable on the stack */
	pid_t	pid;

	var = 88;
	printf("before vfork\n");	/* we don't flush stdio */
	if ((pid = vfork()) < 0) {
		err_sys("vfork error");
	} else if (pid == 0) {		/* child */
		glob++;					/* modify parent's variables */
		var++;
		fclose(stdout);
		_exit(0);				/* child terminates */
	}

	/*
	 * Parent continues here.
	 */
	printf_ret = printf("pid = %d, glob = %d, var = %d\n", getpid(), glob, var);
	write_ret = write(STDOUT_FILENO, "a\n", 2);
	fprintf(stderr, "printf return %d\n", printf_ret);
	fprintf(stderr, "write return %d\n", write_ret);

	exit(0);
}
