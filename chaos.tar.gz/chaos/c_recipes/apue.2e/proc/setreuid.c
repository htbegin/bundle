#include "apue.h"

/* assume the permission of demo: */
/* uid of owner is 6 */
/* gid of group is 1000 */
/* the set-user-ID bit on */
/* assume the uid of the user running the demo is 1000 */

int main(int argc, char **argv)
{
	int ret = 0;

	printf("before running: uid: %d, euid: %d\n", getuid(), geteuid());

	/* the result of setreuid(-1, 1000) is different with setreuid(1000, 1000) */
	/* when use setreuid(-1, 1000), the ruid is not set, the saved user-id will be unchanged.
	 * so seteuid(6) will succeed.
	 */
	/* when use setreuid(1000, 1000), the ruid is set even it is unchanged, the saved user-id will
	 * be changed to 1000 (the new effective uid), so seteuid(6) will fail.
	 */
	ret = setreuid(1000, 1000);
	if (ret != 0) {
		err_sys("setreuid error");
	}

	printf("after setreuid: uid: %d, euid: %d\n", getuid(), geteuid());

	ret = seteuid(6);
	if (ret != 0) {
		err_sys("seteuid error");
	}

	printf("after seteuid: uid: %d, euid: %d\n", getuid(), geteuid());

	return 0;
}
