#include "apue.h"

int main(int argc, char **argv)
{
	fclose(stdout);
	if (write(STDOUT_FILENO, "a", 1) != 1) {
		err_sys("write %d fail", STDOUT_FILENO);
	}

	return 0;
}
