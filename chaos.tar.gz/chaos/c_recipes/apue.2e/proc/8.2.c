#include "apue.h"

static int spawn_a_child(void)
{
	pid_t pid;

	if ((pid = vfork()) < 0) {
		err_sys("vfork error");
	} else if (pid == 0) {
		/* child */
		return 1;
	} else {
		/* parent */
		return 0;
	}
}

int main(int argc, char **argv)
{
	int ret;

	ret = spawn_a_child();
	printf("return %d\n", ret);

	return 0;
}

