#include "apue.h"

int main(int argc, char **argv)
{
	printf("system(NULL) return %d\n", system(NULL));
	return 0;
}

