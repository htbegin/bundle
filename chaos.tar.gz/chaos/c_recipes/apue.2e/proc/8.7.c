#include "apue.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>

static void pr_close_on_exec_flag(const char *name, int fd)
{
	int ret = 0;

	ret = fcntl(fd, F_GETFD);
	if (ret != -1) {
		const char *flag = NULL;

		if (ret & FD_CLOEXEC) {
			flag = "on";
		} else {
			flag = "off";
		}
		printf("for %s: close-on-exec flag is %s\n", name, flag);
	} else {
		err_sys("fcntl %d error", fd);
	}
}

static void test_open(const char *dir)
{
	int fd = open(dir, O_RDONLY);

	if (fd >= 0) {
		pr_close_on_exec_flag("open", fd);
		close(fd);
	} else {
		err_sys("open %s error", dir);
	}
}

static void test_open_dir(const char *dir)
{
	DIR *dir_desc = NULL;
	int fd = 0;

	dir_desc = opendir(dir);
	if (dir_desc != NULL) {
		fd = dirfd(dir_desc);
		if (fd >= 0) {
			pr_close_on_exec_flag("opendir", fd);
		} else {
			err_sys("dirfd %s error", dir);
		}
		closedir(dir_desc);
	} else {
		err_sys("opendir %s error", dir);
	}
}

int main(int argc, char **argv)
{
	const char *dir = "/";

	test_open_dir(dir);
	test_open(dir);

	return 0;
}

