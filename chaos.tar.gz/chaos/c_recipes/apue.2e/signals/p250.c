#include "apue.h"

static void handle_child_exit(int signum)
{
	printf("reap the terminated child before setup signal handler\n");
}

int main(int argc, char **argv)
{
	pid_t pid = 0;
	Sigfunc *ret = NULL;
	char cmd[256] = {0};

	pid = fork();
	if (pid > 0) {
		printf("wait child %d to exit\n", pid);
		sleep(5);

		snprintf(cmd, sizeof(cmd), "ps -p %d -o pid,ppid,stat,cmd", pid);
		system(cmd);

		ret = signal(SIGCHLD, handle_child_exit);
		if (ret == SIG_ERR) {
			err_sys("signal error");
		}
		pause();
	} else if (pid < 0) {
		err_sys("fork error");
	}

	return 0;
}
