#include "apue.h"

enum sigcont_action
{
	ACTION_CAPTURE_CONT,
	ACTION_CAPTURE_EXIT,
	ACTION_IGNORE,
	ACTION_DEFAULT,
	ACTION_BLOCK,
};

static const char *action_str[] = {
	"capture SIGCONT signal and continue",
	"capture SIGCONT signal and exit",
	"ignore SIGCONT signal",
	"default handler for SIGCONT signal",
	"block SIGCONT signal",
};

static void handle_signal_and_cont(int signum)
{
}

static void handle_signal_and_exit(int signum)
{
	exit(0);
}

static int is_invalid_action(enum sigcont_action action)
{
	if (ACTION_CAPTURE_CONT <= action && action <= ACTION_BLOCK) {
		return 1;
	} else {
		return 0;
	}
}

int main(int argc, char **argv)
{
	enum sigcont_action action = ACTION_CAPTURE_CONT;
	const char *str = action_str[action];

	if (argc == 2) {
		action = atoi(argv[1]);
		if (!is_invalid_action(action)) {
			action = ACTION_CAPTURE_CONT;
		}
		str = action_str[action];
	}

	printf("action: %s\n", str);

	switch (action) {
		case ACTION_CAPTURE_CONT:
			signal(SIGCONT, handle_signal_and_cont);
			break;
		case ACTION_CAPTURE_EXIT:
			signal(SIGCONT, handle_signal_and_exit);
			break;
		case ACTION_IGNORE:
			signal(SIGCONT, SIG_IGN);
			break;
		case ACTION_DEFAULT:
			signal(SIGCONT, SIG_DFL);
			break;
		case ACTION_BLOCK:
		{
			sigset_t block_set;
			int ret;

			sigemptyset(&block_set);
			sigaddset(&block_set, SIGCONT);
			ret = sigprocmask(SIG_BLOCK, &block_set, NULL);
			if (ret < 0) {
				err_sys("sigprocmask error");
			}

			break;
		}
	}

	pr_mask("befor stop, block ");
	raise(SIGSTOP);
	pr_mask("after continue, block ");

	return 0;
}
