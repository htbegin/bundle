#include "apue.h"

#define OUTPUT_LENGTH (1024 * 1024 * 1024)

static void handle_signal(int signum)
{
	printf("handle SIGALRM\n");
}

int main(int argc, char **argv)
{
	const char *fname = "timestamp";
	FILE *output = NULL;
	const size_t length = OUTPUT_LENGTH;
	char *content = NULL;

	output = fopen(fname, "w");
	if (output == NULL) {
		err_sys("fopen %s error", fname);
	}

	content = calloc(1, length);
	if (content == NULL) {
		err_sys("calloc %u bytes fail", length);
	}

	memset(content, 0xA5, length);

	if (signal_intr(SIGALRM, handle_signal) == SIG_ERR) {
		err_sys("signal error");
	}

	alarm(1);

	if (usleep(900000) != 0) {
		err_sys("usleep error");
	}

	if (fwrite(content, length, 1, output) != 1) {
		if (ferror(output)) {
			err_sys("fwrite error");
		}
	}

	free(content);
	fclose(output);

	exit(0);
}
