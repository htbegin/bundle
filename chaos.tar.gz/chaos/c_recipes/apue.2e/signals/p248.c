#include "apue.h"

#include <sys/types.h>
#include <sys/wait.h>

enum sigchild_action
{
	SIGNAL_NONE,
	SIGNAL_IGN,
	SIGNAL_DFT,
	SIGACTION_DFT_NOCLDWAIT,
};

static void register_signal_handler(Sigfunc *handler)
{
	Sigfunc *ret = signal(SIGCHLD, handler);
	if (ret == SIG_ERR) {
		err_sys("signal error");
	}
}

static void register_sigaction_handler(Sigfunc *handler, int flags)
{
	struct sigaction action;
	int ret = 0;

	memset(&action, 0, sizeof(action));
	action.sa_handler = handler;
	action.sa_flags = flags;

	ret = sigaction(SIGCHLD, &action, NULL);
	if (ret != 0) {
		err_sys("sigaction error");
	}
}

static void setup_signal_action(enum sigchild_action action)
{
	switch (action) {
		case SIGNAL_NONE:
			break;
		case SIGNAL_IGN:
			register_signal_handler(SIG_IGN);
			break;
		case SIGNAL_DFT:
			register_signal_handler(SIG_DFL);
			break;
		case SIGACTION_DFT_NOCLDWAIT:
			register_sigaction_handler(SIG_DFL, SA_NOCLDWAIT);
			break;
	}
}

int main(int argc, char **argv)
{
	enum sigchild_action action = SIGNAL_NONE;
	pid_t pid = 0;
	char cmd[256] = {0};

	if (argc == 2) {
		action = atoi(argv[1]);
	} else {
		printf("Usage: %s [0|1|2|3]\n"
				"0: no signal disposition for SIGCHLD\n"
				"1: use ignore signal disposition for SIGCHLD\n"
				"2: use default signal disposition for SIGCHLD\n"
				"3: use SA_NOCLDWAIT flag in sigaction for SIGCHLD\n",
				argv[0]);
		exit(1);
	}

	setup_signal_action(action);

	pid = fork();
	if (pid > 0) {
		int status = 0;

		printf("wait child %d to exit\n", pid);
		sleep(5);
		snprintf(cmd, sizeof(cmd), "ps -p %d -o pid,ppid,stat,cmd", pid);
		system(cmd);
		pid = wait(&status);
		if (pid != -1) {
			printf("wait pid: %d and its status: %d\n", pid, status);
		} else {
			err_sys("wait error");
		}
	} else if (pid < 0) {
		err_sys("fork error");
	}

	return 0;
}
