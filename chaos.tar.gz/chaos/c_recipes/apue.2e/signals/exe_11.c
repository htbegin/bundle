#include "apue.h"

#include <sys/time.h>
#include <sys/resource.h>

#define	BUFFSIZE	100

static void handle_signal(int signum)
{
	err_msg("handle SIGXFSZ");
}

static void pr_fsize_limit(struct rlimit *limit)
{
	char metric[64];

	memset(metric, 0, sizeof(metric));
	if (limit->rlim_cur == RLIM_INFINITY) {
		snprintf(metric, sizeof(metric), "%s", "infinite");
	} else {
		snprintf(metric, sizeof(metric), "%lu", limit->rlim_cur);
	}
	err_msg("current soft file size limit is %s", metric);

	memset(metric, 0, sizeof(metric));
	if (limit->rlim_max == RLIM_INFINITY) {
		snprintf(metric, sizeof(metric), "%s", "infinite");
	} else {
		snprintf(metric, sizeof(metric), "%lu", limit->rlim_max);
	}
	err_msg("current hard file size limit is %s", metric);
}

int main(int argc, char **argv)
{
	int     ret;
	struct rlimit limit;
	int		n;
	char	buf[BUFFSIZE];

	if (signal_intr(SIGXFSZ, handle_signal) == SIG_ERR) {
		err_sys("signal_intr error");
	}

	ret = getrlimit(RLIMIT_FSIZE, &limit);
	if (ret == 0) {
		pr_fsize_limit(&limit);
	} else {
		err_sys("getrlimit error");
	}

	limit.rlim_cur = 1024;
	ret = setrlimit(RLIMIT_FSIZE, &limit);
	if (ret != 0) {
		err_sys("setrlimit fail");
	}
	pr_fsize_limit(&limit);

	while ((n = read(STDIN_FILENO, buf, BUFFSIZE)) > 0) {
		ret = write(STDOUT_FILENO, buf, n);
		if (ret != n) {
			if (ret >= 0) {
				err_msg("incomplete write: %d/%d", ret, n);
			} else {
				err_sys("write error");
			}
		}
	}

	if (n < 0) {
		err_sys("read error");
	}

	exit(0);
}
