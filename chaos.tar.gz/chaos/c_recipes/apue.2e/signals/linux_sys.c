#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

static void
sig_int(int signo)
{
	printf("caught SIGINT\n");
}

static void
sig_chld(int signo)
{
	pid_t pid = 0;
	int status = 0;

	printf("caught SIGCHLD\n");

	pid = wait(&status);
	if (pid != -1) {
		printf("child %d, status %d\n", pid, status);
	} else {
		perror("wait error");
	}
}

int
main(void)
{
	if (signal(SIGINT, sig_int) == SIG_ERR)
		perror("signal(SIGINT) error");
	if (signal(SIGCHLD, sig_chld) == SIG_ERR)
		perror("signal(SIGCHLD) error");
	if (system("/bin/ed") < 0)
		perror("system() error");
	exit(0);
}
