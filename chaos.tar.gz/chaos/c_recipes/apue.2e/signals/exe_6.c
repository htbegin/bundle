#include "apue.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

extern void TELL_WAIT_INIT(void);
extern void TELL_WAIT_FINAL(void);

static void increase_timestamp(int is_parent, pid_t pid, int fd, int cnt)
{
	const char *relation = NULL;
	int idx = 0;
	int value = 0;
	int ret = 0;

	if (is_parent) {
		relation = "parent";
	} else {
		relation = "child";
	}

	for (idx = 0; idx < cnt; ++idx) {
		if (is_parent) {
			WAIT_CHILD();
		}

		ret = pread(fd, &value, sizeof(value), 0);
		if (ret != sizeof(value)) {
			err_sys("pread error");
		}
		printf("%s read %d\n", relation, value);

		value += 1;
		ret = pwrite(fd, &value, sizeof(value), 0);
		if (ret != sizeof(value)) {
			err_sys("pwrite error");
		}
		printf("%s write %d\n", relation, value);

		if (!is_parent) {
			TELL_PARENT(pid);
			WAIT_PARENT();
		} else {
			TELL_CHILD(pid);
		}
	}
}

int main(int argc, char **argv)
{
	const char *fname = "timestamp";
	int fd = 0;
	int value = 0;
	int ret = 0;
	pid_t pid = 0;
	int loop_cnt = 10;

	fd = open(fname, O_RDWR | O_TRUNC | O_CREAT, 0644);
	if (fd < 0) {
		err_sys("create %s error", fname);
	}

	ret = write(fd, &value, sizeof(value));
	if (ret != sizeof(value)) {
		err_sys("write %s error", fname);
	}

	TELL_WAIT_INIT();

	pid = fork();
	if (pid > 0) {
		increase_timestamp(1, pid, fd, loop_cnt);
	} else if (pid == 0) {
		increase_timestamp(0, getppid(), fd, loop_cnt);
	} else {
		err_sys("fork error");
	}

	TELL_WAIT_FINAL();

	return 0;
}
