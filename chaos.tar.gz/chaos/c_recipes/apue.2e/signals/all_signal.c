#include "apue.h"

int main(int argc, char **argv)
{
	const char *str = NULL;
	int sig = 1;
	int cnt = NSIG;

	while (sig < cnt) {
		str = strsignal(sig);
		printf("%d: %s\n", sig, str);
		++sig;
	}

	if (SIGPOLL == SIGIO) {
		printf("\nSIGPOLL equals SIGIO\n");
	} else {
		printf("\nSIGPOLL doesn't equal SIGIO\n");
	}

	return 0;
}
