#include "apue.h"
#include <time.h>

int main(int argc, char **argv)
{
	time_t sec = 0;
	struct tm *tm = NULL;
	char buf[MAXLINE] = {0};

	sec = time(NULL);
	tm = localtime(&sec);
	/* Sun Oct 16 22:41:56 CST 2011 */
	strftime(buf, sizeof(buf), "%a %b %d %H:%M:%S %Z %Y\n", tm);
	printf("%s", buf);

	return 0;
}
