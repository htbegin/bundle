#!/bin/bash

echo "unset TZ"
unset TZ
./6.5
echo

export TZ=GMT0
echo "TZ is $TZ"
./6.5
echo

export TZ=GMT+8
echo "TZ is $TZ"
./6.5
echo

export TZ=GMT-8
echo "TZ is $TZ"
./6.5
