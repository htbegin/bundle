#include "apue.h"
#include <time.h>

static void display_utc_time(time_t sec)
{
	const struct tm *time = NULL;

	time = gmtime(&sec);
	printf("%04d-%02d-%02d %02d:%02d:%02d\n",
			time->tm_year + 1900, time->tm_mon + 1, time->tm_mday,
			time->tm_hour, time->tm_min, time->tm_sec);
}

int main(int argc, char **argv)
{
	time_t last_sec = ((1 << 30) + ((1 << 30) - 1));

	display_utc_time(last_sec);

	last_sec = 0x80000000;
	display_utc_time(last_sec);

	last_sec = 0;
	display_utc_time(last_sec);

	last_sec = 0xffffffff;
	display_utc_time(last_sec);

	return 0;
}
