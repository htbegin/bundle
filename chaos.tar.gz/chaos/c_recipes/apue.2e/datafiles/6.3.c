#include "apue.h"
#include <sys/utsname.h>

int main(int argc, char **argv)
{
	struct utsname buf;

	memset(&buf, 0, sizeof(buf));

	if (uname(&buf) == 0) {
		printf("sysname: %s\n", buf.sysname);
		printf("nodename: %s\n", buf.nodename);
		printf("release: %s\n", buf.release);
		printf("version: %s\n", buf.version);
		printf("machine: %s\n", buf.machine);
#ifdef _GNU_SOURCE
		printf("domainname: %s\n", buf.domainname);
#endif /* _GNU_SOURCE */
	} else {
		err_sys("uname fail");
	}

	return 0;
}
