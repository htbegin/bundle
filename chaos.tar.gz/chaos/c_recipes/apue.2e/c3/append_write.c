#include "apue.h"
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char **argv)
{
	if (argc != 4) {
		err_quit("Usage: %s fname cnt character", argv[0]);
	}

	const char *fname = argv[1];
	int cnt = atoi(argv[2]);
	int val = atoi(argv[3]);
	int fd = 0;
	char *buf = NULL;
	int ret;

	fd = open(fname, O_WRONLY | O_APPEND);
	if (fd < 0) {
		err_sys("open %s fail", fname);
	}

	if (cnt <= 0 || val < 0) {
		err_quit("invalid \"cnt\" or \"character\"");
	}

	cnt += 1;

	buf = calloc(1, cnt);
	if (buf == NULL) {
		err_sys("calloc %d byte fail", cnt);
	}
	memset(buf, val, cnt);
	buf[cnt - 1] = '\n';

	while (1) {
		ret = write(fd, buf, cnt);
		if (ret != cnt) {
			err_sys("write %d byte to %s with fd %d fail", cnt, fname, fd);
		}
		usleep(1000);
	}

	return 0;
}
