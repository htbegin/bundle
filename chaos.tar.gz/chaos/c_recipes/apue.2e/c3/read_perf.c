#include "apue.h"

int main(int argc, char **argv)
{
	if (argc != 2) {
		err_quit("Usage: %s buf_size\n"
				"buf_size: must belongs to [1, 512]",
				argv[0]);
	}

	int buf_size = atoi(argv[1]);

	if (buf_size < 1 || buf_size > 512) {
		err_quit("invalid buf_size");
	}

	buf_size <<= 10;

	char *buf = NULL;
	int	n;

	buf = calloc(1, buf_size);
	if (buf == NULL) {
		err_sys("calloc %d KB fail", buf_size >> 10);
	}

	while ((n = read(STDIN_FILENO, buf, buf_size)) > 0) {
		if (write(STDOUT_FILENO, buf, n) != n) {
			free(buf);
			err_sys("write error");
		}
	}

	if (n < 0) {
		free(buf);
		err_sys("read error");
	}

	free(buf);

	exit(0);
}
