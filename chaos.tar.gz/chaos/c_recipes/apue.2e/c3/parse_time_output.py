#!/usr/bin/env python
# -*- coding: utf8 -*-

import sys
import re

def inc_time(num, line, times):
    parts = line.split()
    if len(parts) != 2:
        sys.stderr.write("invalid line %d\n" % num)
        sys.exit(1)

    time_str = parts[1].strip()
    result = re.search(r"(?P<min>\d+(?:\.\d+)?)m(?P<sec>\d+(?:\.\d+)?)s", time_str)
    if result is not None:
        min = float(result.group("min"))
        sec = float(result.group("sec"))
        time = "%.3f" % (min * 60 + sec)
        times.append(time)
    else:
        sys.stderr.write("invalid line %d\n" % num)
        sys.exit(1)

def output_times(real_times, user_times, sys_times):
    all_times = zip(real_times, user_times, sys_times)
    idx = 1
    sys.stdout.write("# KB real user sys\n")
    for all_time in all_times:
        real_t, user_t, sys_t = all_time
        sys.stdout.write("%d %s %s %s\n" % (idx, real_t, user_t, sys_t))
        idx <<= 1

def parse_time_output():
    real_times = []
    user_times = []
    sys_times = []

    line_num = 0
    for line in sys.stdin:
        line_num += 1
        line = line.strip()
        if line.startswith("real"):
            dst_times = real_times
        elif line.startswith("user"):
            dst_times = user_times
        elif line.startswith("sys"):
            dst_times = sys_times
        else:
            continue

        inc_time(line_num, line, dst_times)

    if len(real_times) != len(user_times) or len(user_times) != len(sys_times):
        sys.stderr.write("invalid input, un-matched real/user/sys times\n")
        sys.exit(1)

    output_times(real_times, user_times, sys_times)

if __name__ == "__main__":
    parse_time_output()
    sys.exit(0)
