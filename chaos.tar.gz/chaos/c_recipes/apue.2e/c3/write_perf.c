#include "apue.h"
#include <assert.h>
#include <sys/stat.h>
#include <fcntl.h>

#define STRATEGIES_BUF_LEN (512)
#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
#define BUF_LEN_MIN (4)
#define BUF_LEN_MAX (512)

enum
{
	CMD_IDX,
	INPUT_FNAME_IDX,
	OUTPUT_FNAME_IDX,
	BUF_LEN_IDX,
	STRATEGY_IDX,
	LAST_IDX_PLUS_ONE,
};

enum write_strategy
{
	WRITE_STRATEGY_NORMAL,
	WRITE_STRATEGY_SYNC_OPEN,
	WRITE_STRATEGY_POST_FDATASYNC,
	WRITE_STRATEGY_POST_FSYNC,
	WRITE_STRAGEGY_HYBRID_SYNC_OPEN_POST_FSYNC,
};

struct strategy_action_ctx {
	const char *input_fname;
	const char *output_fname;
	int input_fd;
	int output_fd;
	char *buf;
	size_t buf_len;
};

typedef int (*strategy_action_t)(const struct strategy_action_ctx *ctx);

int log_to_stderr = 1;

static const char *strategy_strs[] = {
	[WRITE_STRATEGY_NORMAL] = "normal",
	[WRITE_STRATEGY_SYNC_OPEN]= "sync_open",
	[WRITE_STRATEGY_POST_FDATASYNC] = "post_fdatasync",
	[WRITE_STRATEGY_POST_FSYNC] = "post_fsync",
	[WRITE_STRAGEGY_HYBRID_SYNC_OPEN_POST_FSYNC] = "hybrid_sync_open_post_fsync",
};

static int normal_write(const struct strategy_action_ctx *ctx);
static int sync_open_write(const struct strategy_action_ctx *ctx);
static int post_fdatasync_write(const struct strategy_action_ctx *ctx);
static int post_fsync_write(const struct strategy_action_ctx *ctx);
static int hybrid_sync_open_post_fsync_write(const struct strategy_action_ctx *ctx);

static const strategy_action_t strategy_actions[] = {
	[WRITE_STRATEGY_NORMAL] = normal_write,
	[WRITE_STRATEGY_SYNC_OPEN]= sync_open_write,
	[WRITE_STRATEGY_POST_FDATASYNC] = post_fdatasync_write,
	[WRITE_STRATEGY_POST_FSYNC] = post_fsync_write,
	[WRITE_STRAGEGY_HYBRID_SYNC_OPEN_POST_FSYNC] =
		hybrid_sync_open_post_fsync_write,
};

static void concatenate_all_strategies(char *buf, int len, const char *join)
{
	int idx = 0;
	int cnt = ARRAY_SIZE(strategy_strs);
	char *dst = buf;
	int left_len = len;
	int advance = 0;
	int join_len = strlen(join);

	memset(dst, '\0', left_len);

	for (; idx < cnt && left_len > 1; ++idx) {
		strncat(dst, strategy_strs[idx], left_len - 1);

		advance = strlen(strategy_strs[idx]);
		dst += advance;
		left_len -= advance;

		if (idx != cnt - 1 && left_len > 1) {
			strncat(dst, join, left_len - 1);
			dst += join_len;
			left_len -= join_len;
		}
	}

	if (!(idx == cnt && left_len >= 1)) {
		err_quit("buffer len %d for strategies is too small", len);
	}
}

static strategy_action_t get_strategy_action(const char *strategy)
{
	int idx = 0;
	int str_cnt = ARRAY_SIZE(strategy_strs);
	int action_cnt = ARRAY_SIZE(strategy_actions);
	strategy_action_t action = NULL;

	assert(str_cnt == action_cnt);

	for (; idx < str_cnt; ++idx) {
		if (strcmp(strategy, strategy_strs[idx]) == 0) {
			action = strategy_actions[idx];
			break;
		}
	}

	return action;
}

static int normal_write(const struct strategy_action_ctx *ctx)
{
	int ret = 0;
	int n = 0;

	while ((n = read(ctx->input_fd, ctx->buf, ctx->buf_len)) > 0) {
		if (write(ctx->output_fd, ctx->buf, n) != n) {
			err_ret("write %s with fd %d fail",
					ctx->output_fname, ctx->output_fd);
			ret = 1;
			break;
		}
	}

	if (n < 0) {
		err_ret("read %s with fd %d fail",
				ctx->input_fname, ctx->input_fd);
		ret = 1;
	}

	return ret;
}

static int sync_open_write(const struct strategy_action_ctx *ctx)
{
	int ret = 0;

	set_fl(ctx->output_fd, O_SYNC);

	ret = normal_write(ctx);

	return ret;
}

static int post_fdatasync_write(const struct strategy_action_ctx *ctx)
{
	int ret = 0;

	ret = normal_write(ctx);
	if (ret == 0) {
		if (fdatasync(ctx->output_fd) < 0) {
			err_ret("fdatasync %s with fd %d fail",
					ctx->output_fname, ctx->output_fd);
			ret = 1;
		}
	}

	return ret;
}

static int post_fsync_write(const struct strategy_action_ctx *ctx)
{
	int ret = 0;

	ret = normal_write(ctx);
	if (ret == 0) {
		if (fsync(ctx->output_fd) < 0) {
			err_ret("fsync %s with fd %d fail",
					ctx->output_fname, ctx->output_fd);
			ret = 1;
		}
	}

	return ret;
}

static int hybrid_sync_open_post_fsync_write(const struct strategy_action_ctx *ctx)
{
	int ret = 0;

	set_fl(ctx->output_fd, O_SYNC);

	ret = post_fsync_write(ctx);

	return ret;
}

int main(int argc, char **argv)
{
	if (argc != LAST_IDX_PLUS_ONE) {
		char strategies[STRATEGIES_BUF_LEN] = {0};

		concatenate_all_strategies(strategies, sizeof(strategies), "|");

		err_quit("Usage: %s input output buf_len strategy\n"
				"input: input file name\n"
				"output: output file name\n"
				"buf_len: must belong to [%d, %d], its unit is KB\n"
				"strategy: %s",
				argv[CMD_IDX], BUF_LEN_MIN, BUF_LEN_MAX, strategies);
	}

	int input_fd = open(argv[INPUT_FNAME_IDX], O_RDONLY);
	int output_fd = creat(argv[OUTPUT_FNAME_IDX],
			S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
	size_t buf_len = atoi(argv[BUF_LEN_IDX]);
	char *buf = NULL;
	strategy_action_t action = get_strategy_action(argv[STRATEGY_IDX]);
	struct strategy_action_ctx context = {0};
	int ret = 0;

	if (input_fd < 0) {
		err_sys("invalid input file name %s", argv[INPUT_FNAME_IDX]);
	}

	if (output_fd < 0) {
		err_sys("invalid output file name %s", argv[OUTPUT_FNAME_IDX]);
	}

	if (buf_len < BUF_LEN_MIN || BUF_LEN_MAX < buf_len) {
		err_sys("invalid buf_len %s", argv[BUF_LEN_IDX]);
	}

	buf_len <<= 10;
	buf = calloc(1, buf_len);
	if (buf == NULL) {
		err_sys("calloc %dKB rw buffer fail", buf_len >> 10);
	}

	if (action == NULL) {
		err_sys("invalid strategy %s", argv[STRATEGY_IDX]);
	}

	log_msg("input_fd: %d, output_fd: %d, buf_len: %uKB, strategy: %s",
			input_fd, output_fd, buf_len >> 10, argv[STRATEGY_IDX]);

	context.input_fname = argv[INPUT_FNAME_IDX];
	context.output_fname = argv[OUTPUT_FNAME_IDX];
	context.input_fd = input_fd;
	context.output_fd = output_fd;
	context.buf = buf;
	context.buf_len = buf_len;

	ret = action(&context);

	free(buf);
	close(output_fd);
	close(input_fd);

	return ret;
}
