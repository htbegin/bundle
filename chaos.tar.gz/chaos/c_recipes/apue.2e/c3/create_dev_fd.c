#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char **argv)
{
	if (argc != 3) {
		fprintf(stderr, "Usage: %s fd mode\n"
				"fd: must be greater than 0\n"
				"mode: must be read, write or rw\n",
				argv[0]);
		exit(1);
	}

	int input_fd = atoi(argv[1]);
	const char *input_mode = argv[2];
	char fpath[256] = {0};
	mode_t fmode = 0;

	if (input_fd >= 0) {
		snprintf(fpath, sizeof(fpath) - 1, "/dev/fd/%d", input_fd);
	} else {
		fprintf(stderr, "invalid fd %d\n", input_fd);
		exit(1);
	}

	if (strcmp(input_mode, "read") == 0) {
		fmode = O_RDONLY;
	} else if (strcmp(input_mode, "write") == 0) {
		fmode = O_WRONLY;
	} else if (strcmp(input_mode, "rw") == 0) {
		fmode = O_RDWR;
	} else {
		fprintf(stderr, "invalid mode %s\n", input_mode);
		exit(1);
	}

	int fd = creat(fpath, fmode);
	if (fd >= 0) {
		fprintf(stdout, "create %s under mode %s, get fd %d\n",
				fpath, input_mode, fd);
	} else {
		fprintf(stderr, "create %s under mode %s fail, error-%s\n",
				fpath, input_mode, strerror(errno));
		exit(1);
	}

	return 0;
}

