#!/bin/bash

input_fname=perf_input
input_fsize=200
output_fname_prefix=perf_output
buf_len=4
strategy_list="normal sync_open post_fdatasync post_fsync hybrid_sync_open_post_fsync"

if ! test -f $input_fname
then
	dd if=/dev/zero of=$input_fname bs=1M count=$input_fsize oflag=sync
fi

idx=1
for strategy in $strategy_list
do
	output_fname=$output_fname_prefix.$idx
	# free pagecache, dentries and inodes
	sudo bash -c 'echo 3 > /proc/sys/vm/drop_caches'
	time ./write_perf $input_fname $output_fname $buf_len $strategy
	rm -f $output_fname
	let idx+=1
done
