#include "apue.h"
#include <sys/stat.h>
#include <fcntl.h>

int log_to_stderr = 1;

static void seek_read(const char *fname, int fd, off_t offset, off_t fsize)
{
	int ret;
	char val;

	if (offset >= fsize) {
		log_msg("offset %d is out-of-range, file size is %d", offset, fsize);
	}

	ret = lseek(fd, 0, SEEK_CUR);
	log_msg("current offset of %s with fd %d is %d", fname, fd, ret);

	ret = lseek(fd, offset, SEEK_SET);
	if (ret < 0) {
		err_sys("lseek %s with fd %d to %d fail", fname, fd, offset);
	}

	ret = read(fd, &val, 1);
	if (ret == 1) {
		log_msg("read %s with fd %d in offset %d get %c", fname, fd, offset, val);
	} else if (ret == 0) {
		log_msg("read %s with fd %d EOFed", fname, fd);
	} else {
		err_sys("read %s with fd %d fail", fname, fd);
	}
}

static void seek_write(const char *fname, int fd, off_t offset, off_t fsize)
{
	int ret;
	char val = 'a';

	if (offset >= fsize) {
		log_msg("offset %d is out-of-range, file size is %d", offset, fsize);
	}

	ret = lseek(fd, 0, SEEK_CUR);
	log_msg("current offset of %s with fd %d is %d", fname, fd, ret);

	ret = lseek(fd, offset, SEEK_SET);
	if (ret < 0) {
		err_sys("lseek %s with fd %d to %d fail", fname, fd, offset);
	}

	ret = write(fd, &val, 1);
	if (ret == 1) {
		log_msg("write %s with fd %d in offset %d with %c", fname, fd, offset, val);
	} else {
		err_sys("write %s with fd %d fail", fname, fd);
	}
}

int main(int argc, char **argv)
{
	if (argc != 4) {
		err_quit("Usage: %s fname action offset\n"
				"action: must be read or write",
				argv[0]);
	}

	const char *fname = argv[1];
	const char *action = argv[2];
	off_t offset = atoi(argv[3]);
	int fd;
	struct stat info = {0};
	int ret;

	fd = open(fname, O_RDWR | O_APPEND);
	if (fd < 0) {
		err_sys("open %s fail", fname);
	}

	ret = fstat(fd, &info);
	if (ret < 0) {
		err_sys("fstat %s with fd %d fail", fname, fd);
	}

	if (strcmp(action, "read") == 0) {
		seek_read(fname, fd, offset, info.st_size);
	} else if (strcmp(action, "write") == 0) {
		seek_write(fname, fd, offset, info.st_size);
	} else {
		err_exit(1, "invalid action %s", action);
	}

	if (close(fd) < 0) {
		err_sys("close %s with fd %d fail", fname, fd);
	}

	return 0;
}

