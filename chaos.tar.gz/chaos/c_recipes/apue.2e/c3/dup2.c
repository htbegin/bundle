#include "apue.h"
#include <errno.h>

static int apue_dup2(int old_fd, int new_fd)
{
	if (old_fd < 0 || new_fd < 0) {
		errno = EBADF;
		return -1;
	}

	if (old_fd == new_fd) {
		return new_fd;
	}

	int *opened_fds = NULL;
	int fd_idx = 0;
	int cur_fd = -1;
	int ret = -1;

	if (new_fd > 0) {
		opened_fds = calloc(new_fd, sizeof(*opened_fds));
		if (opened_fds == NULL) {
			return -1;
		}
	}

	close(new_fd);

	while (1) {
		cur_fd = dup(old_fd);
		if (cur_fd >= 0) {
			if (cur_fd == new_fd) {
				ret = new_fd;
				break;
			} else if (cur_fd < new_fd) {
				opened_fds[fd_idx++] = cur_fd;
			} else {
				errno = EBADF;
				break;
			}
		} else {
			break;
		}
	}

	while (--fd_idx >=0 ) {
		close(opened_fds[fd_idx]);
	}

	if (new_fd > 0) {
		free(opened_fds);
	}

	system("ls -l /dev/fd/");

	return ret;
}

int main(int argc, char **argv)
{
	if (argc != 3) {
		exit(1);
	}

	int old_fd = atoi(argv[1]);
	int new_fd = atoi(argv[2]);
	int ret = apue_dup2(old_fd, new_fd);

	fprintf(stdout, "dup %d to %d, get %d\n", old_fd, new_fd, ret);

	return 0;
}

