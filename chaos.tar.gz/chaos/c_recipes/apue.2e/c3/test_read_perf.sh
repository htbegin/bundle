#!/bin/bash

input_fname=perf_input
input_fsize=200
size_list="1 2 4 8 16 32 64 128 256 512"

if test "$#" -gt 0
then
	size_list=$@
fi

if ! test -f $input_fname
then
	dd if=/dev/zero of=$input_fname bs=1M count=$input_fsize oflag=sync
fi

sync
# free pagecache, dentries and inodes
sudo bash -c 'echo 3 > /proc/sys/vm/drop_caches'

for size in $size_list
do
	time ./read_perf $size <$input_fname >/dev/null
	sudo bash -c 'echo 3 > /proc/sys/vm/drop_caches'
done
