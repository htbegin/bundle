#include "apue.h"
#include <errno.h>
#include <pthread.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define	SHM_MODE	0600	/* user read/write */

struct shared_info
{
	int shmid;
	pthread_mutex_t lock;
	int first_cnt;
	int sec_cnt;
};

static int is_process_shared_mutex_supported(void)
{
	int support = 0;

#ifdef _POSIX_THREAD_PROCESS_SHARED
	printf("static: support process shared pthread mutex\n");
	support = 1;
#else
	long ret = 0;

	errno = 0;
	ret = sysconf(_SC_THREAD_PROCESS_SHARED);
	if (ret >= 0)
	{
		printf("dynamic: support process shared pthread mutex\n");
		support = 1;
	}
	else if (errno == 0)
	{
		printf("dynamic: not support process shared pthread mutex\n");
	}
	else
	{
		err_sys("sysconf fail");
	}
#endif

	return support;
}

static int init_pshared_mutex(pthread_mutex_t *lock)
{
	int ret = 0;
	pthread_mutexattr_t attr;

	ret = pthread_mutexattr_init(&attr);
	if (ret == 0)
	{
		ret = pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED);
		if (ret == 0)
		{
			ret = pthread_mutex_init(lock, &attr);
			if (ret != 0)
			{
				err_sys("pthread_mutex_init fail");
			}
		}
		else
		{
			err_sys("pthread_mutexattr_setpshared fail");
		}
	}
	else
	{
		err_sys("pthread_mutexattr_init fail");
	}

	return ret;
}

static struct shared_info *init_shared_info(void)
{
	int shmid = 0;
	size_t mem_size = sizeof(struct shared_info);
	struct shared_info *info = NULL;

	shmid = shmget(IPC_PRIVATE, mem_size, SHM_MODE);
	if (shmid >= 0)
	{
		/* attached for read and write */
		info = shmat(shmid, 0, 0);
		if (info != (struct shared_info *)-1)
		{
			if (init_pshared_mutex(&info->lock) == 0)
			{
				info->shmid = shmid;
				info->first_cnt = 0;
				info->sec_cnt = 0;
			}
		}
		else
		{
			err_sys("shmat fail");
		}
	}
	else
	{
		err_sys("shmget fail");
	}

	return info;
}

static void final_shared_info(struct shared_info *info)
{
	int shmid = info->shmid;

	shmdt(info);
	if (shmctl(shmid, IPC_RMID, NULL) != 0)
	{
		err_sys("remove shmid failed");
	}
}

static void repeat_inc(struct shared_info *info, int repeat, int f_inc, int s_inc)
{
	int i = 0;

	for (i = 0; i < repeat; i++)
	{
		pthread_mutex_lock(&info->lock);
		info->first_cnt += f_inc;
		info->sec_cnt += s_inc;
		pthread_mutex_unlock(&info->lock);
	}
}

static void print_cnt(struct shared_info *info)
{
	printf("first cnt %d\n", info->first_cnt);
	printf("sec cnt %d\n", info->sec_cnt);
}

int main(int argc, char **argv)
{
	if (is_process_shared_mutex_supported())
	{
		struct shared_info *info = init_shared_info();
		pid_t pid;

		pid = fork();
		if (pid > 0)
		{
			repeat_inc(info, 100000, 7, 300);
			waitpid(pid, NULL, 0);
			print_cnt(info);
			final_shared_info(info);
		}
		else if (pid == 0)
		{
			repeat_inc(info, 100000, 300, 7);
		}
		else
		{
			err_sys("fork failed");
		}
	}

	return 0;
}
