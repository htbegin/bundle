#include "apue.h"
#include <sys/wait.h>

#define	PAGER	"${PAGER:-more}" /* environment variable, or default */

int
main(int argc, char *argv[])
{
	FILE	*cmd;
	char	line[MAXLINE];
	int     rval;

	if ((cmd = popen("/bin/sleep 20", "r")) == NULL)
		err_sys("popen failed");

	while (fgets(line, MAXLINE, cmd) != NULL) {
	}

	if (ferror(cmd))
		err_sys("fgets from pipe failed");

	rval = pclose(cmd);
	if (rval != -1)
	{
		pr_exit(rval);
	}
	else
	{
		err_sys("pclose failed");
	}

	exit(0);
}
