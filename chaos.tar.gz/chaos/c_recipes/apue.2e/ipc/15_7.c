#include "apue.h"
#include <errno.h>
#include <poll.h>
#include <sys/wait.h>

#define PIPE_RIDX 0
#define PIPE_WIDX 1

static int read_from_fd(int fd)
{
	int rval = 0;
	char line[MAXLINE];

	rval = read(fd, line, MAXLINE);
	if (rval > 0)
	{
		err_msg("pipe readable");
	}
	else if (rval == 0)
	{
		err_msg("pipe read EOF");
	}
	else if (rval < 0)
	{
		err_ret("pipe read failed");
	}

	return rval;
}

static int write_to_fd(int fd)
{
	int rval = 0;

	rval = write(fd, "0", 1);
	if (rval == 1)
	{
		err_msg("pipe writable");
	}
	else if (rval == 0)
	{
		err_msg("pipe Not writable");
	}
	else
	{
		err_ret("pipe write failed");
	}

	return rval;
}

static void rw_from_pipe_by_select(int fd)
{
	fd_set r_set;
	fd_set w_set;
	fd_set e_set;
	int rval = 0;
	int exit_flag = 0;

	FD_ZERO(&r_set);
	FD_ZERO(&w_set);
	FD_ZERO(&e_set);

	while (!exit_flag)
	{
		FD_SET(fd, &r_set);
		FD_SET(fd, &w_set);
		FD_SET(fd, &e_set);

		rval = select(fd + 1, &r_set, &w_set, &e_set, NULL);
		if (rval > 0)
		{
			if (FD_ISSET(fd, &r_set))
			{
				FD_CLR(fd, &r_set);

				if (read_from_fd(fd) <= 0)
				{
					exit_flag = 1;
				}
			}

			if (FD_ISSET(fd, &w_set))
			{
				FD_CLR(fd, &w_set);

				if (write_to_fd(fd) < 0)
				{
					exit_flag = 1;
				}	
			}

			if (FD_ISSET(fd, &e_set))
			{
				FD_CLR(fd, &e_set);

				err_msg("pipe exception");
				exit_flag = 1;
			}
		}
		else if (rval == 0)
		{
			continue;
		}
		else
		{
			err_ret("select failed");
			exit_flag = 1;
		}
	}
}

static void rw_from_pipe_by_poll(int fd)
{
	struct pollfd fds[1];
	int rval = 0;
	int exit_flag = 0;
	short events = 0;

	memset(fds, sizeof(fds), 0);
	fds[0].fd = fd;
	fds[0].events = POLLIN | POLLOUT | POLLRDHUP | POLLPRI;

	while (!exit_flag)
	{
		fds[0].revents = 0;

		rval = poll(fds, 1, -1);
		if (rval > 0)
		{
			events = fds[0].revents;
			if (events & POLLIN)
			{
				if (read_from_fd(fd) <= 0)
				{
					exit_flag = 1;
				}
			}
			if (events & POLLOUT)
			{
				if (write_to_fd(fd) < 0)
				{
					exit_flag = 1;
				}
			}
			if (events & POLLPRI)
			{
				err_msg("pipe urgent data readable");
				exit_flag = 1;
			}
			if (events & POLLRDHUP)
			{
				err_msg("pipe stream socket read hang-up");
				exit_flag = 1;
			}
			if (events & POLLHUP)
			{
				err_msg("pipe read hang-up");
				read_from_fd(fd);
				exit_flag = 1;
			}
			if (events & POLLERR)
			{
				err_msg("pipe error");
				exit_flag = 1;
			}
			if (events & POLLNVAL)
			{
				err_msg("pipe invalid");
				exit_flag = 1;
			}
		}
		else if (rval == 0)
		{
			continue;
		}
		else
		{
			err_ret("poll failed");
			exit_flag = 1;
		}
	}
}

static void pwriter_creader(int *pipes, const char *method)
{
	pid_t pid = fork();

	if (pid > 0)
	{
		/* parent as writer */
		close(pipes[PIPE_RIDX]);

		/*write(pipes[PIPE_WIDX], "hello", 5);*/
		close(pipes[PIPE_WIDX]);

		TELL_CHILD(pid);

		waitpid(pid, NULL, 0);
	}
	else if (pid == 0)
	{
		WAIT_PARENT();

		/* child as reader */
		close(pipes[PIPE_WIDX]);

		if (strcmp("select", method) == 0)
		{
			rw_from_pipe_by_select(pipes[PIPE_RIDX]);
		}
		else
		{
			rw_from_pipe_by_poll(pipes[PIPE_RIDX]);
		}

		close(pipes[PIPE_RIDX]);
	}
	else
	{
		err_sys("fork failed");
	}
}

static void preader_cwriter(int *pipes, const char *method)
{
	pid_t pid = fork();

	if (pid > 0)
	{
		/* parent as reader */
		close(pipes[PIPE_WIDX]);

		/* close the read end directly */
		close(pipes[PIPE_RIDX]);

		TELL_CHILD(pid);

		waitpid(pid, NULL, 0);
	}
	else if (pid == 0)
	{
		WAIT_PARENT();

		/* child as writer */
		close(pipes[PIPE_RIDX]);

		if (strcmp("select", method) == 0)
		{
			rw_from_pipe_by_select(pipes[PIPE_WIDX]);
		}
		else
		{
			rw_from_pipe_by_poll(pipes[PIPE_WIDX]);
		}

		close(pipes[PIPE_WIDX]);
	}
	else
	{
		err_sys("fork failed");
	}
}

static void handle_signal(int signum)
{
	printf("caught SIGPIPE\n");
}

int main(int argc, char **argv)
{
	int rval = 0;
	int pipes[2] = {0, 0};
	const char *target = "read";
	const char *method = "select";

	if (argc == 3)
	{
		if (strcmp("read", argv[1]) == 0 || strcmp("write", argv[1]) == 0)
		{
			target = argv[1];
			err_msg("use target %s", target);
		}
		if (strcmp("select", argv[2]) == 0 || strcmp("poll", argv[2]) == 0)
		{
			method = argv[2];
			err_msg("use method %s", method);
		}
	}
	else
	{
		err_msg("use default target %s", target);
		err_msg("use default method %s", method);
	}

	TELL_WAIT();

	if (signal_intr(SIGPIPE, handle_signal) == SIG_ERR)
	{
		err_quit("install signal action failed");
	}

	rval = pipe(pipes);
	if (rval == 0)
	{
		if (strcmp(target, "read") == 0)
		{
			pwriter_creader(pipes, method);
		}
		else
		{
			preader_cwriter(pipes, method);
		}
	}
	else
	{
		err_sys("pipe failed");
	}

	return 0;
}
