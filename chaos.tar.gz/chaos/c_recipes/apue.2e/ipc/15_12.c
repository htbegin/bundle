#include "apue.h"
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct id_msg
{
	long type;
	char id;
};

int main()
{
	int i;
	int cnt;
	int qid = 0;

	for (i = 0, cnt = 5; i < cnt; ++i)
	{
		qid = msgget(IPC_PRIVATE,  0600);
		if (qid != -1)
		{
			err_msg("msg queue id is %d", qid);
			if (msgctl(qid, IPC_RMID, NULL) == -1)
			{
				err_sys("remove msg queue failed");
			}
		}
		else
		{
			err_sys("create msg queue failed");
		}
	}

	for (i = 0, cnt = 5; i < cnt; ++i)
	{
		qid = msgget(IPC_PRIVATE,  0600);
		if (qid != -1)
		{
			struct id_msg msg = {0};

			err_msg("msg queue id is %d", qid);

			msg.type = 1;
			msg.id = i;
			if (msgsnd(qid, &msg, 1, IPC_NOWAIT) == -1)
			{
				err_sys("send msg failed");
			}
		}
		else
		{
			err_sys("create msg queue failed");
		}
	}

	return 0;
}
