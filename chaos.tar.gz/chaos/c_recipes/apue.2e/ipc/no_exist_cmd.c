#include "apue.h"

int main()
{
	FILE *cmd = popen("no_exist", "r");
	int exit_status = 0;

	if (cmd == NULL)
	{
		err_sys("popen failed");
	}

	exit_status = pclose(cmd);
	if (exit_status != -1)
	{
		pr_exit(exit_status);
	}

	return 0;
}
