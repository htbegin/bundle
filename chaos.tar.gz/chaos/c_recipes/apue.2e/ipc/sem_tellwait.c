#include "apue.h"
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

union semun
{
	int              val;    /* Value for SETVAL */
	struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
	unsigned short  *array;  /* Array for GETALL, SETALL */
	struct seminfo  *__buf;  /* Buffer for IPC_INFO (Linux-specific) */
};

static int p2c_semid;
static int c2p_semid;

static int create_sem(int semval, int flag)
{
	int semid;
	union semun arg;

	semid = semget(IPC_PRIVATE, 1, flag);
	if (semid == -1)
	{
		err_sys("semget failed");
	}

	arg.val = semval;
	if (semctl(semid, 0, SETVAL, arg) != 0)
	{
		err_sys("semctl failed");
	}

	return semid;
}

static void down_sem(int semid)
{
	struct sembuf op;

	memset(&op, 0, sizeof(op));
	op.sem_num = 0;
	op.sem_op = -1;
	op.sem_flg = SEM_UNDO;

	if (semop(semid, &op, 1) != 0)
	{
		err_sys("semop failed");
	}
}

static void up_sem(int semid)
{
	struct sembuf op;

	memset(&op, 0, sizeof(op));
	op.sem_num = 0;
	op.sem_op = 1;
	op.sem_flg = SEM_UNDO;

	if (semop(semid, &op, 1) != 0)
	{
		err_sys("semop failed");
	}
}

void
TELL_WAIT(void)
{
	p2c_semid = create_sem(0, 0600);
	c2p_semid = create_sem(0, 0600);
}

void
TELL_PARENT(pid_t pid)
{
	up_sem(c2p_semid);
}

void
WAIT_PARENT(void)
{
	down_sem(p2c_semid);
}

void
TELL_CHILD(pid_t pid)
{
	up_sem(p2c_semid);
}

void
WAIT_CHILD(void)
{
	down_sem(c2p_semid);
}
