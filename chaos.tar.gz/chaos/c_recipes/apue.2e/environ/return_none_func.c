#include	<stdio.h>

static int test_a(void)
{
	int x = 100;
	x = x * x;
}

static int test_b(void)
{
	printf("hello, world\n");
}

static int test_c(void)
{
	int *ptr = (int *)0xFFFFFFFF;
	ptr = (int *)0xFFFFFFFF;
	return;
}

int main(int argc, char **argv)
{
	printf("test return value of functions which should return explictly but don't:\n");
	printf("return value of test_a is %d\n", test_a());
	printf("return value of test_b is %d\n", test_b());
	printf("return value of test_c is %d\n", test_c());
	return 0;
}
