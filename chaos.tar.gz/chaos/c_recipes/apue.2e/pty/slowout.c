#include <stdio.h>
#include <unistd.h>
#include <time.h>

int main(int argc, char **argv)
{
	while (1)
	{
		printf("%d\n", (int)time(NULL));
		sleep(5);
	}

	return 0;
}
