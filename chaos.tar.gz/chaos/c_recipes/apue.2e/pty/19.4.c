#include "apue.h"
#include <poll.h>

#define	BUFFSIZE	512

#define POLLFD_IDX_MPTY 0
#define POLLFD_IDX_STDIN 1

/*
 * return 1: OK
 * return 0: EOF
 * return -1: error
 */
static int handle_poll_event(int ptym, int ignoreeof, struct pollfd *fds, int cnt)
{
	int rval = 1;
	int idx = 0;
	short events = 0;
	int nread;
	char buf[BUFFSIZE];
	const char *fd_name[2];
	int dst_fds[2];
	const char *dst_fd_name[2];

	fd_name[POLLFD_IDX_MPTY] = "master_pty";
	fd_name[POLLFD_IDX_STDIN] = "stdin";
	dst_fds[POLLFD_IDX_MPTY] = STDOUT_FILENO;
	dst_fds[POLLFD_IDX_STDIN] = ptym;
	dst_fd_name[POLLFD_IDX_MPTY] = "stdout";
	dst_fd_name[POLLFD_IDX_STDIN] = "master_pty";

	idx = 0;
	while (cnt > 0)
	{
		events = fds[idx].revents;

		if (events > 0)
		{
			--cnt;
		}

		if (events & POLLIN)
		{
			nread = read(fds[idx].fd, buf, sizeof(buf));
			if (nread > 0)
			{
				if (writen(dst_fds[idx], buf, nread) != nread)
				{
					err_sys("writen error to %s", dst_fd_name[idx]);
					rval = -1;
					break;
				}
			}
			else if (nread == 0)
			{
				if (idx == POLLFD_IDX_STDIN && ignoreeof)
				{
					fds[idx].events = 0;
				}
				else
				{
					rval = 0;
					break;
				}
			}
			else
			{
				err_sys("read error from %s", fd_name[idx]);
				rval = -1;
				break;
			}
		}
		else if (events & POLLHUP)
		{
			if (idx == POLLFD_IDX_STDIN && ignoreeof)
			{
				fds[idx].events = 0;
			}
			else
			{
				rval = 0;
				break;
			}
		}

		++idx;
	}

	return rval;
}

void loop(int ptym, int ignoreeof)
{
	int rval = 0;
	struct pollfd fds[2];

	memset(fds, 0, sizeof(fds));
	fds[POLLFD_IDX_MPTY].fd = ptym;
	fds[POLLFD_IDX_MPTY].events = POLLIN;
	fds[POLLFD_IDX_STDIN].fd = STDIN_FILENO;
	fds[POLLFD_IDX_STDIN].events = POLLIN;

	while (1)
	{
		fds[POLLFD_IDX_MPTY].revents = 0;
		fds[POLLFD_IDX_STDIN].revents = 0;
		rval = poll(fds, sizeof(fds) / sizeof(fds[0]), -1);
		if (rval > 0)
		{
			rval = handle_poll_event(ptym, ignoreeof, fds, rval);
			if (rval <= 0)
			{
				break;
			}
		}
		else if (rval < 0)
		{
			err_sys("poll failed");
			break;
		}
		else
		{
			err_sys("unexpect return value %d from poll", rval);
			break;
		}
	}

	return;
}

