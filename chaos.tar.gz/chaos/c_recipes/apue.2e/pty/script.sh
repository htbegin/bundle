#!/bin/bash
./pty "${SHELL:-/bin/bash}" | tee typescript
