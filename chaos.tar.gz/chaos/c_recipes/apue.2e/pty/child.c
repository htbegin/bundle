#include "apue.h"

static void pr_winsize(int fd)
{
	struct winsize size;

	if (ioctl(fd, TIOCGWINSZ, (char *) &size) < 0)
		err_sys("TIOCGWINSZ error");
	fprintf(stderr, ":%d rows, %d columns", size.ws_row, size.ws_col);
}

static void sig_handler(int sig)
{
	if (sig == SIGTERM)
	{
		fprintf(stderr, "SIGTERM");
	}
	else if (sig == SIGWINCH)
	{
		fprintf(stderr, "SIGWINCH");
		pr_winsize(STDIN_FILENO);
	}
}

int main(int argc, char **argv)
{
	Sigfunc *old = NULL;

	old = signal(SIGTERM, sig_handler);
	if (old == SIG_ERR)
	{
		err_sys("setup SIGTERM handler failed");
	}
	old = signal(SIGWINCH, sig_handler);
	if (old == SIG_ERR)
	{
		err_sys("setup SIGWINCH handle failed");
	}
	old = signal(SIGHUP, sig_handler);

	while (1)
	{
		pause();
	}

	return 0;
}
