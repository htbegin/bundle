#include "apue.h"
#include <termios.h>

int main(int argc, char *argv[])
{
	pid_t pid;
	int fdm;
	char slave_name[20];
	struct winsize winsz;
	char buf[512];
	int cnt;
	char expect[512];

	pid = pty_fork(&fdm, slave_name, sizeof(slave_name), NULL, NULL);
	if (pid < 0) {
		err_sys("fork error");
	} else if (pid == 0) {		/* child */
		if (execl("./child", "./child", NULL) < 0)
			err_sys("can't execute child"); 
	}

	sleep(2);

	fprintf(stderr, "slave name = %s\n", slave_name);

	if (ioctl(fdm, TIOCSIG, SIGTERM) < 0)
	{
		err_sys("ioctl %d failed", TIOCSIG);
	}

	cnt = read(fdm, buf, sizeof(buf) - 1);
	if (cnt <= 0)
	{
		err_sys("read from master pty failed");
	}
	buf[cnt] = '\0';
	snprintf(expect, sizeof(expect), "%s", "SIGTERM");
	if (strcmp(buf, expect))
	{
		fprintf(stderr, "expect \"%s\", got \"%s\"\n", expect, buf); 
	}

	winsz.ws_row = 40;
	winsz.ws_col = 60;
	if (ioctl(fdm, TIOCSWINSZ, &winsz) < 0)
	{
		err_sys("ioctl %d failed", TIOCSWINSZ);
	}
	cnt = read(fdm, buf, sizeof(buf) - 1);
	if (cnt <= 0)
	{
		err_sys("read from master pty failed");
	}
	buf[cnt] = '\0';
	snprintf(expect, sizeof(expect), "%s:%d rows, %d columns",
			 "SIGWINCH", winsz.ws_row, winsz.ws_col);
	if (strcmp(buf, expect))
	{
		fprintf(stderr, "expect \"%s\", got \"%s\"\n", expect, buf); 
	}

	return 0;
}

