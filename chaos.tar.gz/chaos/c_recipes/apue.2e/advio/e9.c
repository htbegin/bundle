#include "apue.h"
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/uio.h>

struct winfo
{
	int fd;
	char *hdr;
	size_t hdr_size;
	char *data;
	size_t data_size;
};

static void merge_write(struct winfo *info)
{
	size_t total_size = info->hdr_size + info->data_size;
	char *msg = 0;
	int rval = 0;

	msg = calloc(1, total_size);
	if (msg != NULL)
	{
		memcpy(msg, info->hdr, info->hdr_size);
		memcpy(msg + info->hdr_size, info->data, info->data_size);
		rval = write(info->fd, msg, total_size);
		if (rval == total_size)
		{
			return;
		}
		else if (rval >= 0)
		{
			err_quit("incomplet write %d/%d", rval, total_size);
		}
		else
		{
			err_sys("write fail");
		}
	}
	else
	{
		err_quit("calloc %u bytes fail", total_size);
	}
}

static void scatter_write(struct winfo *info)
{
	struct iovec iov[2];
	int rval = 0;
	int total_size = info->hdr_size + info->data_size;

	iov[0].iov_base = info->hdr;
	iov[0].iov_len = info->hdr_size;
	iov[1].iov_base = info->data;
	iov[1].iov_len = info->data_size;

	rval = writev(info->fd, iov, 2);
	if (rval == total_size)
	{
		return;
	}
	else if (rval >= 0)
	{
		err_quit("incomplet write %d/%d", rval, total_size);
	}
	else
	{
		err_sys("write fail");
	}
}

int main(int argc, char **argv)
{
	int rval = 0;
	const char *method = NULL;
	const char *fname = NULL;
	char *endptr = NULL;
	struct winfo info;

	if (argc != 5)
	{
		err_quit("%s <method> <file name> <header size> <data size>\n"
				 "method: merge or scatter\n"
				 "file name: file name\n"
				 "header size: KB unit\n"
				 "data size: KB unit", argv[0]);
	}

	memset(&info, 0, sizeof(info));

	method = argv[1];
	fname = argv[2];

	errno = 0;
	info.hdr_size = strtoul(argv[3], &endptr, 10);
	if (errno == 0 && endptr != argv[3] && *endptr == '\0')
	{
		info.hdr_size <<= 10;
	}
	else
	{
		err_quit("invalid header size %s", argv[3]);
	}

	errno = 0;
	info.data_size = strtoul(argv[4], &endptr, 10);
	if (errno == 0 && endptr != argv[4] && *endptr == '\0')
	{
		info.data_size <<= 10;
	}
	else
	{
		err_quit("invalid data size %s", argv[4]);
	}

	info.fd = open(fname, O_WRONLY | O_TRUNC | O_CREAT, FILE_MODE);
	if (info.fd < 0)
	{
		err_sys("create %s fail", fname);
	}
#if 0
	rval = unlink(fname);
	if (rval != 0)
	{
		err_sys("unlink %s fail", fname);
	}
#endif
	info.hdr = calloc(1, info.hdr_size);
	if (info.hdr == NULL)
	{
		err_sys("calloc %u bytes fail", info.hdr_size);
	}

	info.data = calloc(1, info.data_size);
	if (info.data == NULL)
	{
		err_sys("calloc %u bytes fail", info.data_size);
	}

	if (strcmp(method, "merge") == 0)
	{
		merge_write(&info);
	}
	else if (strcmp(method, "scatter") == 0)
	{
		scatter_write(&info);
	}
	else
	{
		err_quit("invalid method %s", method);
	}

	return 0;
}

