#include "apue.h"
#include <pthread.h>

#define THREAD_CNT 4

enum
{
	READ_LOCK = 1,
	WRITE_LOCK,
};

#define MK_ARG(lock, delay, tid) ((((lock) & 0xFFFF) << 16) | (((delay) & 0xFF) << 8) | ((tid) & 0xFF))
#define LOCK_IN_ARG(arg) (((unsigned int)(arg) >> 16) & 0xFFFF)
#define DELAY_IN_ARG(arg) (((unsigned int)(arg) >> 8) & 0xFF)
#define TID_IN_ARG(arg) ((unsigned int)(arg) & 0xFF)

static pthread_rwlock_t rwlock;

static void* thread_fn(void *arg)
{
	int lock_type = LOCK_IN_ARG(arg);
	int delay = DELAY_IN_ARG(arg);
	int tid = TID_IN_ARG(arg);
	int rval = 0;
	struct timespec wait;

	memset(&wait, 0, sizeof(wait));

	if (delay > 0)
	{
		wait.tv_sec = delay;
		nanosleep(&wait, NULL);
	}

	if (lock_type == READ_LOCK)
	{
		rval = pthread_rwlock_rdlock(&rwlock);
		if (rval == 0)
		{
			err_msg("thread %u acquire read lock", tid);
		}
		else
		{
			err_sys("thread %u acquire read lock fail", tid);
		}
	}
	else if (lock_type == WRITE_LOCK)
	{
		rval = pthread_rwlock_wrlock(&rwlock);
		if (rval == 0)
		{
			err_msg("thread %u acquire write lock", tid);
		}
		else
		{
			err_sys("thread %u acquire write lock fail", tid);
		}
	}

	wait.tv_sec = 15;
	nanosleep(&wait, NULL);

	if (lock_type == READ_LOCK || lock_type == WRITE_LOCK)
	{
		rval = pthread_rwlock_unlock(&rwlock);
		if (rval == 0)
		{
			if (lock_type == READ_LOCK)
			{
				err_msg("thread %u release read lock", tid);
			}
			else
			{
				err_msg("thread %u release write lock", tid);
			}
		}
		else
		{
			if (lock_type == READ_LOCK)
			{
				err_sys("thread %u release read lock fail", tid);
			}
			else
			{
				err_sys("thread %u release write lock fail", tid);
			}
		}
	}

	return NULL;
}

int main(int argc, char **argv)
{
	int rval = 0;
	int idx = 0;
	int cnt = 0;
	pthread_t tids[THREAD_CNT];
	int tid_args[THREAD_CNT] =
	{
		[0] = MK_ARG(READ_LOCK, 0, 0),
		[1] = MK_ARG(WRITE_LOCK, 2, 1),
		[2] = MK_ARG(READ_LOCK, 4, 2),
		[3] = MK_ARG(READ_LOCK, 6, 3),
	};

	rval = pthread_rwlock_init(&rwlock, NULL);
	if (rval != 0)
	{
		err_sys("init rw lock fail");
	}

	for (idx = 0, cnt = sizeof(tids) / sizeof(tids[0]); idx < cnt; ++idx)
	{
		rval = pthread_create(&tids[idx], NULL, thread_fn, (void *)tid_args[idx]);
		if (0 != rval)
		{
			err_sys("create thread fail");
		}
	}

	for (idx = 0, cnt = sizeof(tids) / sizeof(tids[0]); idx < cnt; ++idx)
	{
		rval = pthread_join(tids[idx], NULL);
		if (0 != rval)
		{
			err_sys("join thread fail");
		}
	}

	rval = pthread_rwlock_destroy(&rwlock);
	if (rval != 0)
	{
		err_sys("destroy rw lock fail");
	}

	return 0;
}
