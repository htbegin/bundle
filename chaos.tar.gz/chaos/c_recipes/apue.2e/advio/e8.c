#include "apue.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>

int main(int argc, char **argv)
{
	int fds[2] = {0, 0};
	int rval = 0;
	char buf[4096];
	int write_cnt = 0;

	rval = pipe(fds);
	if (rval == 0)
	{
		errno = 0;
		rval = fpathconf(fds[1], _PC_PIPE_BUF);
		if (rval != -1)
		{
			err_msg("pipe buffer is %d", rval);
		}
		else if (errno == 0)
		{
			err_msg("no limitation for pipe buffer");
		}
		else
		{
			err_quit("get pipe buffer fail");
		}

		set_fl(fds[1], O_NONBLOCK);
		write_cnt = 0;
		while (1)
		{
			errno = 0;
			rval = write(fds[1], buf, sizeof(buf));
			if (rval >= 0)
			{
				write_cnt += rval;
				err_msg("write %d bytes", rval);
			}
			else if (errno == EAGAIN)
			{
				err_msg("the pipe buffer is full");
				err_msg("totally write %d bytes", write_cnt);
				break;
			}
			else
			{
				err_quit("write fail");
				break;
			}
		}
	}
	else
	{
		err_quit("create pipe fail");
	}

	return 0;
}

