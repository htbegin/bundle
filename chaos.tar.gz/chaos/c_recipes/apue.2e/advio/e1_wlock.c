#include "apue.h"
#include <fcntl.h>

int main(int argc, char **argv)
{
	int delay = 0;
	int	fd;

	if (argc == 2)
	{
		delay = atoi(argv[1]);
	}
	if (delay <= 0)
	{
		delay = 30;
	}
	printf("delay %d seconds before release\n", delay);

	/*
	 * Create a file and write two bytes to it.
	 */
	if ((fd = open("e1_lock", O_WRONLY) < 0))
	{
		err_sys("open error");
	}

	writew_lock(fd, 0, SEEK_SET, 0);
	printf("process %d acquire write lock\n", getpid());

	sleep(delay);

	un_lock(fd, 0, SEEK_SET, 0);
	printf("process %d release write lock\n", getpid());
	exit(0);
}
