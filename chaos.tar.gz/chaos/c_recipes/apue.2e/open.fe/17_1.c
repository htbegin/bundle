#include "apue.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>

static void show_fd_offset(const char *prefix, int fd)
{
	loff_t offset = lseek(fd, 0, SEEK_CUR);

	if (offset != -1)
	{
		err_msg("%s: offset is %lld", prefix, offset);
	}
	else
	{
		err_sys("lseek fd %d failed", fd);
	}
}

int main(int argc, char **argv)
{
	pid_t pid;
	int fd[2] = { -1, -1 };

	TELL_WAIT();

	if (s_pipe(fd) < 0)
	{
		err_sys("s_pipe error");
	}

	pid = fork();
	if (pid < 0)
	{
		err_sys("fork error");
	}
	else if (pid == 0)
	{
		/* child process */
		int fd_to_send;
		loff_t offset;

		close(fd[0]);

		fd_to_send = open(argv[0], O_RDONLY);
		if (fd_to_send < 0)
		{
			err_sys("open %s failed", argv[0]);
		}

		err_msg("child:send fd %d", fd_to_send);
		if (send_fd(fd[1], fd_to_send) < 0)
		{
			err_sys("child: send fd failed");
		}
		/* wait for parent to receive fd */
		WAIT_PARENT();

		offset = lseek(fd_to_send, 55, SEEK_CUR);
		if (offset == -1)
		{
			err_sys("lseek fd %d failed", fd_to_send);
		}
		show_fd_offset("child", fd_to_send);
		/* tell parent the lseek is done*/
		TELL_PARENT(getppid());
	} else {
		int received_fd;

		close(fd[1]);

		received_fd = recv_fd(fd[0], write);
		if (received_fd < 0)
		{
			err_sys("parent: receive fd failed");
		}
		err_msg("parent: receive fd %d", received_fd);
		/* tell child the receive is complete */
		TELL_CHILD(pid);

		/* wait for child to lseek fd */
		WAIT_CHILD();
		show_fd_offset("parent", received_fd);

		/* wait for child to exit */
		waitpid(pid, NULL, 0);
	}

	return 0;
}
