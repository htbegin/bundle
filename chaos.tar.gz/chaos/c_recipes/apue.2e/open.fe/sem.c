#include "apue.h"
#include <fcntl.h>
#include <sys/stat.h> 
#include <semaphore.h>

int main(int argc, char **argv)
{
	int ret = 0;
	sem_t *sem = NULL;
	int cur_val = 0;

	sem = sem_open("/apue2_sem", O_CREAT, 0600, 1);
	if (sem == SEM_FAILED)
	{
		err_sys("create sem failed");
	}

	ret = sem_getvalue(sem, &cur_val);
	if (ret != 0)
	{
		err_sys("get sem value failed");
	}
	err_msg("sem value is %d", cur_val);

	ret = sem_wait(sem);
	if (ret != 0)
	{
		err_sys("wait sem failed");
	}

	sem_close(sem);

	return 0;
}
