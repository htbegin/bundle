#include "apue.h"

static void
pr_ids(char *name)
{
	printf("%s: pid = %d, ppid = %d, pgrp = %d, tpgrp = %d\n",
	    name, getpid(), getppid(), getpgrp(), tcgetpgrp(STDIN_FILENO));
	fflush(stdout);
}

int main(int argc, char **argv)
{
	pid_t pid = 0;
	pid_t pgid = 0;

	pid = fork();
	if (pid > 0) {
		pr_ids("parent");
	} else if (pid == 0) {
		pgid = setsid();
		if (pgid >= 0) {
			pr_ids("child");
		} else {
			err_sys("setsid error");
		}
	} else {
		err_sys("fork error");
	}

	return 0;
}
