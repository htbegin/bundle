#include "apue.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char **argv)
{
	const char *tty_dev = "/dev/tty";
	int tty_fd = 0;
	char tty_buf[32] = {0};
	int cnt = 0;

	tty_fd = open(tty_dev, O_RDONLY);
	if (tty_fd >= 0) {
		cnt = read(tty_fd, tty_buf, sizeof(tty_buf) - 1);
		if (cnt > 0) {
			tty_buf[cnt] = '\0';
			printf("read %d bytes: \"%s\"\n", cnt, tty_buf);
		} else if (cnt == 0) {
			err_msg("read %s EOFed", tty_dev);
		} else {
			err_sys("read from %s error", tty_dev);
		}
		close(tty_fd);
	} else {
		err_sys("open %s error", tty_dev);
	}

	return 0;
}
