#include "apue.h"

void internal_setbuf(FILE *fp, char *buf)
{
	if (fp != NULL) {
		if (buf != NULL) {
			/* TODO
			 * check whether or not fp is associated with a terminal
			 * if true, set fp as line-buffer type
			 */
			setvbuf(fp, NULL, _IOFBF, 0);
		} else {
			setvbuf(fp, NULL, _IONBF, 0);
		}
	}
}

