#include "apue.h"

int main(int argc, char **argv)
{
	int ret = printf("");
	printf("printf(\"\") return %d\n", ret);
	return 0;
}

