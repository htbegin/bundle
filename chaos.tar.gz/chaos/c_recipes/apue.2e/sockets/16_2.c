#include "apue.h"
#include <sys/types.h>
#include <sys/socket.h>

int main(int argc, char **argv)
{
	int fd = socket(AF_INET, SOCK_STREAM, 0);
	if (fd >= 0)
	{
		struct stat info;

		memset(&info, 0, sizeof(info));
		if (0 == fstat(fd, &info))
		{
			printf("st_dev: %d %d\n", major(info.st_dev), minor(info.st_dev));
			printf("st_ino: %lu\n", info.st_ino);
			printf("st_mode: 0%o\n", info.st_mode);
			printf("st_nlink: %d\n", info.st_nlink);
			printf("st_rdev: %d %d\n", major(info.st_rdev), minor(info.st_rdev));
		}
	}
	return 0;
}
