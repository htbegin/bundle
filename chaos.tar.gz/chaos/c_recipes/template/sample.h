/*
 * Description:
 *     the header file of code style sample.
 * Copyright:
 *     hotforest <hotforest@gmail.com>
 * Author:
 *     hotforest <hotforest@gmail.com>
 */

#ifndef __TEMPLATE_H__
#define __TEMPLATE_H__

enum enum_template
{
	ENUM_TEMPLATE_ONE,
	ENUM_TEMPLATE_TWO,
	ENUM_TEMPLATE_THREE,
};

struct struct_template
{
	int field_template;
	struct struct_template * next;
};

extern int template_prototype_init(enum enum_template value);

extern int template_prototype_set(const struct struct_template * value);

extern int template_prototype_get(struct struct_template * value);

extern void template_prototype_uninit();

#endif /* __TEMPLATE_H__ */

