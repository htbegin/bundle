/*******************************************************************************
*	Filename: template.c
********************************************************************************
* Description:
*	template C source file to show the code style;
* Version:
*	V_0.1 Apr-01-2010
* Coypright:
*	hotforest <hotforest@gmail.com>
* Author:
*	hotforest <hotforest@gmail.com>
* History:
*	V_0.1	alpha edition
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#include "template.h"

#define log_syscall_error(fmt,args...) \
	fprintf(stderr,"invoke " fmt " fail,error-%s.\n",##args,strerror(errno))
#define log_error(fmt,args...) \
	fprintf(stderr,fmt ".\n",##args)
#define log_info(fmt,args...) \
	fprintf(stdout,fmt ".\n",##args)

int template_prototype_init(enum enum_template value)
{
	int rval=0;

	log_info("invoke %s at %s:%d succeed",__FUNCTION__,__FILE__,__LINE__);

	return rval;
}

int template_prototype_set(const struct struct_template * value)
{
	assert(value!=NULL);

	int rval=0;
	struct struct_template * buffer=NULL;

	buffer=calloc(1,sizeof(*buffer));
	if(buffer!=NULL)
	{
		*buffer=*value;
		free(buffer);
		buffer=NULL;
	}
	else
	{
		log_syscall_error("calloc");
		rval=-1;
	}

	return rval;
}

int template_prototype_get(struct struct_template * value)
{
	assert(value!=NULL);

	int rval=-1;

	log_error("invoke %s at %s:%d fail",__FUNCTION__,__FILE__,__LINE__);

	return rval;
}

void template_prototype_uninit()
{
	log_info("invoke %s at %s:%d",__FUNCTION__,__FILE__,__LINE__);
}

int main(int argc,char * argv[])
{
	return 0;
}

