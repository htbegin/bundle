#! /usr/bin/env python
# -*- coding: ascii -*-

def table_to_points(file_name):
    input=open(file_name, "r")

    points=[]
    workset_key=15
    data_line_detected=False
    for line in input:
        tokens=line.split()

        if not data_line_detected:
            if tokens[0] == "32m":
                data_line_detected=True
            else:
                continue

        throughput_list=tokens[1:]

        for index, throughput in enumerate(throughput_list):
            stride_key=index+1
            point=(stride_key, workset_key, throughput)
            points.append(point)

        workset_key=workset_key-1

    points.sort()
    input.close()

    return points

def output_3d_points(points, fname):
    output=open(fname, "w")

    for point in points:
        str="{0} {1} {2}\n".format(*point)
        output.write(str)

    output.close()

def output_2d_points(points, fname):
    output=open(fname, "w")

    for point in points:
        str="{0} {1}\n".format(*point)
        output.write(str)

    output.close()

def output_2d_points_with_const_stride(points, fname_prefix):
    stride_key_list=range(1, 65)

    for stride_key in stride_key_list:
        fname="{0}_{1:02d}".format(fname_prefix, stride_key)
        new_points=[(point[1], point[2]) for point in points \
                    if point[0] == stride_key]
        output_2d_points(new_points, fname)

def output_2d_points_with_const_workset(points, fname_prefix):
    workset_value_list=("2KB", "4KB", "8KB", "16KB", "32KB", "64KB", "128KB",
            "256KB", "512KB", "1MB", "2MB", "4MB", "8MB", "16MB", "32MB")
    workset_key_list=range(1, 16)

    for workset_key in workset_key_list:
        workset_value=workset_value_list[workset_key-1]
        fname="{0}_{1}".format(fname_prefix, workset_value)
        new_points=[(point[0], point[2]) for point in points \
                    if point[1] == workset_key]
        output_2d_points(new_points, fname)

points=table_to_points("../data/input")
output_3d_points(points, "../data/output")
output_2d_points_with_const_stride(points, "../data/stride")
output_2d_points_with_const_workset(points, "../data/workset")
