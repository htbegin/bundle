#! /bin/bash

# pre cleanup
rm -fr images
rm -fr data
make -s -C code clean

# directory for images
mkdir -p images/stride
mkdir -p images/workset

# temporary directory for data
mkdir -p data

# build "mountain"
make -s -C code clean
make -s -C code

# get memory mountain statistics
./code/mountain > ./data/input

# convert format of memory mountain statistics
# and plot the graph of memory mountain
pushd plot >/dev/null
./format.py
gnuplot mountain.plot
gnuplot const_stride.plot
gnuplot const_workset.plot
popd >/dev/null

# post clean up
rm -fr data
make -s -C code clean

