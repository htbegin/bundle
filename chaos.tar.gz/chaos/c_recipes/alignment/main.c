#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#include "access.h"

#define log_error(fmt,args...) \
	fprintf(stderr,"Error at %s:%s:%d, "fmt".\n",\
			__FILE__,__FUNCTION__,__LINE__,##args)

#define log_sys_error(fmt,args...) \
	fprintf(stderr,"Error %s at %s:%s:%d, "fmt".\n",strerror(errno),\
			__FILE__,__FUNCTION__,__LINE__,##args)

typedef enum boolean
{
	FALSE=0,
	TRUE=1,
}boolean;

enum parse_result
{
	PARSE_RESULT_VALID_HELP_ON,
	PARSE_RESULT_VALID_HELP_OFF,
	PARSE_RESULT_INVALID,
};

enum
{
	BUFFER_SIZE_IN_MB_INVALID=0,
	BUFFER_SIZE_IN_MB_MIN=4,
	BUFFER_SIZE_IN_MB_MAX=1024,

	MB_IN_BYTES=1024*1024,

	REPEAT_CNT_INVALID=0,
	REPEAT_CNT_MIN=10,
	REPEAT_CNT_MAX=30,
};

struct perf_test_setting
{
	boolean plot_format_output;
	int buffer_size_in_mb;
	int repeat_cnt;
};

struct perf_test_case
{
	const char * name;
	void (*func)(void * data,int size);
};

struct global_argument
{
	boolean plot_format_output;
	int buffer_size;
	void * buffer;
	int counter_cnt;
	double * counter;
	const struct perf_test_case * test_case;
	int case_cnt;
};

static double calc_time_delta(const struct timeval * begin,\
		const struct timeval * end)
{
	assert(begin!=NULL);
	assert(end!=NULL);

	double delta=0;

	delta=(end->tv_sec-begin->tv_sec)*1e6+(end->tv_usec-begin->tv_usec);

	assert(delta>=0);

	return delta;
}

static double calc_average_dvalue(const double * set,const int set_cnt)
{
	assert(set!=NULL);
	assert(set_cnt>0);

	double average=0;
	double total=0;
	int set_index;

	for(set_index=0;set_index<set_cnt;set_index++)
	{
		total+=set[set_index];
	}
	average=total/set_cnt;

	return average;
}

void run_performance_test_case(const struct global_argument * global)
{
	const struct perf_test_case * test_case=NULL;
	const int case_cnt=global->case_cnt;
	int case_index;

	for(case_index=0;case_index<case_cnt;case_index++)
	{
		test_case=&global->test_case[case_index];

		const int max_offset=16;
		int offset;
		void * start=NULL;
		int len;
		double average;

		if(global->plot_format_output)
		{
			printf("# %s\n",test_case->name);
		}
		else
		{
			printf("# run %s:\n",test_case->name);
		}
		for(offset=0;offset<=max_offset;offset++)
		{
			start=global->buffer+offset;
			len=global->buffer_size-offset;

			const int counter_cnt=global->counter_cnt;
			int cnt;
			struct timeval stime;
			struct timeval etime;

			for(cnt=0;cnt<counter_cnt;cnt++)
			{
				gettimeofday(&stime,NULL);
				(*test_case->func)(start,len);
				gettimeofday(&etime,NULL);
				global->counter[cnt]=calc_time_delta(&stime,&etime);
			}
			average=calc_average_dvalue(global->counter,counter_cnt);
			if(global->plot_format_output)
			{
				printf("%d %.0f\n",offset,average);
			}
			else
			{
				printf("offset %d bytes, time %.0f microsecond\n",offset,average);
			}
		}
		if(global->plot_format_output)
		{
			printf("\n");
			printf("\n");
		}
	}
}

static const struct perf_test_case test_case[]=
{
	{
		.name="one_stride_access",
		.func=one_stride_access,
	},
	{
		.name="two_stride_access",
		.func=two_stride_access,
	},
	{
		.name="four_stride_access",
		.func=four_stride_access,
	},
	{
		.name="eight_stride_access",
		.func=eight_stride_access,
	},
};

static void usage(const char * cmd)
{
	printf("\nUsage: %s -h, %s [-m] -s size -r repeat\n"
			"-h: output help message\n"
			"-m: output is fit for gnuplot plot\n"
			"-s: the buffer size in range [4,1024], unit is MB\n"
			"-r: the repeat count of time counting in range [10,30]\n"
			"\n",cmd,cmd);
}

static enum parse_result parse_options(const int argc,char ** argv,\
		struct perf_test_setting * setting)
{
	struct perf_test_setting input;

	input.plot_format_output=FALSE;
	input.buffer_size_in_mb=BUFFER_SIZE_IN_MB_INVALID;
	input.repeat_cnt=REPEAT_CNT_INVALID;

	const char * opt_str=":hms:r:";
	boolean input_valid;
	boolean help_enable;
	int opt;
	int integer_arg;

	help_enable=FALSE;
	input_valid=TRUE;
	opterr=0;
	while(input_valid && (opt=getopt(argc,argv,opt_str))!=-1)
	{
		switch(opt)
		{
			case 'h':
				if(argc==2 && optind>=argc)
				{
					help_enable=TRUE;
				}
				else
				{
					fprintf(stderr,"option -h must be alone\n");
					input_valid=FALSE;
				}
				break;
			case 'm':
				input.plot_format_output=TRUE;
				break;
			case 's':
				integer_arg=atoi(optarg);
				if(BUFFER_SIZE_IN_MB_MIN<=integer_arg && \
						integer_arg<=BUFFER_SIZE_IN_MB_MAX)
				{
					input.buffer_size_in_mb=integer_arg;
				}
				else
				{
					fprintf(stderr,"buffer size arg %d is out-of-range\n",\
							integer_arg);
					input_valid=FALSE;
				}
				break;
			case 'r':
				integer_arg=atoi(optarg);
				if(REPEAT_CNT_MIN<=integer_arg && integer_arg<=REPEAT_CNT_MAX)
				{
					input.repeat_cnt=integer_arg;
				}
				else
				{
					fprintf(stderr,"repeat cnt arg %d is out-of-range\n",\
							integer_arg);
					input_valid=FALSE;
				}
				break;
			case '?':
				fprintf(stderr,"unknown option %c\n",optopt);
				input_valid=FALSE;
				break;
			case ':':
				fprintf(stderr,"option %c miss required argument\n",optopt);
				input_valid=FALSE;
				break;
		}
	}
	if(input_valid && (!help_enable))
	{
		if(input.buffer_size_in_mb == BUFFER_SIZE_IN_MB_INVALID || \
				input.repeat_cnt == REPEAT_CNT_INVALID)
		{
			input_valid=FALSE;
		}
		if(optind<argc)
		{
			fprintf(stderr,"too many options are provided\n");
			input_valid=FALSE;
		}
	}

	enum parse_result rval=PARSE_RESULT_INVALID;

	if(input_valid)
	{
		if(help_enable)
		{
			rval=PARSE_RESULT_VALID_HELP_ON;
		}
		else
		{
			*setting=input;
			rval=PARSE_RESULT_VALID_HELP_OFF;
		}
	}
	return rval;
}

int main(int argc,char ** argv)
{
	enum parse_result result;
	struct perf_test_setting setting;

	result=parse_options(argc,argv,&setting);
	if(result==PARSE_RESULT_VALID_HELP_ON)
	{
		usage(argv[0]);
		return 0;
	}
	else if(result==PARSE_RESULT_INVALID)
	{
		usage(argv[0]);
		return 1;
	}

	int rval=0;
	struct global_argument global={};

	global.plot_format_output=setting.plot_format_output;

	global.buffer_size=setting.buffer_size_in_mb*MB_IN_BYTES;
	global.buffer=calloc(global.buffer_size,1);
	if(global.buffer==NULL)
	{
		log_sys_error("buffer malloc");
		rval=1;
		goto out;
	}

	global.counter_cnt=setting.repeat_cnt;
	global.counter=calloc(global.counter_cnt,sizeof(double));
	if(global.counter==NULL)
	{
		log_sys_error("counter array malloc");
		rval=1;
		goto out;
	}

	global.test_case=test_case;
	global.case_cnt=sizeof(test_case)/sizeof(test_case[0]);

	run_performance_test_case(&global);

out:
	if(global.buffer!=NULL) free(global.buffer);
	if(global.counter!=NULL) free(global.counter);

	global.buffer=NULL;
	global.buffer_size=0;
	global.counter=NULL;
	global.counter_cnt=0;

	return rval;
}

