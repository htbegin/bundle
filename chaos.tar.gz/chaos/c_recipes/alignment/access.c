#include "access.h"

void one_stride_access(void * data,int size)
{
	unsigned char * begin=(unsigned char *)data;
	unsigned char * end=begin+size;

	while(begin<end)
	{
		*begin=-*begin;
		++begin;
	}
}

void two_stride_access(void * data,int size)
{
	unsigned short * begin=(unsigned short *)data;
	unsigned short * end=begin+(size>>1);

	while(begin<end)
	{
		*begin=-*begin;
		++begin;
	}

	unsigned char * remain_begin=(unsigned char *)end;
	unsigned char * remain_end=remain_begin+(size & 0x1);

	while(remain_begin<remain_end)
	{
		*remain_begin=-*remain_begin;
		++remain_begin;
	}
}

void four_stride_access(void * data,int size)
{
	unsigned int * begin=(unsigned int *)data;
	unsigned int * end=begin+(size>>2);

	while(begin<end)
	{
		*begin=-*begin;
		++begin;
	}

	unsigned char * remain_begin=(unsigned char *)end;
	unsigned char * remain_end=remain_begin+(size & 0x3);

	while(remain_begin<remain_end)
	{
		*remain_begin=-*remain_begin;
		++remain_begin;
	}
}

void eight_stride_access(void * data,int size)
{
	double * begin=(double *)data;
	double * end=begin+(size>>3);

	while(begin<end)
	{
		*begin=-*begin;
		++begin;
	}

	unsigned char * remain_begin=(unsigned char *)end;
	unsigned char * remain_end=remain_begin+(size & 0x7);

	while(remain_begin<remain_end)
	{
		*remain_begin=-*remain_begin;
		++remain_begin;
	}
}

