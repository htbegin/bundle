#ifndef __ALIGMENT_ACCESS__
#define __ALIGMENT_ACCESS__

void one_stride_access(void * data,int size);
void two_stride_access(void * data,int size);
void four_stride_access(void * data,int size);
void eight_stride_access(void * data,int size);

#endif /* __ALIGMENT_ACCESS__ */

