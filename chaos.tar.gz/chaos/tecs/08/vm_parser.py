import re

class Parser:
    "Parser for VM files"
    
    #command types
    C_ARITHMETIC = 1
    C_PUSH       = 2
    C_POP        = 3
    C_LABEL      = 4
    C_GOTO       = 5
    C_IF         = 6
    C_FUNCTION   = 7
    C_RETURN     = 8
    C_CALL       = 9
    
    COMMAND_HASH = {"push":C_PUSH,
                    "pop":C_POP,
                    "add":C_ARITHMETIC,
                    "sub":C_ARITHMETIC,
                    "neg":C_ARITHMETIC,
                    "eq":C_ARITHMETIC,
                    "gt":C_ARITHMETIC,
                    "lt":C_ARITHMETIC,
                    "and":C_ARITHMETIC,
                    "or":C_ARITHMETIC,
                    "not":C_ARITHMETIC,
                    "label":C_LABEL,
                    "goto":C_GOTO,
                    "if-goto":C_IF,
                    "function":C_FUNCTION,
                    "call":C_CALL,
                    "return":C_RETURN
                    }
    
    BUFFER_SIZE = 4
    def __init__(self, stream):
        self.stream = stream
        self.storedLine = []
        self.hasMoreCommands()
        
    def getLine(self):
        return self.storedLine[0]
    
    def getNextLineFromStream(self):
        "Returns the next line from the stream of None if there isn't any"
        line = None
        while(True):
            line = self.stream.readline()
            if (line == ""):
                return None
            # remove comments from the line
            commentIndex = line.find("//")
            if (commentIndex != -1):
                line = line[:commentIndex]
            # split the command into the different parts (max 3)
            if (line.strip() != ""):
                return re.split("[ \t\n\r]+", line)

    
    def hasMoreCommands(self):
        "return true if there are more command in the input"
        while ((len(self.storedLine)< Parser.BUFFER_SIZE)):
            line = self.getNextLineFromStream()
            if (line == None):
                return len(self.storedLine) != 0
            else:
                self.storedLine.append(line)
                return True
        else:
            return True
    
    def getBufferSize(self):
        return len(self.storedLine)
    
    def advance(self):
        "Move to the next line"
        assert self.hasMoreCommands()
        self.storedLine= self.storedLine[1:]

    
    def commandType(self, index = 0):
        "returns one of C_* constants"
        return Parser.COMMAND_HASH[self.storedLine[index][0]]

    def getArgs(self, index = 0):
        # last argument is always bogus
        if (self.commandType(index) == Parser.C_ARITHMETIC):
            return self.storedLine[index][0:-1]
        else: return self.storedLine[index][1:-1]
