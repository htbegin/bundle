import vm_parser
import os

class CodeWriter:
    COMMON_CALL_LABEL = "$COMMON_CALL"
    COMMON_RETURN_LABEL = "$COMMON_RETURN"
    COMMON_INIT_LOCALS_LABEL = "$COMMON_INIT_LOCALS"
    
    def __init__(self, output):
        self.output = open(output, "wt")
        self.labelCounter = 0
        self.staticCounter = 0
        self.funcName = None
        self.lineCount = 0
        self.lastCommand = None
    
    def setFileName(self, name, parser):
        self.fileName = name
        self.parser = parser
        print "File %s started in line %d"%(name, self.lineCount)
        
    def close(self):
        self.output.close()
    
    def writeInit(self):
        "Sets initial SP and call Sys.init"
        self.write("@256")
        self.write("D=A")
        self.write("@SP")
        self.write("M=D")
        self.writeCall('Sys.init', 0)
    
    def writeCommon(self):
        # write common code sections
        print "Common code started in line %d"%(self.lineCount)
        self.writeCommonReturn()
        self.writeCommonCall()
        self.writeCommonInitLocals()
    
    def writeCommand(self, commandType, args):
        if (not CodeWriter.HANDLERS.has_key(commandType)):
            raise "Unknown command " + str(commandType)
        # call the appropriate handler
        CodeWriter.HANDLERS[commandType](self, *args)
        self.lastCommand = (commandType, args)
    
    
    ##
    ## Flow control commands
    ##
    
    def writeLabel(self, label):
        self.write("(%s)"%self.translateLabel(label))
    
    def writeGoto(self, label):
        self.write("@%s"%self.translateLabel(label))
        self.write("0;JMP")
    
    def writeIf(self, label):
        self.popToD()
        self.write("@%s"%self.translateLabel(label))
        self.write("D; JNE")
    
    def writeCall(self, funcName, numArgs):
        #Store function label in R15
        self.write("@%s"%funcName)
        self.write("D=A")
        self.write("@R15")
        self.write("M=D")
        #Store numArgs in R14
        if (numArgs == "0" or numArgs == "1"):
            self.write("D=%s"%numArgs)
        else:
            self.write("@%s"%numArgs)
            self.write("D=A")
        self.write("@R14")
        self.write("M=D")
        #Store return address in D
        returnLabel = self.getNextLabel()
        self.write("@%s"%returnLabel)
        self.write("D=A")
        #goto Common call procedure
        self.write("@%s"%CodeWriter.COMMON_CALL_LABEL)
        self.write("0; JMP")
        
        #(return-address) // Declare a label for the return-address
        self.write("(%s)"%returnLabel)        
    
    def writeCommonCall(self):
        """when called, D should contain the return address,
        R14 should contain numArgs
        R15 should contain the function label"""
        self.write("(%s)"%CodeWriter.COMMON_CALL_LABEL)
        #push return-address
        self.pushD()
        
        #push LCL // Save LCL of the calling function
        self.writePushRegister("LCL")
        #push ARG // Save ARG of the calling function
        self.writePushRegister("ARG")
        #push THIS // Save THIS of the calling function
        self.writePushRegister("THIS")
        #push THAT // Save THAT of the calling function
        self.writePushRegister("THAT")
        #ARG = SP-n-5 // Reposition ARG (n = number of arguments)
        self.write("@R14")
        self.write("D=M")
        self.write("@5")
        self.write("D=A+D")
        self.write("@SP")
        self.write("D=M-D")
        self.write("@ARG")
        self.write("M=D")
        #LCL = SP // Reposition LCL
        self.write("@SP")
        self.write("D=M")
        self.write("@LCL")
        self.write("M=D")
        #goto f // Transfer control
        self.write("@R15")
        self.write("A=M")
        self.write("0;JMP")


    def writeReturn(self):
        self.write("@%s"%CodeWriter.COMMON_RETURN_LABEL)
        self.write("0;JMP")

    
    def writeCommonReturn(self):    
        #FRAME=LCL-1 // FRAME is a temporary variable
        self.write("(%s)"%CodeWriter.COMMON_RETURN_LABEL)
        self.write("@LCL")
        self.write("D=M")
        self.write("@R15")
        self.write("M=D-1")
        
        #RET=*(FRAME-4) // Put the return-address in a temporary variable(R14)
        self.write('@R15')
        self.write('D=M')
        self.write('@4')
        self.write('A=D-A') # a = frame-4
        self.write('D=M')
        self.write('@R14')
        self.write('M=D')

        
        #*ARG=pop() // Reposition the return value for the caller
        self.popToD()
        self.write("@ARG")
        self.write("A=M")
        self.write("M=D")
        
        #SP=ARG+1 // Restore SP for the caller
        self.write("D=A+1")
        self.write("@SP")
        self.write("M=D")
        
        #THAT=*(FRAME) // Restore THAT of the caller
        self.write("@R15")
        self.write("A=M")
        self.write("D=M")
        self.write("@THAT")
        self.write("M=D")
        
        self.write("@R15")    #(R15) FRAME--
        self.write("M=M-1")
        
        #THIS=*(FRAME-1) // Restore THIS of the caller
        self.write("A=M")
        self.write("D=M")
        self.write("@THIS")
        self.write("M=D")
        
        self.write("@R15")    #(R15) FRAME--
        self.write("M=M-1")
        
        #ARG=*(FRAME-2) // Restore ARG of the caller
        self.write("A=M")
        self.write("D=M")
        self.write("@ARG")
        self.write("M=D")
        
        self.write("@R15")    #(R15) FRAME--
        self.write("M=M-1")
        
        #LCL=*(FRAME-3) // Restore LCL of the caller
        self.write("A=M")
        self.write("D=M")
        self.write("@LCL")
        self.write("M=D")
        
        #goto RET // GOTO return-address (in the callers code)
        self.write('@R14')
        self.write('A=M')
        self.write("0;JMP")
    
    def writeFunction(self, funcName, numLocals):
        self.funcName = funcName
        #Declare a label for the function entry
        self.write("(%s)"%funcName)
        # check if we need to init locals and if so do it
        if(numLocals != "0"):
            # special case for 1 local arg, else we jump to common init locals helper
            if (numLocals == "1"):
                self.write("@SP")
                self.write("A=M")
                self.write("M=0") 
                self.incSP()
            else:
                # total 8 commands
                self.write("@%s"%numLocals)
                self.write("D=A")
                self.write("@R15")
                self.write("M=D")
                returnLabel = self.getNextLabel()
                self.write("@%s"%returnLabel)
                self.write("D=A")
                self.write("@%s"%CodeWriter.COMMON_INIT_LOCALS_LABEL)
                self.write("0;JMP")
                self.write("(%s)"%returnLabel)
    
    def writeCommonInitLocals(self):
        """when called, D should contain the return address,
           R15 should contain numLocals and is assumed > 0"""
        self.write("(%s)"%CodeWriter.COMMON_INIT_LOCALS_LABEL)
        self.write("@R14")
        self.write("M=D")
        
        #loop R15 times and push 0 in stack each time
        loopLabel = self.getNextLabel()
        self.write("(%s)"%loopLabel)
        self.write("D=0")
        self.pushD()
        self.write("@R15")
        self.write("M=M-1")
        self.write("D=M")
        self.write("@%s"%loopLabel)
        self.write("D;JNE")
        
        #go back to caller
        self.write("@R14")
        self.write("A=M")
        self.write("0;JMP")

    
    ##
    ## Stack handling functions
    ##
    
    SEGMENT_MAP = {"local":"LCL",
                   "argument":"ARG",
                   "this":"THIS",
                   "that":"THAT",
                    }
    
    def writePop(self, segment, index):
        # address => R13
        self.calcAddress(segment, index, "D")
        self.write("@R13")
        self.write("M=D")
        # stack->D
        self.popToD()
        # R13 ->A
        self.write("@R13")
        self.write("A=M")
        # d-> address
        self.write("M=D")
    
    def optPushConstPushAdd(self, const):
        "Handle push const, push anything and then add/sub"
        self.writeComment("OPT: push constant, push X, sub/add")
        self.skipLine()
        factor = 1
        if (self.parser.getArgs(1)[0] == "sub"):
            factor = -1
        args = self.parser.getArgs()
        if args[0] == "constant":
            self.writeComment("OPT: compacting push const, push const, add/sub to one push")
            result = int(const) + factor*int(args[1])
            self.write("@%d"%(result))
            self.write("D=A")
            self.pushD()
        else:
            self.calcAddress(args[0], args[1], "A")
            if (const == "1"):
                if (factor == 1):
                    self.write("D=M+1")
                else:
                    self.write("D=M-1")
            elif (const == "0"):
                self.write("D=M")
            else:
                self.write("D=M")
                self.write("@%s"%(const))
                if (factor == 1):
                    self.write("D=D+A")
                else:
                    self.write("D=A-D")
                
            self.pushD()
        self.skipLine()
        
    
    def optPushConstAdd(self, const):
        "Handle add/sub right after pushing a constant"
        self.writeComment("OPT: push const, add/sub")
        self.skipLine()
        if (const == "0"):
            return
        elif (const == "1"):
            self.write("@SP")
            self.write("A=M-1")
            if (self.parser.getArgs()[0] == "add"):
                self.write("M=M+1")
            else: self.write("M=M-1")
        else: # other constant
            self.write("@%s"%const)
            self.write("D=A")
            self.write("@SP")
            self.write("A=M-1")
            if (self.parser.getArgs()[0] == "add"):
                self.write("M=D+M")
            else: self.write("M=M-D")
    
    def writePush(self, segment, index):
        if self.lookForCommand(1, self.parser.C_POP):
            self.optPushPop()
        elif (segment == "constant"):
            # look for push constant push X add/sub or push constant add/sub sequences
            if (self.lookForCommand(1, self.parser.C_PUSH) and                
               self.lookForCommand(2, self.parser.C_ARITHMETIC) and
               self.parser.getArgs(2)[0] in ("add", "sub")):
                self.optPushConstPushAdd(index)
            elif (self.lookForCommand(1, self.parser.C_ARITHMETIC) and
               self.parser.getArgs(1)[0] in ("add", "sub")):
                self.optPushConstAdd(index)
            else:                
                self.pushConstant(index)
        else:
            if self.lookForCommand(1, self.parser.C_ARITHMETIC):
                self.optPushArithmetic()
            else:
                self.calcAddress(segment, index, "A")
                self.write("D=M")
                self.pushD()
    
    def lookForCommand(self, index, *commandTypes):
        return ((index < self.parser.getBufferSize()) and
                (self.parser.commandType(index) in commandTypes))
    
    def optPushPop(self):
        self.writeComment("OPT: push, pop")
        #target address -> R14 
        args = self.parser.getArgs(1)
        self.calcAddress(args[0], args[1], "D")
        self.write("@R14")
        self.write("M=D")
        #source->D
        if self.parser.getArgs()[0] == "constant":
            const = self.parser.getArgs()[1]
            if (const in ["0","1"]):
                self.write("D=%s"%const)
            else:
                self.write("@%s"%const)
                self.write("D=A")
        else:
            args = self.parser.getArgs()
            self.calcAddress(args[0], args[1], "A")
            self.write("D=M")
        #source->target
        self.write("@R14")
        self.write("A=M")
        self.write("M=D")
        
        self.skipLine()
        
        
    
    def optPushArithmetic(self):
        aritCommand = self.parser.getArgs(1)[0]
        self.writeComment("OPT: push, %s"%aritCommand)
        pushArgs = self.parser.getArgs()
        self.skipLine()
        # put param in D
        self.calcAddress(pushArgs[0], pushArgs[1], "A")
        self.write("D=M")
        if (aritCommand in CodeWriter.BINARY_ARIT_CMDS.keys()):
            # sub add and or
            # get first param from stack into A
            self.write("@SP")
            self.write("A=M-1")
            self.write("A=M")
            if (aritCommand == "sub"):
                self.write("D=A-D")
            else:
                self.write("D=D" + CodeWriter.BINARY_ARIT_CMDS[aritCommand] + "A")
            self.DToStack()
        elif (aritCommand in ("neg", "not")):
            # push result into the stack
            self.write("@SP")
            self.write("M=M+1")
            self.write("A=M-1")
            if (aritCommand == "not"):
                self.write("M=!D")
            else: self.write("M=-D")
        else: #eq, lt, gt
            self.write("@SP")
            self.write("A=M-1")
            self.write("A=M")
            self.writeBooleanCmd(aritCommand, True)

    def writePushRegister(self, registerName):
        self.write("@%s"%registerName)
        self.write("D=M")
        self.pushD()

    def pushConstant(self, constant):
        # save on consecutive push constant of the same constant
        if (self.lastCommand != (vm_parser.Parser.C_PUSH, ["constant", constant])):
            self.write("@" + constant)
            self.write("D=A")
        else:
            self.writeComment("OPT: repeated push const")
        self.pushD()

    def pushD(self):
        self.write("@SP")
        self.write("M=M+1")
        self.write("A=M-1")
        self.write("M=D")

    def decSP(self):
        "Decrement stack pointer (doesn't change D)"
        self.write("@SP")
        self.write("M=M-1")
        
    def incSP(self):
        "Increment stack pointer (doesn't change D)"
        self.write("@SP")
        self.write("M=M+1")

    ##
    ## Arithmatic / boolean commands
    ##
    

    def writeArithmetic(self, command):
        if (command in ["eq","gt","lt"]):
            self.preBinaryOperation()
            self.writeBooleanCmd(command)
        elif(command in ["and", "or", "sub", "add"]):
            self.writeBinaryAritCmd(command)
        else:
            self.writeUnaryAritCmd(command)

    BINARY_ARIT_CMDS = {"add":"+",
                        "sub":"-",
                        "and":"&",
                        "or" :"|"}

    def writeBinaryAritCmd(self, command):
        "handle and, or, sub, add"
        self.preBinaryOperation()
        self.write("D=D" + CodeWriter.BINARY_ARIT_CMDS[command] + "A")
        self.DToStack()
    
    def preBinaryOperation(self):
        "setup two arguments in D and A from top of stack, sp--"
        self.stackToReg(13)
        self.decSP()
        self.stackToD()
        self.write("@R13")
        self.write("A=M")
    
    def writeUnaryAritCmd(self, command):
        "handle neg, not"
        self.write("@SP")
        self.write("A=M-1");
        if (command == "not"):
            self.write("M=!M")
        else:
            self.write("M=-M")
    
    
    BOOLEAN_MAPPING = {
            "eq":("JEQ", "JNE"),
            "gt":("JGT","JLE"),
            "lt":("JLT","JGE")}

    def writeBooleanCmd(self, command, dataSwap = False):
        """handle eq, gt, lt (assume D and A contain the arguments to compare,
        if dataSwap is true then the values are swapped (A and D)"""
        haveNot = 0
        if self.lookForCommand(1, self.parser.C_ARITHMETIC) and (self.parser.getArgs(1)[0]=="not"):
            self.writeComment("OPT: bool-op, not")
            haveNot = 1
        #handle boolean command followed by if
        if self.lookForCommand(1+haveNot, self.parser.C_IF):
            self.writeComment("OPT: bool-op, if")
            if (dataSwap):
                self.write("D=A-D")
            else: self.write("D=D-A")
            self.decSP()
            self.write("@%s"%self.translateLabel(self.parser.getArgs(1+haveNot)[0]))
            self.write("D; %s"%CodeWriter.BOOLEAN_MAPPING[command][haveNot])
            self.skipLine()
        else:
            #@SP
            #A = M-1
            #M = TRUE
            #@trueJump
            #if (cond) jump to trueJump
            #*SP = FALSE
            #(trueJump)
            if (dataSwap):
                self.write("D=A-D")
            else: self.write("D=D-A")
            self.write("@SP")
            self.write("A=M-1")
            self.write("M=-1")
            trueJump = self.getNextLabel()
            self.write("@" + trueJump)
            self.write("D; %s"%CodeWriter.BOOLEAN_MAPPING[command][haveNot])
            self.write("@SP")
            self.write("A=M-1")
            self.write("M=0")
            self.write("(" + trueJump + ")")
        if (haveNot):
                self.skipLine()   
   
  
    ##
    ## General helper methods
    ##
  
    def numToReg(self, num, reg):
        "Store the given number in a register (A or D)"
        self.write("@" + str(num))
        if (reg == "D"):
            self.write("D=A")

    def calcAddress(self, segment, index, reg):
        "Calculate the base+index address and store in register reg, uses D register"
        if (segment == "temp"):
            self.numToReg(5+int(index),reg)
        elif (segment == "pointer"):
            self.numToReg(3+int(index),reg)
        elif (segment == "static"):
            self.write("@%s.%s"%(os.path.basename(self.fileName), index))
            if (reg == "D"):
                self.write("D=A")
        else: #handle local, arg, this, that segments
            self.write("@" + CodeWriter.SEGMENT_MAP[segment])
            if (index == "0"):
                self.write(reg + "=M")
            elif (index == "1"):
                self.write(reg + "=M+1")
            else:
                self.write("D=M")
                self.write("@" + index)
                self.write(reg + "=D+A")  
    
    def popToD(self):
        "Pop an element from the stack to D"
        self.write("@SP")
        self.write("M=M-1") # sp--
        self.write("A=M")   # a = sp
        self.write("D=M")   # d = *a
    
    def stackToD(self):
        "Places in D register the top of the stack"
        self.write("@SP")
        self.write("A=M-1")
        self.write("D=M")
    
    def DToStack(self):
        "Places D in stack top"
        self.write("@SP")
        self.write("A=M-1")
        self.write("M=D")
    
    def stackToReg(self, regNum):
        "Places number at the top of the stack into a register"
        self.stackToD()
        self.write("@R" + str(regNum))
        self.write("M=D")



    def getNextLabel(self):
        "Creates and return a new unique label"
        self.labelCounter += 1
        return "$$LBL" + str(self.labelCounter)
    
    def translateLabel(self, label):
        "Adds the current function name to the name of the label"
        name = self.funcName
        if (name == None):
            name = "$GLOBAL"
        return "%s$%s"%(name, label)
    
    def write(self, line):
        "Writes the given line to the output file with a newline"
        if not line[0] in ('/', '('):
            self.lineCount +=1
        self.output.write(line + "\n")

    def writeComment(self, cmnt):
        "Write a comment to the output file"
        self.write("// %s (%d)"%(str(cmnt), self.lineCount))
        
    def getLineCount(self):
        return self.lineCount
    
    def skipLine(self):
        self.parser.advance()
        self.lastCommand = None
    
    HANDLERS = {
        vm_parser.Parser.C_ARITHMETIC:writeArithmetic,
        vm_parser.Parser.C_PUSH:writePush,
        vm_parser.Parser.C_POP:writePop,
        vm_parser.Parser.C_LABEL:writeLabel,
        vm_parser.Parser.C_IF:writeIf,
        vm_parser.Parser.C_GOTO:writeGoto,
        vm_parser.Parser.C_FUNCTION:writeFunction,
        vm_parser.Parser.C_RETURN:writeReturn,
        vm_parser.Parser.C_CALL:writeCall,
        }
