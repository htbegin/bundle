import sys,os
import vm_parser, code_writer

def parseArguments():
    "Returns a tuple of 2 elements - target filename and input filenames"
    name = sys.argv[1]
    if (os.path.isdir(name)):
        # get all the files from the directory ending with .vm
        vmFiles = filter(lambda x: x.endswith(".vm"), os.listdir(name))

        # add the directory name to the start of each name
        targetFile = os.path.join(name, os.path.basename(name) + ".asm")
        return (targetFile, map(lambda x: os.path.join(name, x), vmFiles))
    else:
        return (name[:-2] + "asm", [name])
    

outputFile, filelist = parseArguments()

codeWriter = code_writer.CodeWriter(outputFile)
codeWriter.writeInit()
for file in filelist:
    #print "Parsing file " + file
    parser = vm_parser.Parser(open(file, "rt"))
    codeWriter.setFileName(file, parser)
    while (parser.hasMoreCommands()):
        codeWriter.writeComment(" ".join(parser.getLine()))
        codeWriter.writeCommand(parser.commandType(), parser.getArgs())
        parser.advance()
        
codeWriter.writeCommon()
codeWriter.close()
print "Total code lines:%d"%codeWriter.getLineCount()