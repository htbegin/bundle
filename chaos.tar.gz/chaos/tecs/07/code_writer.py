import vm_parser
import os

class CodeWriter:
    
    def __init__(self, output):
        self.output = open(output, "wt")
        self.labelCounter = 0
        self.staticCounter = 0
    
    def setFileName(self, name):
        self.fileName = name
    
    def writeArithmetic(self, command):
        self.writeComment(command)
        if (command in ["eq","gt","lt"]):
            self.writeBooleanCmd(command)
        elif(command in ["and", "or", "sub", "add"]):
            self.writeBinaryAritCmd(command)
        else:
            self.writeUnaryAritCmd(command)
    
    SEGMENT_MAP = {"local":"LCL",
                   "argument":"ARG",
                   "this":"THIS",
                   "that":"THAT",
                    }
    
    def writePushPop(self, commandType, segment, index):
        self.writeComment("%d, %s, %s"%(commandType,segment, index))
        if (commandType == vm_parser.Parser.C_PUSH):
            self.writePush(segment, index)
        else:
            self.writePop(segment, index)
    
    def writePop(self, segment, index):
        # address => R13
        self.calcAddress(segment, index, "D")
        self.writeln("@R13")
        self.writeln("M=D")
        # stack->D
        self.stackToD()
        # R13 ->A
        self.writeln("@R13")
        self.writeln("A=M")
        # d-> address
        self.writeln("M=D")
        # sp--
        self.decSP()
    
    def writePush(self, segment, index):
        if (segment == "constant"):
            self.pushConstant(index)
        else:
            self.calcAddress(segment, index, "A")
            self.writeln("D=M")
            self.incSP()
            self.DToStack()

    def numToReg(self, num, reg):
        "Store the given number in a register (A or D)"
        self.writeln("@" + str(num))
        if (reg == "D"):
            self.writeln("D=A")

    def calcAddress(self, segment, index, reg):
        "Calculate the base+index address and store in register reg"
        if (segment == "temp"):
            self.numToReg(5+int(index),reg)
        elif (segment == "pointer"):
            self.numToReg(3+int(index),reg)
        elif (segment == "static"):
            self.writeln("@%s.%s"%(os.path.basename(self.fileName), index))
            if (reg == "D"):
                self.writeln("D=A")
        else:
            self.writeln("@" + CodeWriter.SEGMENT_MAP[segment])
            self.writeln("D=M")
            self.writeln("@" + index)
            self.writeln(reg + "=D+A")

    def pushConstant(self, constant):
        self.writeln("@" + constant)
        self.writeln("D=A")
        self.incSP()
        self.DToStack()

    
    def close(self):
        self.output.close()

    BINARY_ARIT_CMDS = {"add":"+",
                        "sub":"-",
                        "and":"&",
                        "or" :"|"}

    def writeBinaryAritCmd(self, command):
        "handle and, or, sub, add"
        self.preBinaryOperation()
        self.writeln("D=D" + CodeWriter.BINARY_ARIT_CMDS[command] + "A")
        self.DToStack()
    
    def preBinaryOperation(self):
        "setup two arguments in D and A from top of stack, sp--"
        self.stackToReg(13)
        self.decSP()
        self.stackToD()
        self.writeln("@R13")
        self.writeln("A=M")
    
    def writeUnaryAritCmd(self, command):
        "handle neg, not"
        self.stackToD()
        if (command == "not"):
            self.writeln("M=!M")
        else:
            self.writeln("M=-M")
        
    def writeBooleanCmd(self, command):
        "handle eq, gt, lt"
        # get 2 params to A and D
        # D = D-A
        # @trueLabel
        # if (cond) jump to trueLabel
        # D = FALSE
        # jump to continueLabel
        # (trueLabel)
        # D = TRUE
        # (continueLabel)
        # write D to stack
        self.preBinaryOperation()
        self.writeln("D=D-A")
        trueJump = self.getNextLabel()
        self.writeln("@" + trueJump)
        self.writeln("D; J" + command.upper())
        self.writeln("D=0")
        continueJump = self.getNextLabel()
        self.writeln("@" + continueJump)
        self.writeln("0;JMP")
        self.writeln("(" + trueJump + ")")
        self.writeln("D=-1")
        self.writeln("(" + continueJump + ")")
        self.DToStack()

    def getNextLabel(self):
        "Return the next indexed label for this output stream"
        self.labelCounter += 1
        return "LBL" + str(self.labelCounter)
    
    def writeln(self, line):
        "Writes the given line to the output file with a newline"
        self.output.write(line + "\n")
        
    def writeComment(self, cmnt):
        "Write a comment to the output file"
        self.writeln("//" + cmnt)
    
    def stackToD(self):
        "Places in D register the top of the stack"
        self.writeln("@SP")
        self.writeln("A=M-1")
        self.writeln("D=M")
    
    def DToStack(self):
        "Places D in stack top"
        self.writeln("@SP")
        self.writeln("A=M-1")
        self.writeln("M=D")
    
    def stackToReg(self, regNum):
        "Places number at the top of the stack into a register"
        self.stackToD()
        self.writeln("@R" + str(regNum))
        self.writeln("M=D")

    def decSP(self):
        "Decrement stack pointer"
        self.writeln("@SP")
        self.writeln("M=M-1")
        
    def incSP(self):
        "Increment stack pointer"
        self.writeln("@SP")
        self.writeln("M=M+1")