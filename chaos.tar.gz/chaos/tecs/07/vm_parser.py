import re

class Parser:
    "Parser for VM files"
    
    #command types
    C_ARITHMETIC = 1
    C_PUSH       = 2
    C_POP        = 3
    C_LABEL      = 4
    C_GOTO       = 5
    C_IF         = 6
    C_FUNCTION   = 7
    C_RETURN     = 8
    C_CALL       = 9
    
    COMMAND_HASH = {"push":C_PUSH,
                    "pop":C_POP,
                    "add":C_ARITHMETIC,
                    "sub":C_ARITHMETIC,
                    "neg":C_ARITHMETIC,
                    "eq":C_ARITHMETIC,
                    "gt":C_ARITHMETIC,
                    "lt":C_ARITHMETIC,
                    "and":C_ARITHMETIC,
                    "or":C_ARITHMETIC,
                    "not":C_ARITHMETIC,
                    }
    
    def __init__(self, stream):
        self.stream = stream
        self.storedLine = None
        self.hasMoreCommands()
        
    def getLine(self):
        return self.line
    
    def getNextLineFromStream(self):
        "Returns the next line from the stream of None if there isn't any"
        line = None
        while(True):
            line = self.stream.readline()
            if (line == ""):
                return None
            # remove comments from the line
            commentIndex = line.find("//")
            if (commentIndex != -1):
                line = line[:commentIndex]
            # split the command into the different parts (max 3)
            if (line.strip() != ""):
                return re.split("\W+", line)

    
    def hasMoreCommands(self):
        "return true if there are more command in the input"
        if (self.storedLine == None):
            line = self.getNextLineFromStream()
            if (line == None):
                return False
            else:
                self.storedLine = line
                return True
        else:
            return True
    
    def advance(self):
        "Move to the next line"
        assert self.hasMoreCommands()
        self.line = self.storedLine
        self.storedLine = None

    
    def commandType(self):
        "returns one of C_* constants"
        return Parser.COMMAND_HASH[self.line[0]]

    def arg1(self):
        if (self.commandType() == Parser.C_ARITHMETIC):
            return self.line[0]
        else: return self.line[1]
    
    def arg2(self):
        return self.line[2]
