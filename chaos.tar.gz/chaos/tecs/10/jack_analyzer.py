
import jack_tokenizer, compilation_engine

import sys,os,glob

# create input file list
if (os.path.isdir(sys.argv[1])):
    inputFiles = glob.glob(sys.argv[1]+ os.sep + "*.jack")
else:
    inputFiles = [sys.argv[1]]
    
#process each file
for file in inputFiles:
    print "working on %s"%file
    tokenizer = jack_tokenizer.JackTokenizer(open(file, "rt"))
    engine = compilation_engine.CompilationEngine(tokenizer, file[:-5]+".xml")
    engine.compileClass()
    engine.close()


