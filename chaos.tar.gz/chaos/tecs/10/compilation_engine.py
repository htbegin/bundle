import xml_writer
from jack_tokenizer import JackTokenizer

class CompilationEngine:
    def __init__(self, tokenStream, outputFilename):
        self.tokenStream = tokenStream
        self.output = xml_writer.XMLWriter(open(outputFilename, "wt"))
        
    def close(self):
        self.output.close()
    
    
    TYPE_MAP = {JackTokenizer.IDENTIFIER: "identifier",
           JackTokenizer.INT_CONST: "integerConstant",
           JackTokenizer.SYMBOL:"symbol",
           JackTokenizer.STRING_CONST:"stringConstant",
           JackTokenizer.KEYWORD:"keyword"}
    
    def assertType(self, type, val= None):
        assert self.tokenStream.tokenType() == type
        if (val != None):
            assert self.tokenStream.tokenValue() == val
        
    
    def outputToken(self):
        self.output.element(CompilationEngine.TYPE_MAP[self.tokenStream.tokenType()],
                            self.tokenStream.tokenValue())
        self.advance()
    
    #'class' className '{' classVarDec* subroutineDec* '}'
    def compileClass(self):
        self.advance()
        self.output.start("class")
        self.outputToken()
        self.assertType(JackTokenizer.IDENTIFIER)
        self.outputToken()
        self.assertType(JackTokenizer.SYMBOL, '{')
        self.outputToken()
        #check var dec
        while (True):
            if (self.tokenStream.tokenType() == JackTokenizer.KEYWORD and
                self.tokenStream.tokenValue() in ('static', 'field')):
                self.compileClassVarDec()
            else:
                break
        while (True):
            if (self.tokenStream.tokenType() == JackTokenizer.KEYWORD and
                self.tokenStream.tokenValue() in ('constructor', 'function', 'method')):
                self.compileSubroutineDec()
            else:
                break
        # the }
        self.assertType(JackTokenizer.SYMBOL, '}')
        self.outputToken()
        self.output.end()

    #('static' | 'field' ) type varName (',' varName)* ';'
    def compileClassVarDec(self):
        self.output.start("classVarDec")
        # static/field
        self.assertType(JackTokenizer.KEYWORD)
        self.outputToken()
        #type
        self.outputToken()
        #varName
        self.assertType(JackTokenizer.IDENTIFIER)
        self.outputToken()
        
        #more var names or ;
        while(self.tokenStream.tokenValue() == ','):
            self.outputToken()
            # var name
            self.outputToken()
        # output ;
        self.processSymbol(';')
        self.output.end()
        
    
    #('constructor' | 'function' | 'method') ('void' | type)
    #       subroutineName '(' parameterList ')' subroutineBody
    def compileSubroutineDec(self):
        self.output.start("subroutineDec")
        
        #'constructor' | 'function' | 'method'
        self.assertType(JackTokenizer.KEYWORD)
        self.outputToken()
        #'void' | type
        self.outputToken()
        #subroutineName
        self.assertType(JackTokenizer.IDENTIFIER)
        self.outputToken()
        
        self.processSymbol('(')
        
        #parameter list
        self.compileParameterList()
        
        self.processSymbol(')')
        
        self.output.start('subroutineBody')
        self.processSymbol('{')
        
        #possible varDec
        while (self.tokenStream.tokenValue() == "var"):
            self.compileVarDec()
        
        self.compileStatements()        
        self.processSymbol('}')
        self.output.end()
        self.output.end()
    
    def processSymbol(self, symbol):
        self.assertType(JackTokenizer.SYMBOL, symbol)
        self.outputToken()
    
    #( (type varName) (',' type varName)*)?
    def compileParameterList(self):
        self.output.start("parameterList")
        
        if (self.tokenStream.tokenType() in
            (JackTokenizer.IDENTIFIER, JackTokenizer.KEYWORD)):
            #type
            self.outputToken()
            #varName
            self.outputToken()
            
            while (self.tokenStream.tokenValue() == ','):
                self.outputToken()
                #type
                self.outputToken()
                #varName
                self.outputToken()
        
        self.output.end()
    
    def advance(self):
        self.tokenStream.advance()
    
    #'var' type varName (',' varName)* ';'
    def compileVarDec(self):
        self.output.start("varDec")
        
        self.assertType(JackTokenizer.KEYWORD, "var")
        #var
        self.outputToken()
        #type
        self.outputToken()
        #varName
        self.assertType(JackTokenizer.IDENTIFIER)
        self.outputToken()
        
        #more var names or ;
        while(self.tokenStream.tokenValue() == ','):
            self.outputToken()
            # var name
            self.outputToken()
        # output ;
        self.processSymbol(';')
        
        self.output.end()
    
    def compileStatements(self):
        self.output.start("statements")
        
        while (self.tokenStream.tokenType() == JackTokenizer.KEYWORD):
            val = self.tokenStream.tokenValue()
            if (val== "if"):
                self.compileIf()
            elif (val == "let"):
                self.compileLet()
            elif (val == "do"):
                self.compileDo()
            elif (val == "while"):
                self.compileWhile()
            elif (val == "return"):
                self.compileReturn()
            else:
                break
        
        
        self.output.end()
    
    #'do' subroutineCall ';'
    def compileDo(self):
        self.output.start("doStatement")
        #do
        self.outputToken()
        self.subroutineCall()
        self.processSymbol(';')
        self.output.end()
    
    #    subroutineName '(' expressionList ')' |
    #    ( className | varName) '.' subroutineName '(' expressionList ')'
    def subroutineCall(self, readFirstToken = True):
        # identifier - sub name or className or varName
        if (readFirstToken):
            self.outputToken()
        self.assertType(JackTokenizer.SYMBOL)
        if (self.tokenStream.tokenValue() == "."):
            # output the dot
            self.processSymbol('.')
            
            # sub name in case it is a class method
            self.outputToken()
            
        self.processSymbol("(")
        self.compileExpressionList()
        self.processSymbol(")")

    #'let' varName ('[' expression ']')? '=' expression ';'
    def compileLet(self):
        self.output.start("letStatement")
        #let
        self.outputToken()
        self.assertType(JackTokenizer.IDENTIFIER)
        #varName
        self.outputToken()
        if (self.tokenStream.tokenValue() == '['):
            self.processSymbol('[')
            self.compileExpression()
            self.processSymbol(']')
        self.processSymbol('=')
        self.compileExpression()
        self.processSymbol(';')
        self.output.end()
    
    #'while' '(' expression ')' '{' statements '}'
    def compileWhile(self):
        self.output.start('whileStatement')
        
        #while
        self.outputToken()
        self.processSymbol('(')
        self.compileExpression()
        self.processSymbol(')')
        self.processSymbol('{')
        self.compileStatements()
        self.processSymbol('}')
        
        self.output.end()
    
    #'return' expression? ';'
    def compileReturn(self):
        self.output.start("returnStatement")
        #return
        self.outputToken()
        if (self.tokenStream.tokenValue() != ";"):
            self.compileExpression()
        self.processSymbol(';')
        self.output.end()
    
    #'if' '(' expression ')' '{' statements '}' ( 'else' '{' statements '}' )?
    def compileIf(self):
        self.output.start('ifStatement')
        #if
        self.outputToken()
        self.processSymbol('(')
        self.compileExpression()
        self.processSymbol(')')
        self.processSymbol('{')
        self.compileStatements()
        self.processSymbol('}')
        if ((self.tokenStream.tokenType() == JackTokenizer.KEYWORD) and
           (self.tokenStream.tokenValue() == 'else')):
            #else
            self.outputToken()
            self.processSymbol('{')
            self.compileStatements()
            self.processSymbol('}')
        self.output.end()

    #term (op term)*
    def compileExpression(self):
        self.output.start("expression")
        
        self.compileTerm()
        
        while (self.tokenStream.tokenValue() in ('+','-','*','/','&','|','<','>','=')):
            self.outputToken()
            self.compileTerm()
            
        self.output.end()
    
    #  integerConstant | stringConstant | keywordConstant | varName |
    #  varName '[' expression ']' | subroutineCall | '(' expression ')' |
    #  unaryOp term
    def compileTerm(self):
        self.output.start("term")
        
        tokenType = self.tokenStream.tokenType()
        tokenValue = self.tokenStream.tokenValue()
        
        #term is int/String Constant
        if (tokenType in (JackTokenizer.STRING_CONST, JackTokenizer.INT_CONST)):
            self.outputToken()
        
        #term is keywordConstant
        elif(tokenType == JackTokenizer.KEYWORD and
            tokenValue in ("true", "false", "null", "this")):
            self.outputToken()
        
        #term is '(' expression ')' or unaryOp term
        elif(tokenType == JackTokenizer.SYMBOL):
            if (tokenValue == '('):
                self.processSymbol('(')
                self.compileExpression()
                self.processSymbol(')')
            else:
                assert tokenValue in ('-','~')
                self.processSymbol(tokenValue)
                self.compileTerm()
        
        #term is IDENTIFIER
        elif(tokenType == JackTokenizer.IDENTIFIER):
            self.outputToken()
            #Next is symbol -> not a standalone identifier
            if (self.tokenStream.tokenType() == JackTokenizer.SYMBOL):
                tokenValue = self.tokenStream.tokenValue()
                #array access
                if (tokenValue == '['):
                    self.processSymbol('[')
                    self.compileExpression()
                    self.processSymbol(']')
                #subroutineCall (call method indicating token was already read)
                elif(tokenValue in ('.','(')):
                    self.subroutineCall(False)
                else:
                    pass
        
        self.output.end()
    
    #(expression (',' expression)* )?
    def compileExpressionList(self):
        self.output.start("expressionList")
        
        if (self.tokenStream.tokenValue() != ')'):
            self.compileExpression()
            #(',' expression)*
            while (self.tokenStream.tokenValue() == ','):
                self.processSymbol(',')
                self.compileExpression()
        
        self.output.end()

