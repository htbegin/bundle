import string

class Parser:
    #command types
    A_COMMAND = 1
    C_COMMAND = 2
    L_COMMAND = 3
    
    def __init__(self, stream):
        self.stream = stream
        self.storedLine = None
        self.hasMoreCommands()
        
    def getLine(self):
        return self.line
    
    def getNextLineFromStream(self):
        "Returns the next line from the stream of None if there isn't any"
        line = None
        while(True):
            line = self.stream.readline()
            if (line == ""):
                return None
            # remove whitespace
            line = line.translate(string.maketrans("", ""), string.whitespace)
            if not (line.startswith("//") or line == ""):
                break
        # remove comments from the line
        commentIndex = line.find("//")
        if (commentIndex != -1):
            line = line[:commentIndex]
        return line
    
    def hasMoreCommands(self):
        "return true if there are more command in the input"
        if (self.storedLine == None):
            line = self.getNextLineFromStream()
            if (line == None):
                return False
            else:
                self.storedLine = line
                return True
        else:
            return True
    
    def advance(self):
        "Move to the next line"
        assert self.hasMoreCommands()
        self.line = self.storedLine
        self.storedLine = None

    
    def commandType(self):
        "Returns command type (L/C/A_COMMAND)"
        if (self.line.startswith("@")):
            return Parser.A_COMMAND
        elif (self.line.startswith("(")):
            return Parser.L_COMMAND
        else: return Parser.C_COMMAND;
    
    def symbol(self):
        commandType = self.commandType() 
        if(commandType == Parser.A_COMMAND):
            return self.line[1:]
        elif (commandType == Parser.L_COMMAND):
            return self.line[1:-1]
        else: raise "symbol called on wrong command"
    
    def dest(self):
        if (self.commandType() != Parser.C_COMMAND):
            raise "Wrong command type"
        i = self.line.find('=')
        if (i != -1):
            return self.line[:i]
        else:
            return ""

    
    def comp(self):
        if (self.commandType() != Parser.C_COMMAND):
            raise "Wrong command type"
        s = self.line.find('=')
        if (s == -1): s = -1
        e = self.line.find(";")
        if (e == -1): e = len(self.line)
        return self.line[s+1:e]

    def jump(self):
        if (self.commandType() != Parser.C_COMMAND):
            raise "Wrong command type"
        i = self.line.find(';')
        if (i != -1):
            return self.line[i+1:]
        else:
            return ""
