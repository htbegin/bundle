def tobin(x, count=15):
    """
    Integer to binary
    Count is number of bits
    """
    return "".join(map(lambda y:str((x>>y)&1), range(count-1, -1, -1)))
    
class Code:
    # jump encoding
    JUMP_HASH = {""   :"000",
                 "JGT":"001",
                 "JEQ":"010",
                 "JGE":"011",
                 "JLT":"100",
                 "JNE":"101",
                 "JLE":"110",
                 "JMP":"111"}
    
    COMP_HASH = {"0"  :"101010",
                 "1"  :"111111",
                 "-1" :"111010",
                 "D"  :"001100",
                 "A"  :"110000",
                 "!D" :"001101",
                 "!A" :"110001",
                 "-D" :"001111",
                 "-A" :"110011",
                 "D+1":"011111",
                 "A+1":"110111",
                 "D-1":"001110",
                 "A-1":"110010",
                 "D+A":"000010",
                 "D-A":"010011",
                 "A-D":"000111",
                 "D&A":"000000",
                 "D|A":"010101"}
    
    def dest(self, s):
        dest = ""
        if (s.find("A") != -1):
            dest += "1";
        else: dest += "0"
        if (s.find("D") != -1):
            dest += "1";
        else: dest += "0"
        if (s.find("M") != -1):
            dest += "1";
        else: dest += "0"
        return dest
    
    def jump(self, s):
        return Code.JUMP_HASH[s] 
    
    def comp(self, s):
        comp = ""
        m_index = s.find("M")
        #Search for 'M', if found, set first bit to 1 and replace with 'A'
        if (m_index != -1):
            comp += "1"
        else:
            comp += "0"
        return comp + Code.COMP_HASH[s.replace('M','A')]
    
    def addressCommand(self, num):
        return "0" + tobin(int(num), 15)

