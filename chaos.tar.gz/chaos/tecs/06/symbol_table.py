class SymbolTable:
    def __init__(self):
        " add initial values"
        self.table = {}
        self.addEntry("SP", 0)
        self.addEntry("LCL", 1)
        self.addEntry("ARG", 2)
        self.addEntry("THIS", 3)
        self.addEntry("THAT", 4)
        for i in xrange(16):
            self.addEntry("R" + str(i), i)
        self.addEntry("SCREEN", 0x4000)
        self.addEntry("KBD", 0x6000)
        
    def addEntry(self, symbol, address):
        self.table[symbol]=address
        
    def contains(self,  symbol):
        return self.table.has_key(symbol)
    
    def getAddress(self, symbol):
        return self.table[symbol]