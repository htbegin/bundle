import asm_parser, code2

import tempfile, sys

def removeIndirectReference(f):
    "Convert the indirect syntax to 2 commands"
    import re
    pattern = re.compile(r".*\[(.*)\].*")
    output = tempfile.TemporaryFile(mode="w+t", prefix="ASSEMBLY_TEMP")
    parser = asm_parser.Parser(f)
    while (parser.hasMoreCommands()):
        parser.advance()
        line = parser.getLine()
        if (parser.commandType() == parser.C_COMMAND):
            # check if this line contains the syntax '[something]'
            match = pattern.match(line)
            if (match):
                # generate an address command
                output.write("@"+ match.group(1)+"\n")
                line = line.replace('['+match.group(1)+']', "")
        output.write(line+"\n")
    return output

def generateSymbolTable(f):
    "Find all the labels in the program and generate a symbol table"
    import symbol_table
    symbol_tbl = symbol_table.SymbolTable()
    parser = asm_parser.Parser(f)
    
    line_num = 0;
    while(parser.hasMoreCommands()):
        parser.advance()
        if(parser.commandType() == parser.L_COMMAND):
            if not symbol_tbl.contains(parser.symbol()):
                symbol_tbl.addEntry(parser.symbol(), line_num)
        else: line_num += 1
    
    return symbol_tbl
    
def generateCode(f, symbolTable):
    "Generate binary code for the program"
    outFilename = sys.argv[1][:-3]+"hack"
    out = open(outFilename, "wt")
    parser = asm_parser.Parser(f)
    codeGen = code.Code();
    varAddress = 16
    
    while(parser.hasMoreCommands()):
        parser.advance();
        if (parser.commandType() == parser.A_COMMAND):
            symbol = parser.symbol()
            #handle lable/variable
            if not symbol[0].isdigit():
                # check the symbol table for this symbol
                if not (symbolTable.contains(symbol)):
                    symbolTable.addEntry(symbol, varAddress)
                    varAddress += 1
                #get the Address for the symbol
                symbol = symbolTable.getAddress(symbol)
            out.write(codeGen.addressCommand(symbol)+"\n")
        # handle computation commands
        elif (parser.commandType() == parser.C_COMMAND):
            out.write("111" + codeGen.comp(parser.comp()) +
                              codeGen.dest(parser.dest()) +
                              codeGen.jump(parser.jump()) +
                              "\n")
        


def main():
    f = open(sys.argv[1], "rt")
    f = removeIndirectReference(f)
    
    f.seek(0)
    symbolTable = generateSymbolTable(f)
    
    
    f.seek(0)
    generateCode(f, symbolTable)
    
    f.close()
    

main()
