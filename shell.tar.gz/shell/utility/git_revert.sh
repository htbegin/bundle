#!/bin/bash

all_files=$(git status --short | grep '^[ AM][MD]' | awk '{print $2}')

echo "modified files:"
echo
for file in ${all_files}
do
	echo "${file}"
done
echo

answer=""
for file in ${all_files}
do
	while ! [[ "${answer}" =~ [yanq] ]]
	do
		echo -n "revert ${file} (y/a/n/q)? "
		read answer
	done

	case "${answer}" in
		"y" )
		answer=""
		echo "revert ${file}"
		git checkout -- "${file}"
		;;
		"a" )
		echo "revert ${file}"
		git checkout -- "${file}"
		;;
		"n" )
		answer=""
		;;
		"q" )
		answer=""
		exit 0
		;;
	esac
done
