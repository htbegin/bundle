#!/bin/sh
exec /usr/lib/firefox-3.6/firefox -P ff36 $@

