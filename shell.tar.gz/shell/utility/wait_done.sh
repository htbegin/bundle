#!/bin/sh

if test -z "$1"
then
	echo "$0 process_name" >&2
	exit 1
fi

while ps -C "$1" >/dev/null
do
	sleep 5
done

notify-send "now process $1 exits"
exit 0
