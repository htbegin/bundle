#! /bin/sh

function assert_true()
{
	if ! eval "$1"
	then
		echo "Error: expression [$1] at $2:$3 assert fail" >&2
	fi
}

function device_already_mounted()
{
	assert_true "test -n $1" "$FUNCNAME" "$LINENO"
	local dev=$1

	if test -n "$(cat /proc/mounts | grep -o "^$dev")"
	then
		echo "1"
	else
		echo "0"
	fi
}

function device_umount()
{
	assert_true "test -n $1" "$FUNCNAME" "$LINENO"
	assert_true "test -n $2" "$FUNCNAME" "$LINENO"
	local dev=$1
	local dir=$2

	mounted=$(device_already_mounted $dev)
	if test "$mounted" -eq 1
	then
		umount $dir
	else
		echo "Debug: $dev hasn't been mounted"
	fi
}

device_array=( \
		"//192.168.1.109/htbegin" \
		"//192.168.1.145/htbegin" \
		"//192.168.1.74/htbegin" \
		"//192.168.1.144/htbegin" \
		"//192.168.1.110/htbegin"
)
point_array=( \
		"/media/One" \
		"/media/Two" \
		"/media/Three" \
		"/media/Four" \
		"/media/Unique"
)
index=0
device_cnt=${#device_array[*]}
point_cnt=${#point_array[*]}
assert_true "test $device_cnt -eq $point_cnt" "Global" "$LINENO"

while test "$index" -lt "$device_cnt"
do
	device=${device_array[$index]}
	point=${point_array[$index]}
	device_umount $device $point
	let "index+=1"
done

