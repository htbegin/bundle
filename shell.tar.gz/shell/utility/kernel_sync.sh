#!/bin/sh

remote_host=192.168.1.233

# sync uImage
rsync -av /var/lib/tftpboot/uImage root@${remote_host}:/var/lib/tftpboot/

# sync modules
rsync -av --delete /dm6446/nfs/lib/modules/ public@${remote_host}:/dm6446/nfs/lib/modules
