#! /bin/sh

# description:
#	monitor cpu usage of a process.
#	if its usage exceeds the limit, kill it and restart it 2 min later
# author: hotforest@gmail.com
# history:
#	V0.1 2010-07-25
#		init version


function monitor_cpu_usage()
{
	local prog=$1
	local upper_bound_usage=$2
	local internal=$3
	local pid
	local usage
	local result

	pid=$(pgrep -x $prog)

	while true
	do
		usage=$(top -b -n 1 -p $pid | awk '/^[[:space:]]*'$pid'/ { print $9 }')
		if test -z "$usage"
		then
			echo "program $prog has exited"
		fi
		result=$(echo "$usage<=$upper_bound_usage" | bc)
		if test "$result" -eq 0
		then
			echo "$prog is out-of-control, kill it"
			pkill -x "$prog"
			sleep 2m
			echo "restart $prog"
			$prog &
			sleep 10
			pid=$(pgrep -x $prog)
		else
			echo "$prog under control"
		fi
		sleep $internal
	done
}

monitor_cpu_usage amule 50 2
