#!/bin/sh

xclip -o -selection clipboard | tr "\n" " " | xclip -i -selection clipboard

