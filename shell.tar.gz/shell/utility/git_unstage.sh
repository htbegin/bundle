#!/bin/bash

all_files=$(git status --short | grep '^[MAD]' | awk '{print $2}')

echo "staged files:"
echo
for file in ${all_files}
do
	echo "${file}"
done
echo

answer=""
for file in ${all_files}
do
	while ! [[ "${answer}" =~ [yanq] ]]
	do
		echo -n "unstage ${file} (y/a/n/q)? "
		read answer
	done

	case "${answer}" in
		"y" )
		answer=""
		echo "unstage ${file}"
		git reset HEAD "${file}"
		;;
		"a" )
		echo "unstage ${file}"
		git reset HEAD "${file}"
		;;
		"n" )
		answer=""
		;;
		"q" )
		answer=""
		exit 0
		;;
	esac
done
