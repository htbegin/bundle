#!/bin/bash
# color definitions

# normal
SETCOLOR_NORMAL="echo -en \\033[0;39m"
# white
SETCOLOR_DEBUG="echo -en \\033[1;37m"
# purple
SETCOLOR_ETRACE="echo -en \\033[1;35m"
# green
SETCOLOR_INFO="echo -en \\033[1;32m"
# red
SETCOLOR_ERROR="echo -en \\033[1;31m"

