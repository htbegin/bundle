#!/bin/sh
# description: assert functions for test
# author: houtao <houtao@hisome.com>
# history:
#	V1.0 alpha edition

function debug_echo()
{
	if test -n "$1"
	then
		$SETCOLOR_DEBUG
		echo "$1"
		$SETCOLOR_NORMAL
	fi
}

function info_echo()
{
	if test -n "$1"
	then
		$SETCOLOR_INFO
		echo "$1"
		$SETCOLOR_NORMAL
	fi
}

function error_echo()
{
	if test -n "$1"
	then
		$SETCOLOR_ERROR
		echo "$1" >&2
		$SETCOLOR_NORMAL
	fi
}

function assert_not_null()
{
	local func="$1"
	local line="$2"
	local value="$3"

	if test -z "$value"
	then
		error_echo "in $func:$line $FUNCNAME fail"
	fi
}

function assert_true()
{
	local func="$1"
	local line="$2"
	local expression="$3"

	if ! eval "$expression"
	then
		error_echo "in $func:$line $FUNCNAME fail"
	fi
}

function assert_example()
{
	assert_not_null "$FUNCNAME" "$LINENO" "$1"

	local dir="$HOME"

	assert_true "$FUNCNAME" "$LINENO" "test -d $dir"
}

if test -z "$ASSERT_MODULE_MODE"
then
	assert_example "god"
fi

