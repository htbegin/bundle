#! /bin/sh
# description: demonstrate the signal handler in bash

. ./log.sh

log_level="$DEBUG_LOG_LEVEL"

function get_all_blockable_signal()
{
	local kill_signal stop_signal
	local all_signal blockable_signal

	kill_signal=9
	stop_signal=19

	all_signal=$(seq 1 64)
	# must be echo "$variable", that ensure that
	# the signals are outputed line by line
	blockable_signal=$(echo "$all_signal" | \
			sed "/\<$kill_signal\>\|\<$stop_signal\>/d")

	# must be echo $variable that ensure the signals
	# are outputed word by word
	echo $blockable_signal
}

function block_all_blockable_signal()
{
	local rval=0
	local blockable_signal

	blockable_signal=$(get_all_blockable_signal)

	if test -n "$blockable_signal"
	then
		if ! trap '' $blockable_signal >/dev/null 2>&1
		then
			etrace_log "execute trap fail"
			rval=1
		fi
	else
		etrace_log "no blockable signals"
		rval=1
	fi

	return "$rval"
}

function unblock_all_blockable_signal()
{
	local rval=0
	local blockable_signal

	blockable_signal=$(get_all_blockable_signal)

	if test -n "$blockable_signal"
	then
		if ! trap - $blockable_signal >/dev/null 2>&1
		then
			etrace_log "execute trap fail"
			rval=1
		fi
	else
		etrace_log "no blockable signals"
		rval=1
	fi

	return "$rval"
}

if test -z "$SIGNAL_MODULE_MODE"
then
	trap -p
	block_all_blockable_signal
	debug_log "block all blockable signals"
	/bin/sleep 5
	unblock_all_blockable_signal
	debug_log "unblock all blockable signals"
	/bin/sleep 5
fi

