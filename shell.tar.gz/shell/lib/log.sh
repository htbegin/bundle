# Description: definition of log functions

# constant definition
ERROR_LOG_LEVEL=1
INFO_LOG_LEVEL=2
ETRACE_LOG_LEVEL=3
DEBUG_LOG_LEVEL=4
MIN_LOG_LEVEL="$ERROR_LOG_LEVEL"
MAX_LOG_LEVEL="$DEBUG_LOG_LEVEL"

# global variable
log_level="$ETRACE_LOG_LEVEL"

# function definition
function error_log()
{
	if test -n "$1" && test "$log_level" -ge "$ERROR_LOG_LEVEL"
	then
		$SETCOLOR_ERROR
		echo "$1" >&2
		$SETCOLOR_NORMAL
	fi
}

function info_log()
{
	if test -n "$1" && test "$log_level" -ge "$INFO_LOG_LEVEL"
	then
		$SETCOLOR_INFO
		echo "$1"
		$SETCOLOR_NORMAL
	fi
}

function etrace_log()
{
	if test -n "$1" && test "$log_level" -ge "$ETRACE_LOG_LEVEL"
	then
		$SETCOLOR_ETRACE
		echo "$1" >&2
		$SETCOLOR_NORMAL
	fi
}

function debug_log()
{
	if test -n "$1" && test "$log_level" -ge "$DEBUG_LOG_LEVEL"
	then
		$SETCOLOR_DEBUG
		echo "$1"
		$SETCOLOR_NORMAL
	fi
}

if test -z "$LOG_MODULE_MODE"
then
	log_level="$MAX_LOG_LEVEL"
	error_log "error message"
	info_log "info message"
	etrace_log "etrace message"
	debug_log "debug message"
fi

