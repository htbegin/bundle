#! /bin/sh
# Description: common routines for filesystem.
# Author: hotforest@gmail.com
# History:
#	alpha edition: 2010-03-04

function mount_device()
{
	local rval=0
	local device="$1" dir="$2"
	local result

	assert_not_null "$FUNCNAME" "$LINENO" "$device"
	assert_not_null "$FUNCNAME" "$LINENO" "$dir"

	assert_true "$FUNCNAME" "$LINENO" "test -b $device"
	assert_true "$FUNCNAME" "$LINENO" "test -d $dir"

	mount "$device" "$dir"
	result="$?"
	if test "$result" -ne 0
	then
		etrace_log "mount $device on $dir fail with exit status $result"
		rval=1
	fi

	return "$rval"
}

function umount_device()
{
	local rval=0
	local device="$1"
	local umount_cnt umount_seq
	local mounted_cnt
	local result

	assert_not_null "$FUNCNAME" "$LINENO" "$device"
	assert_true "$FUNCNAME" "$LINENO" "test -b $device"

	mounted_cnt=$(mount | grep -c "^$device[[:space:]]\+")

	if test "$mounted_cnt" -eq 0
	then
		debug_log "device $device hasn't been mounted"
	else
		info_log "device $device has been mounted $mounted_cnt times"
	fi

	umount_cnt=0
	while test "$umount_cnt" -lt "$mounted_cnt"
	do
		umount "$device"
		result="$?"
		if test "$result" -ne 0
		then
			let "umount_seq=umount_cnt+1"
			etrace_log "the "$umount_seq"th umount of $device fail with exit status $result"
			rval=1
			break
		fi
		let "umount_cnt+=1"
	done

	return "$rval"
}

