#!/bin/bash

eval $(xdotool getmouselocation --shell)
if test ${X} -le 1440
then
	let "NX=X+1440"
else
	let "NX=X-1440"
fi

xdotool mousemove --sync ${NX} ${Y}

