#!/bin/bash

function wait_until_show()
{
	local ptn="$1"

	until wmctrl -l | grep "${ptn}"
	do
		sleep 2
	done
}

# VirtualBox desktop 1
start_xp.sh

# Gnome Terminal desktop 2
wmctrl -s 1
ptn="$(whoami)@localhost"
cwd=$(cat ${HOME}/Bin/cfg/cwd | sed -n 's/^\s*\|\s*$//p')
if test -n "${cwd}"
then
	cwd_option="--working-directory ${cwd}"
fi
gnome-terminal --maximize ${cwd_option} --window --tab --tab &
wait_until_show "${ptn}"

# Firefox desktop 3
wmctrl -s 2
ptn="Mozilla Firefox"
firefox &
wait_until_show "${ptn}"

# stay on desktop 2
wmctrl -s 1
