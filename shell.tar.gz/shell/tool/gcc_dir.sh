#!/bin/sh

commands="-print-file-name=libc \
	 -print-libgcc-file-name \
	 -print-multi-directory  \
	 -print-multi-lib  \
	 -print-multi-os-directory \
	 -print-prog-name=program  \
	 -print-search-dirs  \
	 -print-sysroot \
	 -print-sysroot-headers-suffix"

for cmd in $commands
do
	gcc $cmd
	echo
done

