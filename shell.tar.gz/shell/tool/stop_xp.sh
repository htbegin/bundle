#!/bin/sh

if VBoxManage list runningvms | awk '{print $1}' | grep '^"xp"' >/dev/null 2>&1
then
	VBoxManage controlvm xp savestate >/dev/null 2>&1
	if test "${?}" -eq 0
	then
		notify-send "xp stop succeed"
	else
		notify-send "xp stop fail"
	fi
else
	notify-send "xp has stopped"
fi
