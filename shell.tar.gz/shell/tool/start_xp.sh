#!/bin/sh

if VBoxManage list runningvms | awk '{print $1}' | grep '^"xp"' >/dev/null 2>&1
then
	notify-send "xp has started"
else
	VBoxManage startvm xp >/dev/null 2>&1
	if test "${?}" -eq 0
	then
		notify-send "xp start succeed"
	else
		notify-send "xp start fail"
	fi
fi
wmctrl -r xp -t 0
wmctrl -s 1
