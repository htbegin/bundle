#!/bin/bash

# instruct VirtualBox to halt when the guest os: Windows XP becomes blue-screen.

VBoxManage setextradata "name" "VBoxInternal/PDM/HaltOnReset" 1
