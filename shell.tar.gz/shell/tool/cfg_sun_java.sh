#!/bin/sh

function generate_slave_cfg()
{
	local link_base_path="$1"
	local slaves="$2"
	local base_path="$3"
	local link_path
	local slave
	local path
	local all_cfg=""

	for slave in $slaves
	do
		link_path=$link_base_path/$slave
		path=$base_path/$slave

		if ! test -L "$link_path"
		then
			echo "$link_path doesn't exist, so there is no need to config alternative for it" >&2
			continue
		fi

		if test -f "$path"
		then
			all_cfg="$all_cfg --slave $link_path $slave $path"
		else
			echo "$path doesn't exist, couldn't setup alternative for $link_path" >&2
		fi
	done
	echo "$all_cfg"
}

sun_jre_path="/usr/java/latest"
java_bin_slaves="javaws keytool orbd pack200 rmid rmiregistry servertool \
			tnameserv unpack200 jre_exports jre"
java_man1_slaves="java.1.gz keytool.1.gz orbd.1.gz pack200.1.gz rmid.1.gz \
			rmiregistry.1.gz servertool.1.gz tnameserv.1.gz unpack200.1.gz"

link_base_path=/usr/bin
slaves=$java_bin_slaves
base_path=$sun_jre_path/bin
bin_slave_cfg=$(generate_slave_cfg "$link_base_path" "$slaves" "$base_path")

link_base_path=/usr/share/man/man1
slaves=$java_man1_slaves
base_path=$sun_jre_path/man/man1
gzip $base_path/*.1 2>/dev/null
man1_slave_cfg=$(generate_slave_cfg "$link_base_path" "$slaves" "$base_path")

alternatives --install /usr/bin/java java $sun_jre_path/bin/java 140 \
				$bin_slave_cfg $man1_slave_cfg

