#!/bin/sh
ssh -o ProxyCommand="git_git.sh %h %p" $@
