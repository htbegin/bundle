#!/bin/sh
# common options
pkg_base_dir="/home/htbegin/Movie"
output_base_dir="/home/htbegin/Tmp/repo"
file_name_option="--unique-md-filenames"
create_db_option="--database"

# specific options
release_old_pkg_dir=""
release_pkg_dir="Mirror/releases/13/Everything/i386/os/Packages"
release_output_dir="release"
release_output_option="-o $output_base_dir/$release_output_dir"
release_delta_option="--deltas"

update_old_pkg_dir="$release_pkg_dir"
update_pkg_dir="Mirror/updates/13/i386"
update_output_dir="update"
update_output_option="-o $output_base_dir/$update_output_dir"
update_delta_option="--deltas --oldpackagedirs $pkg_base_dir/$update_old_pkg_dir"

# create repodata for release
createrepo $file_name_option $create_db_option $release_delta_option \
			   $release_output_option $pkg_base_dir/$release_pkg_dir

# create repodata for update
createrepo $file_name_option $create_db_option $update_delta_option \
			   $update_output_option $pkg_base_dir/$update_pkg_dir

