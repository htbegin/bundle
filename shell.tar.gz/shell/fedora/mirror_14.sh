#!/bin/bash

dry_run_option=""
script_dir=$(dirname $0)

if test "$1" = "-n"
then
	dry_run_option="--dry-run"
elif test -n "$1"
then
	bwlimit_option="--bwlimit $1"
fi
if test -n "$2"
then
	bwlimit_option="--bwlimit $2"
fi

excludes=$script_dir/14_excludes

remote_path=rsync://mirrors.sohu.com/fedora/

local_path=/media/Go/linux_dist/mirror/fedora

rsync $dry_run_option -vaH --exclude-from=${excludes} --numeric-ids \
		--delete --delete-delay --delay-updates $bwlimit_option \
		$remote_path $local_path

