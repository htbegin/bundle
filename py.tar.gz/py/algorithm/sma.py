#! /usr/bin/python
# -*- coding: utf8 -*-

from collections import deque
import itertools

def moving_average(iterable, n=3):
    # moving_average([40, 30, 50, 46, 39, 44]) --> 40.0 42.0 45.0 43.0
    # http://en.wikipedia.org/wiki/Moving_average
    # simple moving average: A[k] = (S[k-1] + P[k] - P[k-n]) / n
    it = iter(iterable)
    d = deque(itertools.islice(it, n - 1))
    d.appendleft(0)
    s = sum(d)
    for elem in it:
        s += elem - d.popleft()
        d.append(elem)
        yield s / float(n)

if __name__ == "__main__":
    for i in moving_average([40, 30, 50, 46, 39, 44]):
        print i
