#! /usr/bin/env python
# -*- coding: utf8 -*-

"""
all kinds of sort algorithms implemented in python
"""

def stl_middle_value(first, sec, third):
    if first > sec:
        # [f, s, t]
        if sec > third:
            mvalue = sec
        # [f, t, s]
        elif first > third:
            mvalue = third
        # [t, f, s]
        else:
            mvalue = first
    else:
        # [s, f, t]
        if first > third:
            mvalue = first
        # [s, t, f]
        elif sec > third:
            mvalue = third
        # [t, s, f]
        else:
            mvalue = sec

    return mvalue

def stl_quick_sort(input, begin, end):
    # [begin, end]
    if begin >= end:
        return

    pivot_value = stl_middle_value(input[begin], input[end],
            input[begin+(end-begin+1)/2])

    left = begin
    right = end
    while True:
        # no need to worry about the out-of-range problem
        # in the first loop, left and right will stop
        # at some position and left <= right
        # in the following loop, left will not exceed the right boundary which
        # is marked by right, so will right.
        while input[left] < pivot_value: left += 1
        while input[right] > pivot_value: right -= 1
        if left < right:
            input[left], input[right] = input[right], input[left]
            left += 1
            right -= 1
        else:
            break

    # now all elements in [begin, pivot_index-1] are not greater than a value
    # and all elements in [pivot_index, end] are not smaller than a same value
    pivot_index = left
    stl_quick_sort(input, begin, pivot_index-1)
    stl_quick_sort(input, pivot_index, end)

if __name__=="__main__":
    import random

    input = range(100)
    random.shuffle(input)
    stl_quick_sort(input, 0, len(input)-1)
