#!/usr/bin/env python
# -*- coding: utf8 -*-

import sys

_enable_dbg = False

def partition(array):
    cnt = len(array)
    assert cnt % 2 == 0
    sum = 0
    for e in array:
        sum += e
    first_level = []
    for i in range(cnt + 1):
        sec_level = []
        for j in range(cnt / 2 + 1):
            third_level = []
            for k in range(sum / 2 + 1):
                third_level.append(dict(val=0,idx_list=[]))
            sec_level.append(third_level)
        first_level.append(sec_level)
    s = first_level

    for all_cnt in range(1, cnt + 1):
        for sub_cnt in range(1, min(all_cnt, cnt / 2) + 1):
            for max_val in range(1, sum / 2 + 1):
                first_val = s[all_cnt - 1][sub_cnt][max_val]["val"]
                first_idx_list = s[all_cnt - 1][sub_cnt][max_val]["idx_list"]
                if array[all_cnt - 1] <= max_val:
                    sec_val = s[all_cnt - 1][sub_cnt - 1][max_val - array[all_cnt - 1]]["val"] + \
                            array[all_cnt - 1]
                    sec_idx_list = s[all_cnt - 1][sub_cnt - 1][max_val - array[all_cnt - 1]]["idx_list"]
                if array[all_cnt - 1] <= max_val and first_val < sec_val:
                    s[all_cnt][sub_cnt][max_val]["val"]  = sec_val
                    s[all_cnt][sub_cnt][max_val]["idx_list"].extend(sec_idx_list)
                    s[all_cnt][sub_cnt][max_val]["idx_list"].append(all_cnt - 1)
                else:
                    s[all_cnt][sub_cnt][max_val]["val"] = first_val
                    s[all_cnt][sub_cnt][max_val]["idx_list"].extend(first_idx_list)
                if _enable_dbg:
                    sys.stdout.write("s[%d][%d][%d][\"val\"] = %d\n" %
                            (all_cnt, sub_cnt, max_val, s[all_cnt][sub_cnt][max_val]["val"]))

    return (int(s[cnt][cnt / 2][sum / 2]["val"]), s[cnt][cnt / 2][sum / 2]["idx_list"])
