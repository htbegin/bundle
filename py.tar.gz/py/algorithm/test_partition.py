#!/usr/bin/env python
# -*- coding: utf8 -*-

import unittest

from partition import partition

class TestPartition(unittest.TestCase):
    def setUp(self):
        global enable_dbg

    def test_partition_1(self):
        array = [1, 2, 3, 9]
        sum, small_idx_list = partition(array)
        self.assertEqual(sum, 5)
        self.assertEqual(small_idx_list, [1, 2])

    def test_partition_2(self):
        array = [8, 3, 45, 5, 12, 7]
        sum, small_idx_list = partition(array)
        self.assertEqual(sum, 27)
        self.assertEqual(small_idx_list, [0, 4, 5])

    def test_partition_3(self):
        array = [8, 44, 45, 7]
        sum, small_idx_list = partition(array)
        self.assertEqual(sum, 52)
        half = [2, 3]
        another_half = [x for x in range(len(array)) if x not in half]
        try:
            self.assertEqual(small_idx_list, half)
        except AssertionError:
            self.assertEqual(small_idx_list, another_half)

if __name__ == "__main__":
    unittest.main()
