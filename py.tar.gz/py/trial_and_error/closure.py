#!/usr/bin/env python

def outter(d):
    def inner():
        if "a" in d:
            d["a"] += 1
        else:
            d["a"] = 1
    return inner

map = {"b" : 1}

f_a = outter(map)
f_b = outter(map)

f_a()
f_b()

print map
