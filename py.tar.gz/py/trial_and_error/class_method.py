#!/usr/bin/env python
# -*- coding: utf8 -*-

class C:
    @staticmethod
    def sf(arg):
        print "invoke static method with arg", arg
    @classmethod
    def cf(cls, arg):
        print "invoke class method with arg", cls, arg
    def inf(self, arg):
        print "invoke instance method with arg", self, arg

obj = C()

print obj.sf
print obj.cf.im_self, obj.cf.im_func
print obj.inf.im_self, obj.inf.im_func

C.sf("class")
obj.sf("instance")

C.cf("class")
obj.cf("instance")

obj.inf("instance")
