#!/usr/bin/env python

from ctypes import *

class God(Structure):
    def __init__(self):
        self.c = ['a', 'b']

    _fields_ = [
            ('a', c_int),
            ('b', c_int)
            ]

g = God()
print dir(g)
print g.__dict__

g.a = 1
print g.a, g.b, g.c

print g._fields_
print g._objects

print sizeof(g)

g_ptr = pointer(g)
new_g = g_ptr.contents

new_g.a = 2

print g.a, g.b, g.c

print addressof(g)
print addressof(new_g)
print id(g)
print id(new_g)
