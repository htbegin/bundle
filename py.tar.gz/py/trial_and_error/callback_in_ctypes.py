#!/usr/bin/env python
# -*- coding: utf8 -*-

import ctypes

_cb = ctypes.CFUNCTYPE(ctypes.c_char_p, ctypes.c_char_p)

def translate(text):
    return text

c_translate = _cb(translate)
