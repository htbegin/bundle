#!/usr/bin/env python
# -*- coding: utf8 -*-

class A(object):
    def __int__(self):
        pass

    def get(self, percent):
        return percent

a = A()

p = a.get(1.0)
print a.get
print p

def alternative_get(percent):
    return percent
a.get = alternative_get
p = a.get(1.0)
print a.get
print p

