#!/usr/bin/env python
# -*- coding: utf8 -*-

import sys
import os
import fnmatch
import subprocess

dir_dict={}
ignore_dict={}
common_patterns=["*.mod.c", ".*.cmd", "*.ko"]

def update_dir_dict(fname):
    fname = fname.strip()
    if not os.path.exists(fname):
        print "%s doesn't exist" % fname
        return

    parent = os.path.dirname(fname)
    base = os.path.basename(fname)
    if not parent:
        parent = "."

    if parent not in dir_dict:
        dir_dict[parent] = []

    dir_dict[parent].append(base)

def generate_ignore_patterns(dir_dict):
    for key, value in dir_dict.iteritems():
        ignore_dict[key] = []
        for entry in value:
            matched = False
            for ptn in common_patterns:
                if fnmatch.fnmatch(entry, ptn):
                    if ptn not in ignore_dict[key]:
                        ignore_dict[key].append(ptn)
                    matched = True
                    break
            if not matched:
                ignore_dict[key].append(entry)

def get_dir_ignore_patterns(name):
    cmd = ["svn", "pg", "svn:ignore", name]
    output = subprocess.Popen(cmd, stdout=subprocess.PIPE).communicate()[0]
    ptns = output.split("\n")
    return [ptn for ptn in ptns if ptn]

def commit_ignore_patterns(ignore_dict):
    fname = "pattern"
    for key, value in ignore_dict.iteritems():
        old_ptns = get_dir_ignore_patterns(key)
        value.extend(old_ptns)
        value = list(set(value))
        ptns = "\n".join(value)
        with open(fname, "wb") as fd:
            fd.write(ptns)
        cmd = ["svn", "ps", "svn:ignore", "-F", fname, key]
        subprocess.check_call(cmd)

pwd = os.getcwd()
print pwd
for line in sys.stdin:
    update_dir_dict(line)

generate_ignore_patterns(dir_dict)

commit_ignore_patterns(ignore_dict)

for key, value in ignore_dict.iteritems():
    print key
    print value
    print
