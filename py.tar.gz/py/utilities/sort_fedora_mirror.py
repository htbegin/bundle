#!/usr/bin/env python
# -*- coding: utf8 -*-

import lxml.html
import urllib2


def extract_mirror_url(element):
    try:
        url = element.find("span").find("a").get("href")
    except Exception:
        url = ""
    return url


def extract_fedora_mirrors(handle):
    global max_bandwidth

    root = lxml.html.parse(handle).getroot()
    div = root.find_class("keepleft")[0]
    table = div.find("table")
    even_rows = table.find_class("even")
    odd_rows = table.find_class("odd")
    even_rows.extend(odd_rows)
    all_row = even_rows

    all_mirror = []
    for row in all_row:
        mirror = {}
        cells = row.findall("td")
        country, site, host, content, bandwidth, i2, comments = cells
        mirror["country"] = country.text_content()
        mirror["site"] = site.text_content()
        mirror["host"] = host.text_content()

        url_table = content.find("table")
        name, http, ftp, rsync = url_table.findall("tr")[0].findall("td")
        mirror["http"] = extract_mirror_url(http)
        mirror["ftp"] = extract_mirror_url(ftp)
        mirror["rsync"] = extract_mirror_url(rsync)

        mirror["bandwidth"] = int(bandwidth.text_content())
        if i2.text_content().find("Yes") != -1:
            mirror["i2"] = True
        else:
            mirror["i2"] = False

        all_mirror.append(mirror)

    for mirror in all_mirror:
        if mirror["bandwidth"] > max_bandwidth:
            max_bandwidth = mirror["bandwidth"]

    return all_mirror


def mirror_key(mirror):
    weight = 0
    if mirror["rsync"]:
        weight += 100

    weight += mirror["bandwidth"] * 10.0 / max_bandwidth

    if mirror["i2"]:
        weight += 1

    return weight


if __name__ == "__main__":
    max_bandwidth = 1
    page_handle = urllib2.urlopen("http://mirrors.fedoraproject.org/publiclist/Fedora/14/i386/")
    all_mirror = extract_fedora_mirrors(page_handle)
    all_mirror.sort(key = mirror_key, reverse = True)
    for mirror in all_mirror:
        if mirror["rsync"] and mirror["bandwidth"] >= 1000 and mirror["i2"]:
            print "# %s Mbps I2" % mirror["bandwidth"]
            print "#remote_path=%s/" % mirror["rsync"]

