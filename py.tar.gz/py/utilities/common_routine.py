#! /usr/bin/env python
# -*- coding: ascii -*-

import logging

def new_logger(name):
	logger=logging.getLogger(name)
	logger.setLevel(logging.DEBUG)
	logger.propagate=False
	# create console handler and set level to debug
	handler=logging.StreamHandler()
	# create formatter
	formatter=logging.Formatter("%(levelname)s:%(name)s:%(message)s.")
	# add formatter to handler
	handler.setFormatter(formatter)
	# add handler to logger
	logger.addHandler(handler)

	return logger

if __name__ == "__main__":
	logger=new_logger("test")
	logger.debug("debug output")

