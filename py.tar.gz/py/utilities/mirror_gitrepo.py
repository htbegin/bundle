#!/usr/bin/python
# -*- coding: utf8 -*-

import sys
import os.path
import subprocess


def execute_cmd(cmd):
    rval = 0
    cmd_str = " ".join(cmd)

    try:
        ret = subprocess.call(cmd)
        if ret != 0:
            print "execute %s fail" % cmd_str
            rval = 1
    except OSError, err:
        print "os error %s" % str(err)
        rval = 1

    return rval

def is_mounted(dir):
    rval = False
    with open("/proc/mounts", "rb") as fd:
        for line in fd:
            if line.find(dir) != -1:
                rval = True
                break
    return rval

def generate_cifs_dev_dir(site):
    return "".join(("192.168.1.", site, ":htbegin/backup")),\
            "".join(("/home/work/Backup/rt_", site))

def mount_cifs_site(site):
    dev, dir = generate_cifs_dev_dir(site)
    if not is_mounted(dir):
        cmd = ["sudo", "mount", "-t", "cifs", "-o", "guest", dev, dir]
        execute_cmd(cmd)

def umount_cifs_site(site):
    dev, dir = generate_cifs_dev_dir(site)
    if is_mounted(dir):
        cmd = ["sudo", "umount", dir]
        execute_cmd(cmd)

def backup_repo(repo, sites):
    old_cwd = os.getcwd()
    os.chdir(repo)

    for s in sites:
        print "mirror %s to %s" % (repo, s)
        umount_cifs_site(s)
        mount_cifs_site(s)

        remote = "".join(("rt_", s, "_bu"))
        backup_cmd = ["sudo", "git", "push", remote]
        execute_cmd(backup_cmd)

        umount_cifs_site(s)
        print ""

    os.chdir(old_cwd)

def parse_global_sites(fd, global_tag):
    global_sites = []
    for line in fd:
        if line.startswith(global_tag):
            global_sites=line[len(global_tag):].split()
            break

    return global_sites

def backup_repos(cfg_file):
    global_tag = "global"
    comment_tag = "#"
    with open(cfg_file, "rb") as fd:
        global_sites = parse_global_sites(fd, global_tag)

        fd.seek(0)
        line_num = 0
        for line in fd:
            line_num += 1
            line = line.strip()
            if line.startswith(global_tag) or line.startswith(comment_tag) or \
                    not line:
                continue
            repo_cfg = line.split(None, 1)
            if len(repo_cfg) == 1:
                repo = repo_cfg[0]
                local_sites_str = ""
            else:
                repo, local_sites_str = repo_cfg
            if os.path.isdir(repo):
                sites = local_sites_str.split()
                sites.extend(global_sites)
                backup_repo(repo, sites)
            else:
                print "invalid cfg line", line_num
                continue

if __name__ == "__main__":
    self_dir = os.path.abspath(os.path.dirname(sys.argv[0]))
    cfg_file = os.path.join(self_dir, "mirror_cfg")
    backup_repos(cfg_file)
