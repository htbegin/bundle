#! /usr/bin/env python
# -*- coding: utf8 -*-

import sys
import subprocess
import os
import glob
import shutil

def parse_title(info, file):
    title = ""
    title_info = info.splitlines()[0]
    if title_info.find("Title") == 0:
        raw_title = title_info.split(":")[1].lstrip()
        title = raw_title
        replace_dict = {" ":"_", "'":"", "/":"_"}
        for old, new in replace_dict.iteritems():
            title = title.replace(old, new)
    else:
        print "no title info available for", file
    return title

def extract_pdf_title(src_file):
    title = ""
    cmd = "pdfinfo"
    args = [cmd, src_file]
    fd = subprocess.Popen(args, stdout=subprocess.PIPE)
    info = fd.communicate()[0]
    if fd.returncode == 0:
        title = parse_title(info, src_file)
    else:
        print 'invalid pdf file', src_file
    return title

def rename_pdf(base, fname):
    src_file = "{0}/{1}".format(base, fname)

    title = extract_pdf_title(src_file)
    if title:
        insert_pos = src_file.rfind(".pdf")
        dst_file = "{0}_{1}{2}".format(src_file[0:insert_pos],
                title, src_file[insert_pos:])
        shutil.copy(src_file, dst_file)

def rename_all_pdf(dir):
    base = os.path.abspath(dir)
    glob_pattern = "{0}/*.pdf".format(base)
    for pdf in glob.iglob(glob_pattern):
        fname = os.path.basename(pdf)
        if fname.find("_") < 0:
            rename_pdf(base, fname)

if __name__ == "__main__":
    if len(sys.argv) >= 2:
        for dir in sys.argv[1:]:
            if os.path.isdir(dir):
                rename_all_pdf(dir)
