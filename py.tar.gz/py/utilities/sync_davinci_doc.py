#! /usr/bin/env python
# -*- coding: utf8 -*-

import sys
import os
from optparse import OptionParser, OptionValueError
import re
from string import Template
import logging
from datetime import datetime
import sqlite3
from urllib import quote
import urllib2
import cookielib

import lxml.html

from common_routine import new_logger

g_valid_models = ("6446", "6467", "8168")

class SDDError(Exception):
    def __init__(self, msg):
        self.msg = msg

    def __str__(self):
        return repr(self.msg)


class SDDInvalidHtmlFormatError(SDDError):
    def __init__(self, err):
        super(SDDInvalidHtmlFormatError, self).__init__("invalid html "
                "format, error: %s" % err)


class SDDInvalidURLError(SDDError):
    def __init__(self, url):
        super(SDDInvalidURLError, self).__init__("invalid url: %s" % url)

class SDDUnsupportedDocURLError(SDDError):
    def __init__(self, url, title):
        super(SDDUnsupportedDocURLError, self).__init__("unsupported doc "
        "url %s with title %s" % (url, title))


class DavinciDoc(object):
    """ document """
    def __init__(self, catalog, type, date, title, url):
        self.catalog = catalog
        self.type = type
        self.date = date
        self.title = title
        self.url = url


class DavinciDocSrc(object):
    """ document source. """
    INVALID_DOC_CNT = -1
    model_url_template = Template("http://focus.ti.com/dsp/docs/"
            "dspsupporttechdocs.tsp?"
            "sectionId=3&tabId=409&viewType=mostrecent&rootFamilyId=44&"
            "familyId=${fid}&docCategoryId=${cid}")
    catalogs = (
            {"name" : "application_notes", "abbr" : "an", "id" : 1,
                "enable" : True},
            {"name" : "data_sheet", "abbr" : "ds", "id" : 2,
                "enable" : True},
            {"name" : "errata", "abbr" : "er", "id" : 3,
                "enable" : True},
            {"name" : "simulation_models", "abbr" : "mo", "id" : 4,
                "enable" : True},
            {"name" : "more_literature", "abbr" : "ml", "id" : 5,
                "enable" : True},
            {"name" : "user_guides", "abbr" : "ug", "id" : 6,
                "enable" : True},
            {"name" : "whiter_papers", "abbr" : "wp", "id" : 9,
               "enable" : True},
            {"name" : "selection_guides", "abbr" : "sg", "id" : 10,
                "enable" : True},
            {"name" : "solution_guides", "abbr" : "sl", "id" : 11,
                "enable" : True},
            )
    model_fid_map = {"6446" : 1302, "6467" : 1506, "8168" : 2001}
    def __init__(self, model, debug):
        assert model in g_valid_models
        assert isinstance(debug, bool)
        self.model = model
        self.logger = new_logger("DavinciDocSrc")
        if not debug:
            self.logger.setLevel(logging.INFO)
        self.catalog_url_template = Template(self.model_url_template.
                safe_substitute(fid=self.model_fid_map[self.model]))
        self.catalog_idx = 0
        self.catalog_doc_cnt = self.INVALID_DOC_CNT
        self.catalog_doc_idx = 0
        self.catalog_cnt = len(self.catalogs)

    @staticmethod
    def get_catalogs():
        return (catalog["name"] for catalog in DavinciDocSrc.catalogs)

    def __parse_doc_cnt(self, text):
        # text contains "Showing xx of xx results"
        pattern = r"Showing (\d+) of \d+ results"
        match_obj = re.search(pattern, text)
        if match_obj.group(1) is not None:
            return int(match_obj.group(1))
        else:
            return -1

    def __parse_doc_date(self, text):
        # text contains substring likes "08 Jun 2010"
        result = None
        month_ptn = r"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
        pattern = r"(\d{2} " + month_ptn + r" \d{4})"
        match_obj = re.search(pattern, text)
        doc_date_text = match_obj.group(1)
        if doc_date_text is not None:
            fmt = "%d %b %Y"
            try:
                doc_datetime = datetime.strptime(doc_date_text, fmt)
            except ValueError:
                self.logger.error("invalid format %s for doc date %s" %
                        (fmt, doc_date_text))
                result = None
            except Exception, err:
                self.logger.error("unexpected error: %s" % str(err))
                result = None
            else:
                result = doc_datetime.date().isoformat()

        return result

    def __parse_bundle_subdoc_url(self, parent_url, doc):
        strong_tag = doc.find("strong")
        if strong_tag is None:
            self.logger.error("invalid html format for url %s, expected "
                    "strong tag in li tag, but got none" % parent_url)
            return None
        strong_a_tag = strong_tag.find("a")
        if strong_a_tag is None:
            self.logger.error("invalid html format for url %s, expected "
                    "a tag in strong tag, but got none" % parent_url)
            return None
        url = strong_a_tag.get("href")
        if url is None:
            self.logger.error("invalid html format for url %s, expected "
                    "href attribute in a tag, but got none" % parent_url)
            return None
        if not self.__is_single_doc_url(url):
            self.logger.error("invalid html format for url %s, expected "
                    "a single doc url, but got %s" % (parent_url, url))
            return None
        return url

    def __parse_bundle_doc_info(self, parent):
        childrent = []

        url = parent["url"]
        try:
            tree = lxml.html.parse(url)
        except IOError:
            self.logger.error("parse url %s of bundle doc %s fail" %
                    (url, parent["title"]))
            return []
        except Exception, err:
            raise SDDError("unexpected error: %s" % str(err))

        RESULT_CLASS = "srchRsltsList"
        RESULT_CLASS_CNT = 1
        root_ele = tree.getroot()
        result_ele_list = root_ele.find_class(RESULT_CLASS)
        if len(result_ele_list) != RESULT_CLASS_CNT:
            self.logger.error("expect %d class %s, get %d" %
                    (RESULT_CLASS_CNT, RESULT_CLASS, len(result_ele_list)))
            return []

        result_ele = result_ele_list[0]
        DOC_CLASS = "pdf"
        DOC_TAG = "li"
        doc_set_ele_list = result_ele.find_class(DOC_CLASS)
        for doc_set_ele in doc_set_ele_list:
            doc_ele_list = doc_set_ele.findall(DOC_TAG)
            for doc_ele in doc_ele_list:
                sub_url = self.__parse_bundle_subdoc_url(url, doc_ele)
                if sub_url is None:
                    continue
                child = dict(parent)
                child["url"] = sub_url
                child["type"] = self.__get_single_doc_type(sub_url)
                child["id"] = self.__get_single_doc_id(sub_url)
                childrent.append(child)

        return childrent

    def __is_bundle_doc_url(self, url):
        prefix="http://focus.ti.com/dsp/docs/litabsmultiplefilelist.tsp"
        if url.startswith(prefix):
            return True
        else:
            return False

    def __get_single_doc_type(self, url):
        assert self.__is_single_doc_url(url)
        comm_prefix = "http://www.ti.com/litv/"
        return url[len(comm_prefix):].split("/")[0]

    def __get_single_doc_id(self, url):
        assert self.__is_single_doc_url(url)
        comm_prefix = "http://www.ti.com/litv/"
        return url[len(comm_prefix):].split("/")[1]

    def __is_single_doc_url(self, url):
        rval = False
        comm_prefix="http://www.ti.com/litv/"
        doc_types = ["pdf", "zip", "mp3", "mp4", "wmv", "ibs"]
        for type in doc_types:
            type_prefix = "".join((comm_prefix, type, "/"))
            if url.startswith(type_prefix) and \
                    "/" not in url[len(type_prefix):]:
                rval = True
                break

        return rval

    def __parse_sub_doc_info(self, parent):
        url = parent["url"]

        if self.__is_bundle_doc_url(url):
            return self.__parse_bundle_doc_info(parent)

        if self.__is_single_doc_url(url):
            parent["type"] = self.__get_single_doc_type(url)
            parent["id"] = self.__get_single_doc_id(url)
            return [parent,]
        else:
            raise SDDUnsupportedDocURLError(url, parent["title"])

    def __parse_doc_info(self, element):
        dinfo = {}
        class_attr = element.get("class")
        if  class_attr == "abstract":
            dinfo["type"] = "unknown"
        elif class_attr == None:
            dinfo["type"] = "pdf"
        else:
            raise SDDInvalidHtmlFormatError("invalid class attribute %s " %
                    "for tag %s" % (class_attr, element.tag))

        doc_date_text = element.text_content()
        if not doc_date_text:
            raise SDDInvalidHtmlFormatError("no text content for tag %s" %
                    element.tag)
        doc_date = self.__parse_doc_date(doc_date_text)
        if doc_date is None:
            raise SDDInvalidHtmlFormatError("invalid doc date info in text "
                    "content %s for tag %s" % (doc_date_text, element.tag))
        dinfo["date"] = doc_date

        tag = "b"
        b_tag = element.find(tag)
        if b_tag is None:
            raise SDDInvalidHtmlFormatError("no tag %s for doc url under "
                    "tag %s" % (tag, element.tag))
        tag = "a"
        b_a_tag = b_tag.find(tag)
        if b_a_tag is None:
            raise SDDInvalidHtmlFormatError("no tag %s for doc url under "
                    "tag %s" % (tag, b_tag.tag))

        attr = "href"
        url = b_a_tag.get(attr)
        if url is None:
            raise SDDInvalidHtmlFormatError("no attribute %s in tag %s" %
                    (attr, b_a_tag.tag))
        encoding = "utf8"
        try:
            doc_url = url.decode(encoding)
        except UnicodeError:
            raise SDDInvalidHtmlFormatError("%s isn't suitable for url %s" %
                    (encoding, url))
        except Exception, err:
            raise SDDError("unexpected error: %s" % str(err))
        dinfo["url"] = doc_url

        title = b_a_tag.text_content()
        if not title:
            raise SDDInvalidHtmlFormatError("no title in tag %s" %
                    b_a_tag.tag)
        encoding = "utf8"
        try:
            title = title.encode(encoding)
        except UnicodeError:
            raise SDDInvalidHtmlFormatError("%s isn't suitable for encoding "
                    "title %s" % (encoding, title))
        except Exception, err:
            raise SDDError("unexpected error: %s" % str(err))
        try:
            doc_title = title.decode(encoding)
        except UnicodeError:
            raise SDDInvalidHtmlFormatError("%s isn't suitable for decoding "
                    "title %s" % (encoding, title))
        except Exception, err:
            raise SDDError("unexpected error: %s" % str(err))
        dinfo["title"] = doc_title

        if dinfo["type"] == "pdf":
            if self.__is_single_doc_url(dinfo["url"]):
                dinfo["id"] = self.__get_single_doc_id(dinfo["url"])
                return [dinfo]
            else:
                raise SDDInvalidHtmlFormatError("expected a single doc url "
                        "for pdf file, got %s" % dinfo["url"])
        else:
            return self.__parse_sub_doc_info(dinfo)

    def __generate_doc_download_url(self, catalog, doc):
        dl_url_template = Template("http://focus.ti.com/lit/"
                "${catalog}/${id}/${id}.${type}")
        type = doc["type"]
        id = self.__get_single_doc_id(doc["url"])
        return dl_url_template.substitute(catalog=catalog, id=id, type=type)

    def __beautify_doc_title(self, title):
        pattern="[,.]?[ /:]+(- )?"
        repl="_"
        return re.sub(pattern,repl,title.strip())

    def __parse_catalog_info(self, url):
        RESULT_CLASS = "srchRsltsList"
        MIN_RESULT_CLASS_CNT = 1
        try:
            tree = lxml.html.parse(url)
        except IOError:
            raise SDDInvalidURLError(url)
        except Exception, err:
            raise SDDError("unexpected error: %s" % str(err))

        root_ele = tree.getroot()
        result_ele_list = root_ele.find_class(RESULT_CLASS)
        if len(result_ele_list) < MIN_RESULT_CLASS_CNT:
            self.logger.debug("for url '%s', expect equal-or-greater-than "
                    "%d class %s, get %d" %
                    (url, MIN_RESULT_CLASS_CNT,
                        RESULT_CLASS, len(result_ele_list)))
            self.logger.info("%s doesn't have catalog '%s'" %
                    (self.model, self.catalogs[self.catalog_idx]["name"]))
            self.catalog_docs = []
            return

        top_result_ele = result_ele_list[0]

        tag = "p"
        doc_cnt_text = top_result_ele.findtext(tag)
        if doc_cnt_text is None:
            raise SDDInvalidHtmlFormatError("no tag %s for result cnt" % tag)
        doc_cnt_text = doc_cnt_text.strip("\t\r\n ")
        self.logger.debug("catalog %s has doc cnt text: %s" %
                (self.catalogs[self.catalog_idx]["name"], doc_cnt_text))
        doc_cnt = self.__parse_doc_cnt(doc_cnt_text)
        if doc_cnt <= 0:
            raise SDDInvalidHtmlFormatError("invalid result cnt text %s" %
                    doc_cnt_text)

        DOC_CLASS = "pdf"
        MIN_DOC_CLASS_CNT = 1
        doc_set_ele_list = top_result_ele.find_class(DOC_CLASS)
        if len(doc_set_ele_list) < MIN_DOC_CLASS_CNT:
            raise SDDInvalidHtmlFormatError("expect equal or greater than "
                "%d class %s, get %d" % (MIN_DOC_CLASS_CNT,DOC_CLASS,
                    len(doc_set_ele_list)))

        tag = "li"
        doc_ele_list = []
        for doc_set_ele in doc_set_ele_list:
            doc_ele_list.extend(doc_set_ele.findall(tag))

        if len(doc_ele_list) != doc_cnt:
            raise SDDInvalidHtmlFormatError("expect %d tag %s, get %d" %
                    (doc_cnt, tag, len(doc_ele_list)))

        cname = self.catalogs[self.catalog_idx]["name"]
        abbr_cname = self.catalogs[self.catalog_idx]["abbr"]
        self.catalog_docs = []
        for doc_ele in doc_ele_list:
            docs = self.__parse_doc_info(doc_ele)
            for doc in docs:
                dl_url = self.__generate_doc_download_url(abbr_cname, doc)
                doc["url"] = dl_url
                doc["catalog"] = cname
                doc["title"] = self.__beautify_doc_title(doc["title"])
            self.catalog_docs.extend(docs)

    def __prepare_catalog(self):
        assert self.catalog_idx >= 0
        assert self.catalog_idx < self.catalog_cnt
        ct = self.catalogs[self.catalog_idx]
        ct_url = self.catalog_url_template.safe_substitute(cid = ct["id"])
        self.__parse_catalog_info(ct_url)
        self.catalog_doc_cnt = len(self.catalog_docs)
        self.catalog_doc_idx = 0

    def __assert_for_valid_catalog_doc(self):
        assert self.catalog_idx >= 0
        assert self.catalog_idx < self.catalog_cnt
        assert self.catalog_doc_cnt != self.INVALID_DOC_CNT
        assert self.catalog_doc_idx >= 0
        if self.catalog_doc_cnt > 0:
            assert self.catalog_doc_idx < self.catalog_doc_cnt
        else:
            assert self.catalog_doc_idx == 0

    def __inc_catalog_doc_idx(self):
        self.__assert_for_valid_catalog_doc()
        self.catalog_doc_idx += 1
        if self.catalog_doc_idx >= self.catalog_doc_cnt:
            self.catalog_idx += 1
            self.catalog_doc_cnt = self.INVALID_DOC_CNT

    def __fetch_catalog_doc(self):
        self.__assert_for_valid_catalog_doc()
        doc = self.catalog_docs[self.catalog_doc_idx]
        self.__inc_catalog_doc_idx()
        return doc

    def __iter__(self):
        return self

    def next(self):
        if self.catalog_idx >= self.catalog_cnt:
            raise StopIteration
        if self.catalog_doc_cnt == self.INVALID_DOC_CNT:
            self.__prepare_catalog()
        if self.catalog_doc_cnt == 0:
            self.__inc_catalog_doc_idx()
            return self.next()
        else:
            doc = self.__fetch_catalog_doc()
            return doc


class DocGrabber(object):
    """ document downloader. """
    def __init__(self, dst_dir, debug, username=None, password=None):
        assert os.path.isdir(dst_dir)
        assert isinstance(debug, bool)
        self.dst_dir = dst_dir
        self.logger = new_logger("DocGrabber")
        if not debug:
            self.logger.setLevel(logging.INFO)
        self.username = username
        self.password = password

    def __http_to_https_url(self, url):
        # http://focus.ti.com/lit/wp/spry079/spry079.pdf
        # https://focus.ti.com/seclit/wp/spry079/spry079.pdf
        if url.startswith("http://"):
            https_url = url.replace("http", "https", 1)
            https_url = https_url.replace("lit", "seclit", 1)
            return https_url
        elif url.startswith("https://"):
            return url
        else:
            return url

    def __login_ti_site(self):
        cookie = cookielib.CookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie))
        url = "https://ti-pass.ext.ti.com/cgi-bin/login/plogin.pl"
        data_template = Template("fld2=${uname}&fld5=${passwd}&Submit.x=43&" \
        "Submit.y=5&fld3=1&ErrPage=&OKPage=https%3A%2F%2Fti-pass.ext.ti.com" \
        "%2Fcgi-bin%2Flogin%2Fsuccess.pl%3Flt%3Dgenr&actionId=0&fld1=0&" \
        "fld4=all&fld6=&guid=0&j3=2&j5=1&lt=genr&portal=0&sam=1&ss=0&x=0&" \
        "xcon_legal_warn=0")
        if self.username is None or self.password is None:
            raise SDDError("no username or no password for login is provided")
        data = data_template.safe_substitute(uname=quote(self.username),
                passwd=quote(self.password))
        headers = {"Cookie": "iatc=1"}
        request = urllib2.Request(url, data, headers)
        try:
            response = opener.open(request)
        except urllib2.HTTPError, err:
            self.logger.error("http error %s during login through %s" %
                    (err.code, url))
            raise SDDError("")
        except urllib2.URLError, err:
            self.logger.error("url error %s during login through %s" %
                    (err.reason, url))
            raise SDDError("")
        except Exception, err:
            self.logger.error("unexpected error %s during login through %s" %
                    (err, url))
            raise SDDError("")
        else:
            ok_url = "https://ti-pass.ext.ti.com/cgi-bin/login/success.pl?lt=genr"
            ret_url = response.geturl()
            if ret_url == ok_url:
                self.https_opener = opener
            else:
                self.logger.error("login through %s fail" % url)
                raise SDDError("")

    def __download_secure_doc(self, url, file):
        if not hasattr(self, "https_opener"):
            self.__login_ti_site()
        https_url = self.__http_to_https_url(url)
        try:
            response = self.https_opener.open(https_url)
        except urllib2.HTTPError, err:
            self.logger.error("http error %s for %s" % (err.code, https_url))
            raise SDDError("")
        except urllib2.URLError, err:
            self.logger.error("url error %s for %s" % (err.reason, https_url))
            raise SDDError("")
        except Exception, err:
            self.logger.error("unexpected error %s during open %s" %
                    (err, https_url))
            raise SDDError("")
        else:
            try:
                with open(file, "wb") as fd:
                    fd.write(response.read())
            except IOError, err:
                self.logger.error("write file %s fail, %s" % (file, err))
                raise SDDError("")
            except Exception, err:
                self.logger.error("unexpected error %s during write file %s" %
                        (err, file))
                raise SDDError("")

    def __download_doc(self, url, file):
        request = urllib2.Request(url)
        try:
            response = urllib2.urlopen(request)
        except urllib2.HTTPError, err:
            if err.code == 404:
                self.__download_secure_doc(url, file)
            else:
                self.logger.error("http error %s for %s" % (err.code, url))
                raise SDDError("")
        except urllib2.URLError, err:
            self.logger.error("url error %s for %s" % (err.reason, url))
            raise SDDError("")
        except Exception, err:
            self.logger.error("unexpected error-%s" % err)
            raise SDDError("")
        else:
            try:
                with open(file, "wb") as fd:
                    fd.write(response.read())
            except IOError, err:
                self.logger.error("write file %s fail, %s" % (file, err))
                raise SDDError("")
            except Exception, err:
                self.logger.error("unexpected error-%s" % err)
                raise SDDError("")

    def grab(self, doc):
        self.logger.debug("download %s, %s, %s, %s, %s, %s" %
                (doc["catalog"], doc["type"], doc["id"],
                    doc["date"], doc["title"], doc["url"]))
        dst_file = "".join((self.dst_dir, "/", doc["catalog"], "/",
            doc["title"], ".", doc["type"]))
        self.__download_doc(doc["url"], dst_file)


class DocDownloadHistory(object):
    """download history recorder."""
    def __init__(self, dst_dir, debug):
        assert os.path.isdir(dst_dir)
        assert isinstance(debug, bool)
        self.logger = new_logger("DocDlHistory")
        if not debug:
            self.logger.setLevel(logging.INFO)
        self.__create_history_recorder(dst_dir)

    def __create_history_recorder(self, dst_dir):
        db_name = "".join((dst_dir, "/", "history"))
        self.dbc = sqlite3.connect(db_name)
        cursor = self.dbc.cursor()
        cursor.execute("create table if not exists download "
                "(catalog text, type text, id text, date text, title text, "
                "primary key(catalog, type, id))")
        cursor.close()
        self.dbc.commit()

    def download_entry_exists(self, doc):
        rval = False
        cursor = self.dbc.cursor()
        cursor.execute("select COUNT(*) from download where "
                "catalog = ? AND type = ? AND id = ?",
                (doc["catalog"], doc["type"], doc["id"]))
        if cursor.fetchone()[0] > 0:
            rval = True
        cursor.close()
        return rval

    def add_download_entry(self, doc):
        cursor = self.dbc.cursor()
        cursor.execute("insert into download values(?, ?, ?, ?, ?)",
                (doc["catalog"], doc["type"], doc["id"],
                doc["date"], doc["title"]))
        cursor.close()
        self.dbc.commit()


def option_check_callback(option, opt_str, value, parser):
    if opt_str in ["-m", "--model"]:
        if value not in g_valid_models:
            raise OptionValueError("invalid model %s, "
                    "model must belongs to %s" % (value, g_valid_models))
        setattr(parser.values, option.dest, value)
    elif opt_str in ["-d", "--dst"]:
        dir = os.path.abspath(value)
        if not os.path.lexists(dir):
            try:
                os.makedirs(dir)
            except OSError, err:
                raise OptionValueError("invalid dst %s, create directory "
                        "fail, %s" % (dir, err))
            except Exception, err:
                raise OptionValueError("invalid dst %s, create directory "
                        "fail, unexpected error-%s" % (dir, err))
            else:
                setattr(parser.values, option.dest, dir)
        else:
            if os.path.isdir(dir):
                setattr(parser.values, option.dest, dir)
            else:
                raise OptionValueError("invalid dst %s, file exists, but"
                        "isn't a directory" % dir)


def parse_options(input):
    parser = OptionParser()
    parser.add_option("-m", "--model", action="callback",
            callback=option_check_callback, type="string", dest="model",
            help="soc model, must be 6446, 6467 or 8168")
    parser.add_option("-d", "--dst", action="callback",
            callback=option_check_callback, type="string", dest="dst",
            help="destination directory for documents saving")
    parser.add_option("-u", "--username", type="string", dest="username",
            help="username used to login into www.ti.com")
    parser.add_option("-p", "--password", type="string", dest="password",
            help="password used to login into www.ti.com")
    parser.add_option("-v", "--debug", action="store_true", dest="debug",
            default=False, help="debug enable flag")
    (options, args) = parser.parse_args()
    result = options
    if options.model is None:
        sys.stderr.write("miss -m/--model option\n")
        result = None
    if options.dst is None:
        sys.stderr.write("miss -d/--dst option\n")
        result = None

    if result is None:
        parser.print_help()
    return result


def create_dir_or_die(logger, dir):
    if not os.path.lexists(dir):
        try:
            os.mkdir(dir)
        except OSError, err:
            logger.error("create directory %s fail, %s" % (dir, err))
            sys.exit(1)
        except Exception, err:
            logger.error("unexpected error %s" % str(err))
            sys.exit(1)
    else:
        if not os.path.isdir(dir):
            logger.error("file %s exists, but isn't a directory" % dir)
            sys.exit(1)


if __name__ == "__main__":
    options = parse_options(sys.argv)
    if options == None:
        sys.exit(1)

    logger = new_logger("main")
    if not options.debug:
        logger.setLevel(logging.INFO)

    model_dir = "".join((options.dst, "/", options.model))
    create_dir_or_die(logger, model_dir)

    for catalog in DavinciDocSrc.get_catalogs():
        catalog_dir = "".join((model_dir, "/", catalog))
        create_dir_or_die(logger, catalog_dir)

    supported_doc_types = ["pdf", "zip", "ibs"]
    doc_grabber = DocGrabber(model_dir, options.debug,
            options.username, options.password)
    dl_history = DocDownloadHistory(model_dir, options.debug)
    doc_src = DavinciDocSrc(options.model, options.debug)
    for doc in doc_src:
        if doc["type"] not in supported_doc_types:
            logger.debug("ignore document %s.%s in %s" %
                    (doc["title"], doc["type"], doc["catalog"]))
            continue
        if not dl_history.download_entry_exists(doc):
            logger.info("download new document %s.%s in %s" %
                    (doc["title"], doc["type"], doc["catalog"]))
            try:
                doc_grabber.grab(doc)
            except Exception, err:
                pass
            else:
                dl_history.add_download_entry(doc)
    sys.exit(0)
