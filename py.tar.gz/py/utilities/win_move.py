#!/usr/bin/env python
# -*- coding: utf8 -*-

import os
import stat
import sys
import subprocess

def bin_file_exist(f):
    if os.path.isfile(f) and \
    (stat.S_IMODE(os.stat(f).st_mode) & stat.S_IXUSR):
        return True
    else:
        return False

def bin_files_exist(flist):
    result = True
    exist = False
    for f in flist:
        for p in [path for path in os.environ["PATH"].split(":") if path]:
            if bin_file_exist(os.path.join(p, f)):
                exist = True
                break

        if not exist:
            sys.stderr.write("execute file %s doesn't exist\n" % f)
            result = False
            break

    return result

def get_screen_width():
    cmd = ["wmctrl", "-d"]
    if dbg:
        sys.stdout.write("run cmd '%s'\n" % " ".join(cmd))
    output = subprocess.Popen(cmd,
           stdout = subprocess.PIPE).communicate()[0]
    # 0  * DG: 2880x900  VP: 0,0  WA: 0,25 2880x850  Workspace 1
    f_line = output.splitlines()[0]
    if dbg:
        sys.stdout.write("first line is '%s'\n" % f_line)
    w_h = f_line.split(None, 4)[3]
    if dbg:
        sys.stdout.write("width and height is %s\n" % w_h)
    return int(w_h.split("x")[0])

def get_active_wnd_id():
    cmd = ["xdotool", "getactivewindow"]
    if dbg:
        sys.stdout.write("run cmd '%s'\n" % " ".join(cmd))
    output = subprocess.Popen(cmd,
           stdout = subprocess.PIPE).communicate()[0]
    return "0x{0:08x}".format(int(output.strip()))

def get_wnd_geometry(wid):
    wid_exist = False
    geometry = None
    cmd = ["wmctrl", "-l", "-G"]
    if dbg:
        sys.stdout.write("run cmd '%s'\n" % " ".join(cmd))
    output = subprocess.Popen(cmd,
           stdout = subprocess.PIPE).communicate()[0]
    for line in output.splitlines():
        # 0x04001ce0  0 1440 48   1440 875  box htbegin@box: Script
        if line.startswith(wid):
            if dbg:
                sys.stdout.write("match line '%s'\n" % line)
            wid_exist = True
            try:
                geometry = line.split(None, 6)[2:6]
            except Exception:
                geometry = None
            finally:
                break

    if geometry is None:
        if wid_exist:
            sys.stderr.write("invalid wmctrl output\n")
        else:
            sys.stderr.write("invalid window id %s" % wid)
        sys.exit(1)

    return [int(val) for val in geometry]

def set_wnd_geometry(wid, geometry):
    mv_arg = "0,{0},{1},{2},{3}".format(*geometry)
    cmd = ["wmctrl", "-i", "-r", wid, "-e", mv_arg]
    if dbg:
        sys.stdout.write("run cmd '%s'\n" % " ".join(cmd))
    ret = subprocess.call(cmd)
    if ret != 0:
        sys.stderr.write("invalid retcode %d for cmd '%s'\n" % (ret, " ".join(cmd)))
        sys.exit(1)

if __name__ == "__main__":
    dbg = False
    if len(sys.argv) == 2 and sys.argv[1] == "-v":
        dbg = True
    if not bin_files_exist(["wmctrl", "xdotool"]):
        sys.exit(1)
    screen_width = get_screen_width()
    wnd_id = get_active_wnd_id()
    if dbg:
        sys.stdout.write("active window id is %s\n" % wnd_id)
    x, y, w, h = get_wnd_geometry(wnd_id)
    if dbg:
        sys.stdout.write("before move: %s,%s@%s,%s\n" % (x, y, w, h))
    if x >= screen_width / 2:
        x -= screen_width / 2
    else:
        x += screen_width / 2
    if dbg:
        sys.stdout.write("after move: %s,%s@%s,%s\n" % (x, y, w, h))
    set_wnd_geometry(wnd_id, (x, y, w, h))
    sys.exit(0)
