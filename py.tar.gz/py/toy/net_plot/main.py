#! /usr/bin/env python
# -*- coding: ascii -*-

import pygtk
import gtk

from plot_box import PlotBox

def create_main_ui():
	WND_WIDTH=600
	WND_HEIGHT=400
	WND_BORDER_WIDTH=10

	wnd=gtk.Window(gtk.WINDOW_TOPLEVEL)
	wnd.connect("destroy",lambda wid: gtk.main_quit())
	wnd.connect("delete_event",lambda f_arg,s_arg: gtk.main_quit())
	wnd.set_title("network load plot")
	wnd.set_default_size(WND_WIDTH,WND_HEIGHT)
	wnd.set_border_width(WND_BORDER_WIDTH)

	box=PlotBox()
	wnd.add(box)
	box.show()

	wnd.show()

if __name__=="__main__":
	create_main_ui()
	gtk.main()

