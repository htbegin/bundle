#! /usr/bin/env python
# -*- coding: ascii -*-

import pygtk
import gtk
import gobject
from collections import deque

from graph_plot_area import GraphPlotArea
from data_source import create_data_source

class PlotData:
	MAX_POINT_CNT=62
	def __init__(self,color):
		self._point_cnt=1
		self._points=deque([0])
		self._color=color
	def __iter__(self):
		return iter(self._points)
	@property
	def color(self):
		return self._color
	def add_point(self,point):
		self._points.appendleft(point)
		if self._point_cnt < self.MAX_POINT_CNT:
			self._point_cnt += 1
		else:
			self._points.pop()
	def get_max_point(self):
		return max(self._points)
	def get_newest_point(self):
		return self._points[1]

class InfoBox(gtk.HBox):
	COLOR_AREA_WIDTH=20
	COLOR_AREA_HEIGHT=20
	def __init__(self,color="gray",host="",speed=""):
		gtk.HBox.__init__(self,homogeneous=False,spacing=0)

		self.color_area=gtk.DrawingArea()
		self.color_area.set_size_request(self.COLOR_AREA_WIDTH,
				self.COLOR_AREA_HEIGHT)
		gdk_color=gtk.gdk.color_parse(color)
		self.color_area.modify_bg(gtk.STATE_NORMAL,gdk_color)
		self.pack_start(self.color_area,expand=False,fill=False,padding=0)
		self.color_area.show()

		self.host_label=gtk.Label(host)
		self.pack_start(self.host_label,expand=True,fill=True,padding=0)
		self.host_label.show()

		self.speed_label=gtk.Label(speed)
		self.pack_start(self.speed_label,expand=True,fill=True,padding=0)
		self.speed_label.show()
	def update_info(self,color=None,host=None,speed=None):
		if color != None:
			gdk_color=gtk.gdk.color_parse(color)
			self.color_area.modify_bg(gtk.STATE_NORMAL,gdk_color)
		if host != None:
			self.host_label.set_text(host)
		if speed != None:
			self.speed_label.set_text(speed)

class PlotBox(gtk.VBox):
	GRAPH_TEXT_SPACING=10

	TABLE_ROW=2
	TABLE_COLUMN=2
	TABLE_ROW_SPACING=5
	TABLE_COL_SPACING=5

	GRAPH_WIDTH=600
	GRAPH_HEIGHT=100

	UPDATE_INTERNAL_MS=2000
	DATA_UPDATE_CYCLE=5

	color_table={"red":True,"orange":True,"green":True,"purple":True}

	DEFAULT_MAX_PLOT_POINT=5
	def __init__(self):
		gtk.VBox.__init__(self,False,self.GRAPH_TEXT_SPACING)
		self.init_data()
		self.init_ui()
		self.init_timer()
	def init_data(self):
		self.data_src=create_data_source("TP-LINK")
		self.plot_data_pool={}
		self.max_plot_point=None
		self.data_update_counter=self.DATA_UPDATE_CYCLE-1
	def init_ui(self):
		self.table=gtk.Table(self.TABLE_ROW,self.TABLE_COLUMN)
		self.table.set_row_spacings(self.TABLE_ROW_SPACING)
		self.table.set_col_spacings(self.TABLE_COL_SPACING)
		for row in range(0,self.TABLE_ROW):
			for column in range(0,self.TABLE_COLUMN):
				info_box=InfoBox()
				self.table.attach(info_box,column,column+1,row,row+1)
				info_box.show()
		self.pack_start(self.table,expand=False,fill=True,padding=0)
		self.table.show()

		self.drawing_area=GraphPlotArea()
		self.drawing_area.connect("expose_event",
				self.drawing_area.graph_plot_area_expose,
				self)
		self.drawing_area.set_size_request(self.GRAPH_WIDTH,self.GRAPH_HEIGHT)
		self.pack_start(self.drawing_area,expand=True,fill=True,padding=0)
		self.drawing_area.show()
	def init_timer(self):
		self.update_plot()
		self.update_timer=gobject.timeout_add(self.UPDATE_INTERNAL_MS,
				self.update_plot)
	def get_graph_offset_ratio(self):
		return float(self.data_update_counter)/self.DATA_UPDATE_CYCLE
	def get_max_plot_point_cnt(self):
		return PlotData.MAX_POINT_CNT
	def get_plot_data_pool(self):
		return self.plot_data_pool.itervalues()
	def get_max_plot_point(self):
		return self.max_plot_point
	def get_plot_color(self):
		"""color for plot.
		None will be returned if no color is available
		"""
		avail_color=None
		for color,avail in self.color_table.iteritems():
			if avail:
				avail_color=color
				self.color_table[color]=False
				break

		return avail_color
	def update_data(self):
		for entry in self.data_src.generate_netspeed_data_entries():
			ip_addr,kbyte_rate=entry[0],entry[1]
			if ip_addr not in self.plot_data_pool.keys():
				color=self.get_plot_color()
				if color == None:
					printf("graph for {0} won't be plotted".format(ip_addr))
				self.plot_data_pool[ip_addr]=PlotData(color)

			self.plot_data_pool[ip_addr].add_point(kbyte_rate)

		self.max_plot_point=self.DEFAULT_MAX_PLOT_POINT
		for plot_data in self.plot_data_pool.itervalues():
			value=plot_data.get_max_point()
			if self.max_plot_point < value: self.max_plot_point=value

	def update_info_table(self):
		info_list=[]
		host_list=self.plot_data_pool.keys()
		host_list.sort()
		for host in host_list:
			plot_data=self.plot_data_pool[host]
			if plot_data.color == None: continue
			color=plot_data.color
			speed="{0} KB/s".format(plot_data.get_newest_point())
			info_list.append((color,host,speed))

		max_info_index=len(info_list)-1
		cell_list=self.table.get_children()
		cell_list.reverse()
		for index,cell in enumerate(cell_list):
			if max_info_index < index: break
			info=info_list[index]
			cell.update_info(*info)
	def update_graph(self):
		self.drawing_area.queue_draw()
	def update_plot(self):
		if self.data_update_counter == self.DATA_UPDATE_CYCLE-1:
			self.update_data()
			self.update_info_table()
			self.update_graph()
			self.data_update_counter=0
		else:
			self.update_graph()
			self.data_update_counter+=1

		return True

if __name__ == "__main__":
	WND_WIDTH=600
	WND_HEIGHT=400
	WND_BORDER_WIDTH=10

	wnd=gtk.Window(gtk.WINDOW_TOPLEVEL)
	wnd.connect("destroy",lambda wid: gtk.main_quit())
	wnd.connect("delete_event",lambda f_arg,s_arg: gtk.main_quit())
	wnd.set_title("plot_box demo")
	wnd.set_default_size(WND_WIDTH,WND_HEIGHT)
	wnd.set_border_width(WND_BORDER_WIDTH)

	box=PlotBox()
	wnd.add(box)

	wnd.show_all()
	gtk.main()

