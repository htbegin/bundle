#! /usr/bin/env python
# -*- coding: ascii -*-

import random
import urllib2
import re
import logging

def create_data_source(name):
	if name == "Dummy":
		source=DummyNetSpeedDataSource()
	elif name == "Random":
		source=RandomNetSpeedDataSource()
	elif name == "TP-LINK":
		source=TplinkNetSpeedDataSource()
	else:
		raise NotImplementedError("data source {0} doesn't exist".format(name))

	return source

class NetSpeedDataSource(object):
	"""an interface for network speed data source.
	"""
	def __init__(self,name=None):
		self.name=name

	def generate_netspeed_data_entries(self):
		"""generate the network speed for each IP.

		the entry for each IP must be represented as a tulple like this:
		(ip="192.168.1.178",kbyte_rate="40")
		the return value is sequence of the statistic data
		"""
		raise NotImplementedError("it should be implemented in subclass")

class DummyNetSpeedDataSource(NetSpeedDataSource):
	def __init__(self,name="Dummy"):
		NetSpeedDataSource.__init__(self,name)

	def generate_netspeed_data_entries(self):
		return ()

class RandomNetSpeedDataSource(NetSpeedDataSource):
	def __init__(self,name="Random"):
		NetSpeedDataSource.__init__(self,name)

	def generate_netspeed_data_entries(self):
		all_ip_addr=("192.168.9.101","192.168.9.102","192.168.9.103")
		kbyte_rate_range=(4,401)
		entries=((ip_addr,random.randint(*kbyte_rate_range))
				for ip_addr in all_ip_addr)
		return entries

class TplinkNetSpeedDataSource(NetSpeedDataSource):
	def __init__(self,name="TP-Link"):
		NetSpeedDataSource.__init__(self,name)

		self.ip_addr="192.168.1.1"
		self.top_level_url="http://"+self.ip_addr
		self.url="http://"+self.ip_addr+"/userRpm/SystemStatisticRpm.htm"
		self.model="TP-LINK Wireless Router WR340G"

		realm=self.model
		username="admin"
		password="admin"
		password_mgr=urllib2.HTTPPasswordMgr()
		password_mgr.add_password(realm,self.top_level_url,username,password)

		auth_handler=urllib2.HTTPBasicAuthHandler(password_mgr)
		self.opener=urllib2.build_opener(auth_handler)
		self.opener.addheaders=[("Accept","*/*"),("Accept-Encoding","gzip,deflate")]

	def parse_page_content(self,content,entries):
		IP_ADDR_INDEX=1
		BYTE_RATE_INDEX=6
		KBYTE_IN_BYTE=1000
		START_STR="var statList = new Array(\n"
		END_STR="0,0 );\n"

		store_flag=False
		for line in content:
			if store_flag:
				if line == END_STR: break
				info=line.split(", ")
				ip_addr=info[IP_ADDR_INDEX].strip('"')
				kbyte_rate=int(info[BYTE_RATE_INDEX])/KBYTE_IN_BYTE
				entries.append((ip_addr,kbyte_rate))
			if line == START_STR:
				store_flag=True

	def get_page_content(self):
		content=None
		try:
			file=self.opener.open(self.url)
		except URLError,e:
			if hasattr(e,"reason"):
				logging.error("connect {0} fail, error: {1}".format(
							self.ip_addr,e.reason))
			elif hasattr(e,"code"):
				logging.error("bad request to {0}, status code: {1}".format(
							self.ip_addr,e.code))
		else:
			content=file
		finally:
			return content

	def generate_netspeed_data_entries(self):
		entries=[]
		content=self.get_page_content()
		if content != None:
			self.parse_page_content(content,entries)

		return entries

if __name__=="__main__":
	all_name=["Dummy","Random","TP-LINK"]
	for name in all_name:
		print "create data source",name
		data_src=create_data_source(name)
		for entry in data_src.generate_netspeed_data_entries():
			print entry

