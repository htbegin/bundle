#! /usr/bin/env python
# -*- coding: ascii -*-

import cairo
import pygtk
import gtk

class GraphPlotArea(gtk.DrawingArea):
	TMARGIN=20
	BMARGIN=20
	VSPACING=TMARGIN+BMARGIN
	LSPACING=10
	LLABEL_WIDTH=60
	LMARGIN=LSPACING+LLABEL_WIDTH
	RMARGIN=20
	HSPACING=LMARGIN+RMARGIN

	MAX_HORIZONTAL_GAP=50
	VERTICAL_DIVISION=6
	def __init__(self):
		gtk.DrawingArea.__init__(self)
		self.modify_bg(gtk.STATE_NORMAL,gtk.gdk.color_parse("white"))

	def adjust_vertical_max_value(self,raw_max,division):
		max=raw_max
		max+=division-1-(max+division-1)%division
		max+=max/division
		max+=division-1-(max+division-1)%division
		return max

	def get_horizontal_division(self):
		height=self.allocation.height-self.VSPACING
		gap_num=height/self.MAX_HORIZONTAL_GAP

		if 0 <= gap_num and gap_num <= 1:
			division=1
		elif 1 < gap_num and gap_num <= 2:
			division=2
		elif 2 < gap_num and gap_num <= 5:
			division=5
		elif 5 < gap_num and gap_num <= 10:
			division=10
		else:
			division=15

		return division

	def get_vertical_division(self):
		return self.VERTICAL_DIVISION

	def draw_horizontal_bar(self,ctx,data_src):
		division=self.get_horizontal_division()
		raw_max_value=data_src.get_max_plot_point()
		# ensure that value is divisible by division
		value=self.adjust_vertical_max_value(raw_max_value,division)
		value_delta=value/division

		orig_x=self.allocation.x+self.LMARGIN
		orig_y=self.allocation.y+self.TMARGIN
		width=self.allocation.width-self.HSPACING
		height=self.allocation.height-self.VSPACING

		hbar_len=width
		hbar_gap=float(height)/division

		x,y=orig_x,orig_y
		cur_value=value
		for index in range(0,division+1):
			ctx.move_to(x,y)
			ctx.rel_line_to(hbar_len,0)

			cur_value_label="{0:d} KB/s".format(cur_value)
			ctx.move_to(x-self.LLABEL_WIDTH,y)
			ctx.show_text(cur_value_label)

			y+=hbar_gap
			cur_value-=value_delta

		ctx.stroke()

	def draw_vertical_bar(self,ctx,data_src):
		division=self.get_vertical_division()

		orig_x=self.allocation.x+self.LMARGIN
		orig_y=self.allocation.y+self.TMARGIN
		width=self.allocation.width-self.HSPACING
		height=self.allocation.height-self.VSPACING

		vbar_len=height
		vbar_gap=float(width)/division

		x,y=orig_x,orig_y
		for index in range(0,division+1):
			ctx.move_to(x,y)
			ctx.rel_line_to(0,vbar_len)
			x+=vbar_gap

		ctx.stroke()

	def draw_background(self,ctx,data_src):
		line_width=0.5
		dash_pattern=[2.0,1.0]

		ctx.save()

		ctx.set_source_rgb(0,0,0)
		ctx.set_line_width(line_width)
		ctx.set_dash(dash_pattern,0)
		# self.allocation.x/y is window coordinate
		# but cairo use them as origin: (0,0)
		ctx.translate(-self.allocation.x,-self.allocation.y)

		self.draw_horizontal_bar(ctx,data_src)
		self.draw_vertical_bar(ctx,data_src)

		ctx.restore()

	def plot(self,ctx,data_src,plot_data):
		ctx.set_source_color(gtk.gdk.Color(plot_data.color))

		orig_x=self.allocation.x+self.LMARGIN
		orig_y=self.allocation.y+self.TMARGIN
		width=self.allocation.width-self.HSPACING
		height=self.allocation.height-self.VSPACING

		division=self.get_horizontal_division()
		v_raw_max_value=data_src.get_max_plot_point()
		v_max_value=self.adjust_vertical_max_value(v_raw_max_value,division)
		v_len=height
		# h_value belongs [-1,point_cnt-2]
		h_max_value=data_src.get_max_plot_point_cnt()-2
		h_len=width

		x_offset_unit=float(h_len)/h_max_value
		x_offset_ratio=data_src.get_graph_offset_ratio()
		x_offset=x_offset_unit*x_offset_ratio
		for h_value,v_value in enumerate(plot_data):
			h_value-=1
			h_ratio=1.0-float(h_value)/h_max_value
			v_ratio=1.0-float(v_value)/v_max_value
			x=orig_x+h_ratio*h_len-x_offset
			y=orig_y+v_ratio*v_len

			if h_value == -1:
				prev_x,prev_y=x,y
				ctx.move_to(x,y)
				continue

			fc_x,fc_y=(prev_x+x)/2,prev_y
			sc_x,sc_y=(prev_x+x)/2,y
			prev_x,prev_y=x,y

			ctx.curve_to(fc_x,fc_y,sc_x,sc_y,x,y)

		ctx.stroke()

	def setup_clip_region(self,ctx):
		orig_x=self.allocation.x+self.LMARGIN
		orig_y=self.allocation.y+self.TMARGIN
		width=self.allocation.width-self.HSPACING
		height=self.allocation.height-self.VSPACING

		ctx.rectangle(orig_x,orig_y,width,height)
		ctx.clip()

	def draw_graph(self,ctx,data_src):
		line_width=2.0

		ctx.save()

		ctx.set_line_width(line_width)
		ctx.translate(-self.allocation.x,-self.allocation.y)

		self.setup_clip_region(ctx)

		for plot_data in data_src.get_plot_data_pool():
			if plot_data.color != None: self.plot(ctx,data_src,plot_data)

		ctx.restore()

	def graph_plot_area_expose(self,widget,event,data_src):
		ctx=self.window.cairo_create()
		self.draw_background(ctx,data_src)
		self.draw_graph(ctx,data_src)
		return False

