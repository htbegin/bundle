#ifndef __LOAD_PLOT_H__
#define __LOAD_PLOT_H__

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define TYPE_LOAD_PLOT (load_plot_get_type ())
#define LOAD_PLOT(obj) \
	(G_TYPE_CHECK_INSTANCE_CAST((obj),TYPE_LOAD_PLOT,LoadPlot))
#define LOAD_PLOT_CLASS(obj) \
	(G_TYPE_CHECK_CLASS_CAST((obj),LOAD_PLOT,LoadPlotClass))
#define IS_LOAD_PLOT(obj) \
	(G_TYPE_CHECK_INSTANCE_TYPE((obj),TYPE_LOAD_PLOT))
#define IS_LOAD_PLOT_CLASS(obj) \
	(G_TYPE_CHECK_CLASS_TYPE((obj),TYPE_LOAD_PLOT))
#define LOAD_PLOT_GET_CLASS	\
	(G_TYPE_INSTANCE_GET_CLASS((obj),TYPE_LOAD_PLOT,LoadPlotClass))

typedef struct _LoadPlot		LoadPlot;
typedef struct _LoadPlotClass	LoadPlotClass;

struct _LoadPlot
{
	GtkDrawingArea parent;

	/* < private > */
};

struct _LoadPlotClass
{
	GtkDrawingAreaClass parent_class;
};

GtkWidget * load_plot_new();

G_END_DECLS

#endif /* __LOAD_PLOT_H__ */

