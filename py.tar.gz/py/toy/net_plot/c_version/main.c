#include <gtk/gtk.h>

#include "plot.h"

#define WND_HEIGHT 300
#define WND_WIDTH 900

#define PLOT_MIN_HEIGH 100
#define PLOT_MIN_WIDTH 600

int main(int argc,char ** argv)
{
	GtkWidget * window;
	GtkWidget * plot;

	gtk_init(&argc,&argv);

	window=gtk_window_new(GTK_WINDOW_TOPLEVEL);

	plot=load_plot_new();

	gtk_container_add(GTK_CONTAINER(window),plot);

	GdkGeometry hints;

	hints.min_width=PLOT_MIN_WIDTH;
	hints.min_height=PLOT_MIN_HEIGH;
	gtk_window_set_geometry_hints(GTK_WINDOW(window),GTK_WIDGET(plot),\
			&hints,GDK_HINT_MIN_SIZE);

	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
	gtk_window_set_default_size(GTK_WINDOW(window),WND_WIDTH,WND_HEIGHT);

	gtk_widget_show_all(window);

	gtk_main();

	return 0;
}

