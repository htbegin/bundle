#include <gtk/gtk.h>
#include <math.h>
#include <glib.h>

#include "plot.h"

#define LOAD_PLOT_GET_PRIVATE(obj) \
	(G_TYPE_INSTANCE_GET_PRIVATE((obj), TYPE_LOAD_PLOT, LoadPlotPrivate))

#define LOAD_POINT_CNT 13

G_DEFINE_TYPE (LoadPlot, load_plot, GTK_TYPE_DRAWING_AREA);

typedef struct _LoadPlotPrivate LoadPlotPrivate;
typedef struct _LoadDataSrc LoadDataSrc;

#define DATA_SRC_BEGIN 1
#define DATA_SRC_END ((1<<22)+1)
#define DEFAULT_MAX_VALUE 10

struct _LoadDataSrc
{
	int begin_value;
	int end_value;

	GList * point_list;
	int max_point_cnt;
	int point_cnt;
	GList * cur_point;
};

#define MAX_HBAR_GAP 60

struct _LoadPlotPrivate
{
	LoadDataSrc data_src;
};

static void data_src_init(LoadDataSrc * src)
{
	src->begin_value=DATA_SRC_BEGIN;
	src->end_value=DATA_SRC_END;
	src->point_list=NULL;
	src->max_point_cnt=LOAD_POINT_CNT;
	src->point_cnt=0;
	src->cur_point=NULL;
}

static int adjust_max(const int max,const int unit)
{
	g_assert(unit>0);

	int new_max;

	new_max=max+unit-1-(max+unit-1)%unit;
	new_max+=max/unit;
	new_max=new_max+unit-1-(new_max+unit-1)%unit;

	return new_max;
}

static void data_src_get_max(LoadDataSrc * src,int * value)
{
	g_assert(src!=NULL);
	g_assert(value!=NULL);

	int max=DEFAULT_MAX_VALUE;

	GList * const head=src->point_list;
	GList * cur_point=head;
	int cur_value;

	while(cur_point!=NULL)
	{
		cur_value=GPOINTER_TO_INT(cur_point->data);
		if(max<cur_value)
		{
			max=cur_value;
		}
		cur_point=g_list_next(cur_point);
	}

	*value=max;
}

static void data_src_update(LoadDataSrc * src)
{
	g_assert(src->point_cnt<=src->max_point_cnt);

	int rand=g_random_int_range(src->begin_value,src->end_value);

	if(src->point_cnt<src->max_point_cnt)
	{
		src->point_list=g_list_prepend(src->point_list,GINT_TO_POINTER(rand));
		++src->point_cnt;
	}
	else
	{
		GList * last;

		last=g_list_last(src->point_list);
		g_assert(last!=NULL);
		src->point_list=g_list_delete_link(src->point_list,last);

		src->point_list=g_list_prepend(src->point_list,GINT_TO_POINTER(rand));
	}
}

static int data_src_set_start_pos(LoadDataSrc * src,const int pos)
{
	int rval=-1;

	if(0<=pos && pos<src->point_cnt)
	{
		src->cur_point=g_list_nth(src->point_list,pos);
		g_assert(src->cur_point!=NULL);
		rval=0;
	}

	return rval;
}

static void data_src_get_value(LoadDataSrc * src,int * value)
{
	g_assert(src->cur_point!=NULL);

	*value=GPOINTER_TO_INT(src->cur_point->data);
}

static int data_src_goto_next(LoadDataSrc * src)
{
	g_assert(src->cur_point!=NULL);

	int rval=0;
	GList * last=g_list_last(src->point_list);

	if(src->cur_point!=last)
	{
		src->cur_point=g_list_next(src->cur_point);
		g_assert(src->cur_point!=NULL);
		rval=1;
	}

	return rval;
}

static gboolean load_plot_expose (GtkWidget * plot, GdkEventExpose *event);
static gboolean load_plot_update(gpointer data);

static void load_plot_class_init (LoadPlotClass *class)
{
	GtkWidgetClass *widget_class;

	widget_class = GTK_WIDGET_CLASS (class);

	widget_class->expose_event = load_plot_expose;

	g_type_class_add_private(class,sizeof(LoadPlotPrivate));
}

static void load_plot_init (LoadPlot *plot)
{
	LoadPlotPrivate * priv=LOAD_PLOT_GET_PRIVATE(plot);

	data_src_init(&(priv->data_src));

	load_plot_update(plot);

	g_timeout_add(1000,load_plot_update,plot);
}

static gboolean load_plot_update(gpointer data)
{
	LoadPlot * plot=LOAD_PLOT(data);
	LoadPlotPrivate * priv=LOAD_PLOT_GET_PRIVATE(plot);
	GtkWidget * widget=NULL;
	GdkWindow * window=NULL;
	GdkRegion * region=NULL;

	data_src_update(&(priv->data_src));

	widget=GTK_WIDGET(plot);
	window=widget->window;

	if(window==NULL) return TRUE;

	region=gdk_drawable_get_clip_region(window);
	gdk_window_invalidate_region(window,region,TRUE);
	gdk_window_process_updates(window,TRUE);
	gdk_region_destroy(region);

	return TRUE;
}

#define LMARGIN 10
#define RMARGIN 10
#define HMARGIN (LMARGIN+RMARGIN)

#define TMARGIN 10
#define BMARGIN 10
#define VMARGIN (TMARGIN+BMARGIN)

#define HLABEL_WIDTH 80
#define VLABEL_HEIGHT 10

/*
static void draw (GtkWidget *plot, cairo_t *cr)
{
	double x, y;
	double radius;

	x = plot->allocation.x + plot->allocation.width / 2;
	y = plot->allocation.y + plot->allocation.height / 2;
	radius = MIN(plot->allocation.width / 2,plot->allocation.height / 2)-HMARGIN;

	cairo_arc (cr, x, y, radius, 0, 2 * M_PI);
	cairo_set_source_rgb (cr, 1, 1, 1);
	cairo_fill_preserve (cr);
	cairo_set_source_rgb (cr, 0, 0, 0);
	cairo_stroke (cr);
}
*/

static int calc_hbar_num(int height)
{
	g_assert(MAX_HBAR_GAP!=0);

	int gap_num=height/MAX_HBAR_GAP;
	int bar_num;

	if(0<=gap_num && gap_num<=1)
	{
		bar_num=2;
	}
	else if(2<=gap_num && gap_num<=5)
	{
		bar_num=6;
	}
	else if(6<=gap_num && gap_num<=10)
	{
		bar_num=11;
	}
	else
	{
		bar_num=21;
	}

	return bar_num;
}

const char * units[]={"KB","MB","GB"};
static void convert_to_readable_string(char * str,int str_size,double value)
{
	const int max_unit_index=sizeof(units)/sizeof(units[0])-1;
	double old_input;
	double input=value;
	int unit_index=0;

	while(TRUE)
	{
		old_input=input;
		input=input/1024;

		if(input>=1 && unit_index<max_unit_index)
		{
			++unit_index;
		}
		else
		{
			break;
		}
	}

	snprintf(str,str_size,"%.1f %s",old_input,units[unit_index]);
}

#define H_LABEL_LEN 31
static void draw_horizontal_bar(GtkWidget * plot,cairo_t * cr)
{
	LoadPlotPrivate * priv=LOAD_PLOT_GET_PRIVATE(plot);
	LoadDataSrc * data_src=&priv->data_src;

	int background_height;
	int hbar_num;
	int raw_max_value;
	int max_value;

	background_height=plot->allocation.height-VMARGIN-VLABEL_HEIGHT;
	hbar_num=calc_hbar_num(background_height);
	data_src_get_max(data_src,&raw_max_value);
	max_value=adjust_max(raw_max_value,hbar_num-1);

	double x;
	double y;
	double hbar_orig_x;
	double hbar_orig_y;
	double hbar_len;
	double hbar_gap;
	int i;

	char label[H_LABEL_LEN+1];
	double value_gap;
	double value;

	hbar_orig_x=plot->allocation.x+LMARGIN+HLABEL_WIDTH;
	hbar_orig_y=plot->allocation.y+TMARGIN;
	hbar_gap=(plot->allocation.height-VMARGIN-VLABEL_HEIGHT)/(hbar_num-1);
	hbar_len=plot->allocation.width-HMARGIN-HLABEL_WIDTH;
	value_gap=max_value/(hbar_num-1);
	for(i=0;i<hbar_num;++i)
	{
		x=hbar_orig_x;
		y=hbar_orig_y+i*hbar_gap;

		cairo_move_to(cr,x,y);
		cairo_line_to(cr,x+hbar_len,y);

		x-=HLABEL_WIDTH;
		value=(hbar_num-1-i)*value_gap;

		convert_to_readable_string(label,sizeof(label),value);

		cairo_move_to(cr,x,y);
		cairo_show_text(cr,label);
	}
	cairo_stroke(cr);
}

#define V_LABEL_LEN 31
static void draw_vertical_bar(GtkWidget * plot,cairo_t * cr)
{
	double x;
	double y;
	double vbar_orig_x;
	double vbar_orig_y;
	double vbar_len;
	double vbar_gap;
	int i;
	const int vbar_num=7;

	const char unit[]="";
	const double max_value=12;
	char label[V_LABEL_LEN+1];
	double value_gap;
	double value;

	vbar_orig_x=plot->allocation.x+LMARGIN+HLABEL_WIDTH;
	vbar_orig_y=plot->allocation.y+TMARGIN;
	vbar_gap=(plot->allocation.width-HMARGIN-HLABEL_WIDTH)/(vbar_num-1);
	vbar_len=plot->allocation.height-VMARGIN-VLABEL_HEIGHT;
	value_gap=max_value/(vbar_num-1);
	for(i=0;i<vbar_num;++i)
	{
		x=vbar_orig_x+i*vbar_gap;
		y=vbar_orig_y;

		cairo_move_to(cr,x,y);
		cairo_line_to(cr,x,y+vbar_len);

		y+=vbar_len+VLABEL_HEIGHT;
		value=(vbar_num-1-i)*value_gap;
		snprintf(label,sizeof(label),"%.0f %s",value,unit);
		cairo_move_to(cr,x,y);
		cairo_show_text(cr,label);
	}
	cairo_stroke(cr);
}

static void draw_background(GtkWidget *plot,GdkEventExpose *event)
{
	cairo_t * cr=NULL;

	cr=gdk_cairo_create(plot->window);

	cairo_set_source_rgb(cr,0,0,0);
	cairo_set_line_width(cr,1.0);

	double dash_pattern[]={2.0,1.0};
	int dash_pattern_len=sizeof(dash_pattern)/sizeof(dash_pattern[0]);

	cairo_set_dash(cr,dash_pattern,dash_pattern_len,0);

	draw_horizontal_bar(plot,cr);

	draw_vertical_bar(plot,cr);

	cairo_destroy(cr);
}

static void draw_load_graph(GtkWidget *plot,GdkEventExpose *event)
{
	LoadPlotPrivate * priv=LOAD_PLOT_GET_PRIVATE(plot);
	LoadDataSrc * src=&priv->data_src;
	cairo_t *cr;

	cr=gdk_cairo_create(plot->window);
	cairo_set_source_rgb(cr,1,0,0);

	int background_height;
	int hbar_num;
	int raw_v_max_value;

	background_height=plot->allocation.height-VMARGIN-VLABEL_HEIGHT;
	hbar_num=calc_hbar_num(background_height);

	data_src_get_max(src,&raw_v_max_value);
	raw_v_max_value=adjust_max(raw_v_max_value,hbar_num-1);

	double orig_x;
	double orig_y;
	double v_len;
	const double v_max_value=raw_v_max_value;
	double h_len;
	const double h_max_value=LOAD_POINT_CNT-1;

	orig_x=plot->allocation.x+LMARGIN+HLABEL_WIDTH;
	orig_y=plot->allocation.y+TMARGIN;
	h_len=plot->allocation.width-HMARGIN-HLABEL_WIDTH;
	v_len=plot->allocation.height-VMARGIN-VLABEL_HEIGHT;

	const int start_data_pos=0;
	int data_pos;
	double x;
	double y;
	int h_value;
	int v_value;

	if(data_src_set_start_pos(src,start_data_pos)<0)
	{
		g_print("no element at position %d\n",start_data_pos);
		return;
	}
	data_pos=start_data_pos;

	h_value=data_pos;
	data_src_get_value(src,&v_value);
	++data_pos;

	x=orig_x+(1.0-h_value/h_max_value)*h_len;
	y=orig_y+(1.0-v_value/v_max_value)*v_len;
	cairo_move_to(cr,x,y);
	while(data_src_goto_next(src)>0)
	{
		double prev_x;
		double prev_y;
		double fc_x;
		double fc_y;
		double sc_x;
		double sc_y;

		prev_x=x;
		prev_y=y;

		h_value=data_pos;
		data_src_get_value(src,&v_value);
		++data_pos;
		x=orig_x+(1.0-h_value/h_max_value)*h_len;
		y=orig_y+(1.0-v_value/v_max_value)*v_len;

		fc_x=(prev_x+x)/2;
		fc_y=prev_y;

		sc_x=fc_x;
		sc_y=y;

		cairo_curve_to(cr,fc_x,fc_y,sc_x,sc_y,x,y);
	}
	cairo_stroke(cr);
	cairo_destroy (cr);
}

static gboolean load_plot_expose (GtkWidget * plot, GdkEventExpose *event)
{
	draw_background(plot,event);

	draw_load_graph(plot,event);

	return FALSE;
}

GtkWidget * load_plot_new (void)
{
	return g_object_new (TYPE_LOAD_PLOT,NULL);
}

