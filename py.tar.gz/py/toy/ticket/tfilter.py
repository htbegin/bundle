#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import logging

from common_routine import new_logger


_tfilter_logger = new_logger("tfilter")

_filter_buy_ptn = re.compile(ur"求购|急求",
        re.MULTILINE | re.IGNORECASE)
_filter_dst_ptn = re.compile(ur"武昌|武汉|汉口",
        re.MULTILINE | re.IGNORECASE)
_filter_num_ptn = re.compile(r"z4[67]|k112[67]|k529|k532|k35[14]|k12[23]|k1[14]",
        re.MULTILINE | re.IGNORECASE)

def _filter_is_buy(ticket, logger):
    rval = False
    keys = ["title", "desc"]
    for key in keys:
        if _filter_buy_ptn.search(ticket[key]) is not None:
            logger.debug("%s-'%s' match re '%s'" %
                    (key, ticket[key], _filter_buy_ptn.pattern))
            rval = True
            break
    return rval

def _filter_is_valid_dst(ticket, logger):
    rval = False
    keys = ["title", "desc"]
    for key in keys:
        if _filter_dst_ptn.search(ticket[key]) is not None:
            logger.debug("%s-'%s' match re '%s'" %
                    (key, ticket[key], _filter_dst_ptn.pattern))
            rval = True
            break
    return rval

def _filter_is_valid_number(ticket, logger):
    rval = False
    keys = ["title", "desc"]
    for key in keys:
        if _filter_num_ptn.search(ticket[key]) is not None:
            logger.debug("%s-'%s' match re '%s'" %
                    (key, ticket[key], _filter_num_ptn.pattern))
            rval = True
            break
    return rval


class TicketFilter(object):
    def __init__(self):
        pass

    def disable_debug(self):
        self.logger.setLevel(logging.INFO)

    def __eval_result(self, vals):
        return eval(self.expr.format(*vals))

    def run(self, ticket):
        vals = []
        for tfilter in self.chain:
            val = tfilter(ticket, self.logger)
            vals.append(val)
        return self.__eval_result(vals)


class HZ19LouTicketFilter(TicketFilter):
    logger = new_logger("HZ19LouTicketFilter")
    def __init__(self):
        self.chain = [_filter_is_buy, _filter_is_valid_dst,
                _filter_is_valid_number]
        self.expr = "(not {0}) and ({1} or {2})"


class HuoChePiaoDotComTicketFilter(TicketFilter):
    logger = new_logger("HuoChePiaoDotComTicketFilter")
    def __init__(self):
        self.chain = [_filter_is_buy]
        self.expr = "not {0}"


def ticket_filter_factory(name):
    filter_class_dict = {
            "hz19lou" : HZ19LouTicketFilter,
            "huochepiao" : HuoChePiaoDotComTicketFilter,
            }
    if name in filter_class_dict:
        return filter_class_dict[name]()
    else:
        _tfilter_logger.info("unknown ticket filter %s" % name)
        return None

if __name__ == "__main__":
    filter = ticket_filter_factory("hz19lou")
    assert filter is not None
    ticket = {"title" : u"求购", "desc" : u"武汉"}
    assert not filter.run(ticket)
    ticket = {"title" : u"汉口", "desc" : u"Z47"}
    assert filter.run(ticket)

    filter = ticket_filter_factory("huochepiao")
    assert filter is not None
    ticket = {"title" : u"转让", "desc" : "南昌"}
    assert filter.run(ticket)
    ticket = {"title" : u"求购", "desc" : "武昌"}
    assert not filter.run(ticket)

    assert ticket_filter_factory("unknown") is None

