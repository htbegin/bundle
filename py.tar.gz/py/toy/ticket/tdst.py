#!/usr/bin/env python
# -*- coding: ascii -*-

import sys

import xmpp

from common_routine import new_logger


_tdst_logger = new_logger("tdst")

class ConsoleNotifyDst(object):
    def __init__(self):
        pass

    def connect(self):
        pass

    def notify(self, subscribers, msg):
        if isinstance(msg, unicode):
            sys.stdout.write("%s" % msg.encode("utf8"))

    def disconnect(self):
        pass


class GtalkNotifyDst(object):
    logger = new_logger("GtalkNotifyDst")
    def __init__(self):
        self.user = None
        self.passwd = None
        self.client = None
        self.server = "talk.google.com"
        self.auth_repo = "gtalk"

    def __parse_auth_info(self):
        try:
            with open(self.auth_repo, "rb") as fd:
                for line in fd:
                    key, value = line.strip().split(None, 1)
                    if key == "user":
                        self.user = value
                    elif key == "passwd":
                        self.passwd = value
        except Exception, err:
            self.logger.error("parse authentication info fail, error-%s"
                    % str(err))
        else:
            if self.user is None or self.passwd is None:
                self.logger.error("incomplete authentication info under %s" %
                        self.auth_repo)
                self.user = None
                self.passwd = None

    def connect(self):
        self.__parse_auth_info()
        if self.user is not None and self.passwd is not None:
            self.client = xmpp.Client("gmail.com", debug = [])
            self.client.connect(server=(self.server, 5223))
            self.client.auth(self.user, self.passwd, "tticket")
            if self.client.isConnected() is None:
                self.logger("connect %s fail with %s:%s fail" %
                        (self.server, self.user, self.passwd))

    def notify(self, subscribers, msg):
        if self.client is not None and isinstance(msg, unicode):
            msg = msg.encode("utf8")
            for dst in subscribers:
                self.client.send(xmpp.Message(dst, msg))

    def disconnect(self):
        pass


def notify_dst_factory(name):
    table = { "console" : ConsoleNotifyDst, "gtalk" : GtalkNotifyDst}
    if name in table:
        return table[name]()
    else:
        _tdst_logger.error("unknown notify dst %s" % name)
        return None

