#!/usr/bin/env python
# -*- coding: ascii -*-

import calendar
import datetime
import time
import inspect
import errno
import re

import feedparser

from common_routine import new_logger

_tsrc_logger = new_logger("tsrc")

def _structtime_to_datetime(utc_time):
    secs = calendar.timegm(utc_time)
    local_time = time.localtime(secs)

    dtime = datetime.datetime(local_time[0], local_time[1], local_time[2],
            local_time[3], local_time[4], local_time[5])
    return dtime


def _fetch_rss_tickets(rss_url):
    tickets = []
    try:
        info_dict = feedparser.parse(rss_url)
    except Exception, err:
        _tsrc_logger.error("parse %s fail, error-%s" % (rss_url, str(err)))
    else:
        for entry in info_dict["entries"]:
            ticket = {}
            ticket["time"] = _structtime_to_datetime(entry["updated_parsed"])
            ticket["title"] = entry["title"]
            ticket["author"] = entry["author"]
            ticket["desc"] = entry["summary"]
            ticket["link"] = entry["link"]
            tickets.append(ticket)
    return tickets


class TicketSrc(object):
    def __init__(self, tfilter = None):
        self.tfilter = tfilter
        self.ticket_repo = set([])

    def parse_ticket(self, ticket):
        return ticket

    def __parse_tickets(self, tickets):
        parsed_tickets = []
        for t in tickets:
            parsed_tickets.append(self.parse_ticket(t))
        return parsed_tickets

    def __is_duplicated_ticket(self, ticket):
        if ticket["link"] in self.ticket_repo:
            return True
        else:
            return False

    def __update_ticket_repo(self, ticket):
        self.ticket_repo.add(ticket["link"])

    def __run_filter(self, ticket):
        return self.tfilter.run(ticket)

    def __filter_tickets(self, tickets):
        matched = []
        for t in tickets:
            if self.__is_duplicated_ticket(t):
                continue
            else:
                self.__update_ticket_repo(t)

            if self.tfilter is None or self.__run_filter(t):
                matched.append(t)
        return matched

    def query(self):
        newest_tickets = _fetch_rss_tickets(self.url)
        parsed_tickets = self.__parse_tickets(newest_tickets)
        matched_tickets = self.__filter_tickets(parsed_tickets)
        if matched_tickets:
            self.logger.debug("new matched tickets arrived at %s" %
                    time.strftime("%H:%M:%S", time.localtime()))
        return matched_tickets

    def save_ticket_info(self):
        if not hasattr(self, "file_repo"):
            return

        try:
            with open(self.file_repo, "wb") as fd:
                for info in self.ticket_repo:
                    self.logger.debug("save '%s'" % info)
                    fd.write("%s\n" % info)
                    fd.flush()
        except IOError, err:
            self.logger.error("%s fail" % inspect.stack()[0][3])
            self.logger.error("%s: %s" % (err.__class__.__name__, err))
        except Exception, err:
            self.logger("%s fail" % inspect.stack()[0][3])
            self.logger.error("Unexpected Error: %s" % str(err))

    def restore_ticket_info(self):
        if not hasattr(self, "file_repo"):
            return

        try:
            with open(self.file_repo, "rb") as fd:
                for line in fd:
                    info = line.strip()
                    if info:
                        self.logger.debug("restore '%s'" % info)
                        self.ticket_repo.add(info)
        except IOError, err:
            if err.errno == errno.ENOENT:
                self.logger.info("no saved ticket info")
            else:
                self.logger.error("%s fail" % inspect.stack()[0][3])
                self.logger.error("%s: %s" % (err.__class__.__name__, err))
        except Exception, err:
            self.logger("%s fail" % inspect.stack()[0][3])
            self.logger.error("Unexpected Error: %s" % str(err))


class HZ19LouTicketSrc(TicketSrc):
    logger = new_logger("HZ19LouTicketSrc")
    def __init__(self, tfilter = None):
        super(HZ19LouTicketSrc, self).__init__(tfilter)
        self.url = "http://www.19lou.com/index.php?r=rss&fid=1946"
        self.file_repo = "hz19lou"


def _replace_html_tag(match):
    if match.groups(0)[0] == u"/":
        return " "
    else:
        return ""

class HuoChePiaoDotComTicketSrc(TicketSrc):
    logger = new_logger("HuoChePiaoDotComTicketSrc")
    def __init__(self, tfilter = None):
        super(HuoChePiaoDotComTicketSrc, self).__init__(tfilter)
        self.url = "http://www.huochepiao.com/rss/search.asp?" \
        "chufa=%BA%BC%D6%DD&daoda=%CE%E4%B2%FD"
        self.html_tag_ptn = re.compile(r"<(/?)[^>]+>", re.MULTILINE)
        self.file_repo = "huochepiao"

    def parse_ticket(self, ticket):
        ticket["desc"] = self.html_tag_ptn.sub(_replace_html_tag,
                ticket["desc"])
        return ticket


class HuoCheDotComHTMLTicketSrc(TicketSrc):
    pass


def ticket_src_factory(name, tfilter):
    src_map = {
           "hz19lou": HZ19LouTicketSrc,
           "huochepiao" : HuoChePiaoDotComTicketSrc,
           }
    if name in src_map:
        return src_map[name](tfilter)
    else:
        _tsrc_logger.error("unknown ticket source %s" % name)
        return None

