#!/usr/bin/env python
# -*- coding: ascii -*-

import sys
import time

from common_routine import new_logger
from tsrc import ticket_src_factory
from tfilter import ticket_filter_factory
from tdst import notify_dst_factory

def create_ticket_src():
    src_names = ["hz19lou", "huochepiao"]
    srcs = []
    for name in src_names:
        src = ticket_src_factory(name, ticket_filter_factory(name))
        if src:
            src.restore_ticket_info()
            srcs.append(src)
    return srcs

def destroy_ticket_src(srcs):
    for src in srcs:
        src.save_ticket_info()

def create_notify_dst():
    dst_names = ["console", "gtalk"]
    dsts = []
    for name in dst_names:
        dst = notify_dst_factory(name)
        if dst:
            dst.connect()
            dsts.append(dst)
    return dsts

def destroy_notify_dst(dsts):
    for dst in dsts:
        dst.disconnect()

def notify(dsts, tickets):
    subscribers = ("hotforest@gmail.com",)
    for t in tickets:
        msg = u"time: {0}\ntitle: {1}\nlink: {2}\ndesc: {3}\n\n".format(
                str(t["time"]),t["title"],t["link"],t["desc"])
        for dst in dsts:
            dst.notify(subscribers, msg)

def main_loop():
    exit_status = 0
    logger = new_logger("main")
    ticket_srcs = create_ticket_src()
    notify_dsts = create_notify_dst()
    try:
        while True:
            for src in ticket_srcs:
                tickets = src.query()
                if tickets:
                    notify(notify_dsts, tickets)
            time.sleep(10)
    except KeyboardInterrupt:
        logger.info("keyboard interrput")
        exit_status = 0
    except Exception, err:
        logger.error("unexpected error: %s" % str(err))
        exit_status = 1
    finally:
        destroy_notify_dst(notify_dsts)
        destroy_ticket_src(ticket_srcs)
        sys.exit(exit_status)

if __name__ == "__main__":
    main_loop()
