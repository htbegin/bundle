#! /usr/bin/env python
# -*- coding: ascii -*-

# description:
#	generate emotion statistics graphs
# author:
#	hotforest <hotforest@gmail.com>
# history:
#	V0.1 2010.04.02
# version:
#	V0.1 alpha editon

import sys
from optparse import OptionParser
import os
import shutil
import subprocess
import time
from datetime import timedelta
from datetime import date

from logging_wrapper import new_logger
from input_date_src import generate_input_data

def convert_to_date(date_str):
	assert isinstance(date_str,str)

	fmt="%Y_%m_%d"
	date_obj=None
	try:
		raw_time=time.strptime(date_str,fmt)
	except:
		pass
	else:
		date_obj=date(raw_time.tm_year,raw_time.tm_mon,raw_time.tm_mday)

	return date_obj

def is_options_valid(options):
	if options.start is None:
		logger.error("start_date doesn't be set")
		return False

	if options.end is None:
		logger.error("end_date doesn't be set")
		return False

	start_date=convert_to_date(options.start)
	end_date=convert_to_date(options.end)

	if start_date is None:
		logger.error("start_date has invalid format")
		return False

	if end_date is None:
		logger.error("end_date has invalid format")
		return False

	if end_date <= start_date:
		logger.error("end_date must be greater than start_date")
		return False

	return True

def convert_date_range(start_date,end_date):
	MONDAY=1
	relocated_start_date=start_date
	one_day=timedelta(days=1)
	while relocated_start_date.isoweekday() != MONDAY:
		relocated_start_date=relocated_start_date-one_day

	days=(end_date-relocated_start_date).days
	# four weeks or 28 days alignment
	date_set_alignment=28
	date_set_cnt=(days+date_set_alignment-1)/date_set_alignment

	return (relocated_start_date,date_set_cnt)

def generate_output(input,output):
	shutil.copy(input,"four_week")

	subprocess.check_call(["gnuplot","emotion.plot"])

	os.remove("four_week")

	subprocess.check_call(["ps2pdf","emotion.ps"])
	os.remove("emotion.ps")

	os.rename("emotion.pdf",output)

def merge_pdf_files(input_files,output):
	args=["pdfjoin"]
	args.extend(input_files)
	subprocess.check_call(args)

	temp_output=input_files[len(input_files)-1].replace(".","-joined.")
	os.rename(temp_output,output)

def main(sdate_str,edate_str):
	# convert the date instance
	start_date=convert_to_date(sdate_str)
	end_date=convert_to_date(edate_str)

	assert isinstance(start_date,date)
	assert isinstance(end_date,date)
	assert end_date > start_date

	logger.debug("start date is {0}, end date is {1}".format(start_date,
				end_date))

	# generate the input data
	(new_start_date,date_set_cnt)=convert_date_range(start_date,end_date)
	logger.debug("new start date is {0}, date set cnt is {1}".format(
				new_start_date,date_set_cnt))

	generate_input_data(new_start_date,date_set_cnt)
	logger.debug("generate {0} date set".format(date_set_cnt))

	# generate output for each input data set
	input_list=[]
	output_list=[]
	for id in range(1,date_set_cnt+1):
		input_fname="{0:d}_input".format(id)
		output_fname="{0:d}_output.pdf".format(id)
		generate_output(input_fname,output_fname)
		input_list.append(input_fname)
		output_list.append(output_fname)

	logger.debug("generate emotion graphs succeed")

	# merge all output togerther
	final_output_fname="emotion.pdf"
	merge_pdf_files(output_list,final_output_fname)

	logger.debug("merge all pdfs to one pdf {0}".format(final_output_fname))

	# remove all input and output file
	for input_fname in input_list:
		os.remove(input_fname)

	for output_fname in output_list:
		os.remove(output_fname)

	logger.debug("remove all input data and output pdfs")

logger=new_logger("main")

usage="%prog <-s|--start> start_date <-e|--end> end_date"
parser=OptionParser(usage=usage)
parser.add_option("-s","--start",dest="start",
		help="start date, format is YYYY_mm_dd like 2010_04_01")
parser.add_option("-e","--end",dest="end",
		help="end date, format is YYYY_mm_dd like 2010_04_02 and "
		"must be greater than start date")

(options,args)=parser.parse_args()
if args:
	logger.error("much more options are provided")
	parser.print_help()
	sys.exit(1)

if not is_options_valid(options):
	parser.print_help()
	sys.exit(1)

main(options.start,options.end)

