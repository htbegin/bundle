#! /usr/bin/env python
# -*- coding: ascii -*-

# description:
#	provide some handy functions related with logging module
# author:
#	hotforest <hotforest@gmail.com>
# history:
#	V0.1 2010.04.02
# version:
#	V0.1 alpha editon

import logging

def new_logger(name):
	logger=logging.getLogger(name)
	logger.setLevel(logging.DEBUG)
	logger.propagate=False
	# create console handler and set level to debug
	handler=logging.StreamHandler()
	# create formatter
	formatter=logging.Formatter("%(levelname)s:%(name)s:%(message)s.")
	# add formatter to handler
	handler.setFormatter(formatter)
	# add handler to logger
	logger.addHandler(handler)

	return logger

