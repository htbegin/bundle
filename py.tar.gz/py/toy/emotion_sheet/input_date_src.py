#! /usr/bin/env python
# -*- coding: ascii -*-

# description:
#	generate the input data for emotion graphs
# author:
#	hotforest <hotforest@gmail.com>
# history:
#	V0.1 2010.04.02
# version:
#	V0.1 alpha editon

import logging
from datetime import date
from datetime import timedelta
import time

from logging_wrapper import new_logger

MONDAY=1

def get_following_week(start_date):
	assert isinstance(start_date,date)
	assert start_date.isoweekday() == MONDAY

	one_day=timedelta(days=1)

	day_in_week=7
	day_str_list=[]
	cur_date=start_date
	for index in range(day_in_week):
		day_str=cur_date.strftime("%Y_%m_%d")
		day_str_list.append(day_str)
		cur_date=cur_date+one_day

	return day_str_list

def get_following_four_week(start_date):
	assert isinstance(start_date,date)
	assert start_date.isoweekday() == MONDAY

	one_week=timedelta(weeks=1)

	week_cnt=4
	four_week=[]
	cur_date=start_date
	for index in range(week_cnt):
		week=get_following_week(cur_date)
		four_week.append(week)
		cur_date=cur_date+one_week

	return four_week

def write_week(fd,week):
	value_str="61.8"
	for day in week:
		str="{0}  {1}\n".format(day,value_str)
		fd.write(str)

def write_four_week(fd,four_week):
	fd.write("# time  value\n")
	write_week(fd,four_week[0])
	write_week(fd,four_week[1])

	fd.write("\n\n")

	fd.write("# time  value\n")
	write_week(fd,four_week[2])
	write_week(fd,four_week[3])

	fd.write("\n")

def generate_input_data(start_date,four_week_cnt):
	assert isinstance(start_date,date)
	assert start_date.isoweekday() == MONDAY

	logger=new_logger("input")
	logger.debug("start date is {0}".format(start_date))

	# move to next date until enough weeks are got
	four_week=timedelta(weeks=4)
	cur_date=start_date
	weeks_list=[]
	for index in range(four_week_cnt):
		weeks=get_following_four_week(cur_date)
		weeks_list.append(weeks)
		cur_date=cur_date+four_week

	# flush week list to data file
	for index,weeks in enumerate(weeks_list):
		fname="{0:d}_input".format(index+1)
		fd=open(fname,"w")
		write_four_week(fd,weeks)
		fd.close()
		logger.debug("write {0} succeed".format(fname))

if __name__ == "__main__":
	get_following_week(date(2010,04,05))
	get_following_four_week(date(2010,04,05))
	generate_input_data(date(2010,04,05),1)

