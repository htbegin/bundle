=======================================
Embedding Python in Another Application
=======================================

---------
Use Cases
---------
Embedding provides your application with the ability to implement some of the functionality
of your application in Python rather than C or C++.

* allow users to tailor the application to their needs by writing some scripts in Python
* the functionality can be written in Python more easily

----------------
Embed and Extend
----------------
When you extend Python, the main program of the application is still the Python interpreter,
while if you embed Python, the main program may have nothing to do with Python — instead,
some parts of the application occasionally call the Python interpreter to run some Python code.

-----------------------------------
Initialize and Call the Interpreter
-----------------------------------
One of the things this main program has to do is initialize the Python interpreter.
At the very least, you have to call the function Py_Initialize().

There are several different ways to call the interpreter:
you can pass a string containing Python statements to PyRun_SimpleString(),
or you can pass a stdio file pointer and a file name (for identification in error messages only)
to PyRun_SimpleFile().
You can also call the lower-level operations described in the previous chapters
to construct and use Python objects.

--------------------
High Level Embedding
--------------------
The simplest form of embedding Python is the use of the very high level interface.
This interface is intended to execute a Python script without needing to interact with
the application directly.

-------------------
Low Level Embedding
-------------------
It should be noted that extending Python and embedding Python is quite the same activity,
despite the different intent.

Extending Process
=================
* Convert data values from Python to C,
* Perform a function call to a C routine using the converted values, and
* Convert the data values from the call from C to Python.

Embedding Process
=================
* Convert data values from C to Python,
* Perform a function call to a Python interface routine using the converted values, and
* Convert the data values from the call from Python to C.

Pure Embedding
==============

Steps
-----
* load module using PyImport_Import
* load function using PyObject_GetAttrString
* call function using PyObject_CallObject

Extending Embedded Python
=========================
The Python API allows the embedded Python interpreter to have access to functionality
from the application by extending the embedded interpreter. That is, the embedded interpreter
gets extended with routines provided by the application.

Linking Requirements
====================
This is an issue when the application is linked to the static runtime library (libpython.a)
and needs to load dynamic extensions (implemented as .so files).

The problem is that some entry points are defined by the Python runtime solely for
extension modules to use. If the embedding application does not use any of these entry points,
some linkers will not include those entries in the symbol table of the finished executable.
Some additional options are needed to inform the linker not to remove these symbols.

::

    >>> import distutils.sysconfig
    >>> distutils.sysconfig.get_config_var('LINKFORSHARED')
    '-Xlinker -export-dynamic -Wl,-O1 -Wl,-Bsymbolic-functions'
