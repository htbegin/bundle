======
ctypes
======

ctypes is a foreign function library for Python.
It provides C compatible data types, and allows calling functions in DLLs or shared libraries.
It can be used to wrap these libraries in pure Python.

---------------
ctypes tutorial
---------------

loading dynamic link libraries
==============================

windows convention
------------------
::

    from ctypes import *
    print windll.kernel32
    libc = cdll.msvcrt

linux convention
----------------
::

    from ctypes import *
    libc = cdll.LoadLibrary("libc.so.6")
    libc = CDLL("libc.so.6")

accessing functions from loaded dlls
====================================
The function is an attribute of the dlls. If not found, the AttributeError will be raised.

::

    func = libc.printf
    func = libc.god
    func = getattr(libc, "read")

fundamental data types
======================

data types
----------

c_bool

c_void_p

c_char/c_wchar/c_char_p/c_wchar_p

c_byte/c_ubyte/c_short/c_ushort/c_int/c_uint/c_long/c_ulong/c_longlong/c_ulonglong [#]_

c_float/c_double/c_longdouble

::

    i = c_int(0)
    i.value = 2
    s = c_char_p("Hello")
    s.value = "World"

    p = create_string_buffer(4)
    print sizeof(p), repr(p.raw)
    p.value = "god"
    print sizeof(p), repr(p.raw)

    p = create_string_buffer("Hello")
    print sizeof(p), repr(p.raw)

    p = create_string_buffer("Hello", 10)
    print sizeof(p), repr(p.raw)

calling functions
=================
You can call these functions like any other Python callable.

ctypes tries to protect you from calling functions with the wrong number of arguments or
the wrong calling convention. Unfortunately this only works on Windows.

::

    # None is used as NULL pointer
    print libc.time(None)

native Python objects
---------------------
None, integers, longs, byte strings and unicode strings are the only native Python objects
that can directly be used as parameters in these function calls.

None is passed as a C NULL pointer.

Byte strings and unicode strings are passed as pointer to the memory block that
contains their data (char \* or wchar_t \*).

Python integers and Python longs are passed as the platforms default C int type,
their value is masked to fit into the C type.

::

    printf = libc.printf
    printf("Hello, %s\n", "World!")
    printf("%d bottles of beer\n", 42)
    # raise ArgumentError exception
    printf("%f bottles of beer\n", 42.5)
    printf("An int %d, a double %f\n", 1234, c_double(3.14))

calling functions with your own custom data types
-------------------------------------------------

You can also customize ctypes argument conversion to allow instances of your own classes
be used as function arguments.
ctypes looks for an _as_parameter_ attribute and uses this as the function argument.
Of course, it must be one of integer, string, or unicode::

    >>> class Bottles(object):
    ...     def __init__(self, number):
    ...         self._as_parameter_ = number
    ...
    >>> bottles = Bottles(42)
    >>> printf("%d bottles of beer\n", bottles)

specifying the required argument types (function prototypes)
============================================================
It is possible to specify the required argument types of functions exported from DLLs
by setting the argtypes attribute.

argtypes must be a sequence of C data types (fundamental or customized).

Specifying a format protects against incompatible argument types (just as a prototype for a C function),
and tries to convert the arguments to valid types.

::

    >>> printf.argtypes = [c_char_p, c_char_p, c_int, c_double]
    >>> printf("String '%s', Int %d, Double %f\n", "Hi", 10, 2.2)
    # raise ArgumentError exception
    >>> printf("%d %d %d", 1, 2, 3)
    # 3 will be converted to a double type
    >>> printf("%s %d %f\n", "X", 2, 3)

If you want to use your own defined-class to be used in argtypes sequence, you have to
implement a from_param() class method.
The from_param() class method receives the Python object passed to the function call,
it should do a typecheck or whatever is needed to make sure this object is acceptable,
and then return the object itself, its _as_parameter_ attribute,
or whatever you want to pass as the C function argument in this case.
Again, the result should be an integer, string, unicode, a ctypes instance,
or an object with an _as_parameter_ attribute.

Return types
============
By default functions are assumed to return the C int type.
Other return types can be specified by setting the restype attribute of the function object.

::

    >>> strchr = libc.strchr
    >>> strchr("abcdef", ord("d")) # doctest: +SKIP
    8059983
    >>> strchr.restype = c_char_p # c_char_p is a pointer to a string
    >>> strchr("abcdef", ord("d"))
    'def'
    >>> print strchr("abcdef", ord("x"))
    None

    >>> strchr.restype = c_char_p
    >>> strchr.argtypes = [c_char_p, c_char]
    >>> strchr("abcdef", "d")
    'def'

error check
-----------
You can also use a callable Python object (a function or a class for example) as the restype attribute,
if the foreign function returns an integer. The callable will be called with the integer
the C function returns, and the result of this call will be used as the result of your function call.
This is useful to check for error return values and automatically raise an exception.

A much more powerful error checking mechanism is available through the errcheck attribute.

Passing pointers (or: passing parameters by reference)
======================================================
ctypes exports the byref() function which is used to pass parameters by reference.
The same effect can be achieved with the pointer() function, although pointer() does
a lot more work since it constructs a real pointer object, so it is faster to use byref()
if you don’t need the pointer object in Python itself::

    >>> i = c_int()
    >>> f = c_float()
    >>> s = create_string_buffer('\000' * 32)
    >>> print i.value, f.value, repr(s.value)
    0 0.0 ''
    >>> libc.sscanf("1 3.14 Hello", "%d %f %s",
    ...             byref(i), byref(f), s)
    3
    >>> print i.value, f.value, repr(s.value)
    1 3.1400001049 'Hello'

structures and unions
=====================
Structures and unions must derive from the Structure and Union base classes
which are defined in the ctypes module.
Each subclass must define a _fields_ attribute. _fields_ must be a list of 2-tuples,
containing a field name and a field type.

The field type must be a ctypes type like c_int, or any other derived ctypes type:
structure, union, array, pointer.

::

    >>> from ctypes import *
    >>> class POINT(Structure):
    ...     _fields_ = [("x", c_int),
    ...                 ("y", c_int)]
    ...
    >>> point = POINT(10, 20)
    >>> print point.x, point.y
    10 20
    >>> point = POINT(y=5)
    >>> print point.x, point.y
    0 5

    >>> class RECT(Structure):
    ...     _fields_ = [("upperleft", POINT),
    ...                 ("lowerright", POINT)]
    ...
    >>> rc = RECT(point)
    >>> print rc.upperleft.x, rc.upperleft.y
    0 5
    >>> print rc.lowerright.x, rc.lowerright.y
    0 0
    >>> r = RECT(POINT(1, 2), POINT(3, 4))
    >>> r = RECT((1, 2), (3, 4))

bit fields
----------
It is possible to create structures and unions containing bit fields.
Bit fields are only possible for integer fields,
the bit width is specified as the third item in the _fields_ tuples::

    >>> class Int(Structure):
    ...     _fields_ = [("first_16", c_int, 16),
    ...                 ("second_16", c_int, 16)]
    ...
    >>> print Int.first_16
    <Field type=c_long, ofs=0:0, bits=16>
    >>> print Int.second_16
    <Field type=c_long, ofs=0:16, bits=16>

structure/union alignment and byte order
========================================

By default, Structure and Union fields are aligned in the same way the C compiler [#]_ does it.
It is possible to override this behavior be specifying a _pack_ class attribute
in the subclass definition. This must be set to a positive integer and
specifies the maximum alignment for the fields.

ctypes uses the native byte order [#]_ for Structures and Unions.
To build structures with non-native byte order, you can use one of the BigEndianStructure,
LittleEndianStructure, BigEndianUnion, and LittleEndianUnion base classes.
These classes cannot contain pointer fields.

arrays
======
Arrays are sequences, containing a fixed number of instances of the same type.

The recommended way to create array types is by multiplying a data type with a positive integer::

    >>> TenPointsArrayType = POINT * 10
    >>> arr = TenPointsArrayType()
    >>> for pt in arr: print pt.x, pt.y

    >>> class POINT(Structure):
    ...    _fields_ = ("x", c_int), ("y", c_int)
    ...
    >>> class MyStruct(Structure):
    ...    _fields_ = [("a", c_int),
    ...                ("b", c_float),
    ...                ("point_array", POINT * 4)]
    >>>
    >>> print len(MyStruct().point_array)
    4
    >>> S = MyStruct(1, 1.0, ((1, 2), (3, 4), (5, 6), (7, 8)))
    >>> print S.point_array[0].x, S.point_array[0].y
    1 2

pointer
=======
Pointer instances are created by calling the pointer() function on a ctypes type.
Pointer instances have a contents attribute which returns the object to which the pointer points.

Note that ctypes does not have OOR (original object return),
it constructs a new, equivalent object each time you retrieve an attribute.

::

>>> i = c_int(42)
>>> pi = pointer(i)

>>> pi.contents
c_long(42)
>>> pi.contents is i
False
>>> pi.contents is pi.contents
False

>>> i = c_int(99)
>>> pi.contents = i
>>> pi.contents
c_long(99)

>>> pi[0]
99
>>> print i
c_long(99)
>>> pi[0] = 22
>>> print i
c_long(22)

pointer type
------------
This is done with the POINTER() function, which accepts any ctypes type, and returns a new type.
Calling the pointer type without an argument creates a NULL pointer.
NULL pointers have a False boolean value.
ctypes checks for NULL when dereferencing pointers.

::

    >>> PI = POINTER(c_int)
    >>> PI
    <class 'ctypes.LP_c_long'>
    >>> PI(42)
    Traceback (most recent call last):
      File "<stdin>", line 1, in ?
    TypeError: expected c_long instead of int
    >>> PI(c_int(42))
    <ctypes.LP_c_long object at 0x...>
    >>>

    >>> null_ptr = POINTER(c_int)()
    >>> print bool(null_ptr)
    False

    # raise ValueError exception
    >>> null_ptr[0]
    # raise ValueError exception
    >>> null_ptr[0] = 1234

type conversions
================
Usually, ctypes does strict type checking.

Exceptions:
* use compatible array instance instead of pointer types
* use cast() function to case a ctype instance into a pointer to a different ctype data type

cast()
------
cast() takes two parameters, a ctypes object that is or can be converted to a pointer of some kind,
and a ctypes pointer type.
It returns an instance of the second argument, which references the same memory block as
the first argument.

::
>>> o = (c_byte * 4) (1, 2, 3, 4)
>>> for i in range(len(o)):
...     print o[i],
1 2 3 4
>>> n = cast(o, POINTER(c_int))
>>> print hex(n[0])
0x4030201

incomplete types
================
Incomplete Types are structures, unions or arrays whose members are not yet specified.
In C, they are specified by forward declarations, which are defined later.

::

    struct cell;
    struct cell {
        char \*name;
        struct cell \*next;
    };

    class cell(Structure):
        pass
    cell._fields_ = [("name", c_char_p), ("next", POINTER(cell))]

callback functions
==================
ctypes allows to create C callable function pointers (callback functions) from Python callables.

Using CFUNCTYPE or WINDFUNCTYPE factory function to create types for callback functions.
Both of these factory functions are called with the result type as first argument,
and the callback functions expected argument types as the remaining arguments.

>>> CMPFUNC = CFUNCTYPE(c_int, POINTER(c_int), POINTER(c_int))
>>> def py_cmp_func(a, b):
...     print "py_cmp_func", a[0], b[0]
...     return a[0] - b[0]
>>> cmp_func = CMPFUNC(py_cmp_func)

>>> IntArray5 = c_int * 5
>>> ia = IntArray5(5, 1, 7, 33, 99)
>>> qsort = libc.qsort
>>> qsort.restype = None
>>> qsort(ia, len(ia), sizeof(c_int), cmp_func)

reference to CFUNCTYPE object
-----------------------------
Make sure you keep references to CFUNCTYPE objects as long as they are used from C code.
ctypes doesn’t, and if you don’t, they may be garbage collected,
crashing your program when a callback is made.

accessing variables exported from dlls
======================================
ctypes can access values like this with the in_dll() class methods of the type. [#]_

The first argument of in_dll() is the loaded shared library, and the second argument
is the name of the symbol that exports the data.
It returns a ctypes type instance exported by a shared library.

::

    >>> opt_flag = c_int.in_dll(pythonapi, "Py_OptimizeFlag")
    >>> print opt_flag
    c_long(0)

surprises
=========

* Keep in mind that retrieving sub-objects from Structure, Unions, and Arrays
  doesn’t copy the sub-object, instead it retrieves a wrapper object accessing
  the root-object’s underlying buffer.

* ctypes instances are objects containing a memory block plus some descriptors
  accessing the contents of the memory. Storing a Python object in the memory block
  does not store the object itself, instead the contents of the object is stored.
  Accessing the contents again constructs a new Python object each time!

variable-sized data types
=========================
ctypes provides some support for variable-sized arrays and structures.

resize()
--------
The resize() function can be used to resize the memory buffer of an existing ctypes object.
The function takes the object as first argument,
and the requested size in bytes as the second argument.

After invoking resize, there is not method to access the additional elements.

redefine
--------
Another way to use variable-sized data types with ctypes is to use the dynamic nature of Python,
and (re-)define the data type after the required size is already known, on a case by case basis.


.. [#] c_int and c_long are the same type.
.. [#] the compiler used to build the interpreter ?
.. [#] the byte order of the host running the interpreter ?
.. [#] the type of export variables.
