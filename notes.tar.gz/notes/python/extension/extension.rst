===============================
Extending Python With C or C++
===============================

------------------------
Why Extension is Needed
------------------------
Such extension modules can do two things that can’t be done directly in Python:

* they can implement new built-in object types
* they can call C library functions and system calls

ctypes
======
Do note that if your use case is calling C library functions or system calls,
you should consider using the ctypes module rather than writing custom C code.

* ctypes let you write Python code to interface with C code
* it is more portable between implementations of Python than writing and compiling
  an extension module which typically ties you to CPython

----------------------
Errors and Exceptions
----------------------
three global variables: exception, the "associated value" of the exception, and the
stack traceback in case the error originated in Python code.

PyErr_SetString
===============
Its arguments are an exception object and a C string.
The exception object is usually a predefined object like PyExc_ZeroDivisionError.
The C string indicates the cause of the error and is converted to a Python string object and
stored as the “associated value” of the exception.

PyErr_SetFromErrno
==================
It only takes an exception argument and
constructs the associated value by inspection of the global variable errno.

PyErr_SetObject
===============
It takes two object arguments, the exception and its associated value.
You don’t need to Py_INCREF() the objects passed to any of these functions.

PyErr_Clear
===========
To ignore an exception set by a function call that failed,
the exception condition must be cleared explicitly by calling PyErr_Clear().

The only time C code should call PyErr_Clear() is if it doesn’t want to pass the error
on to the interpreter but wants to handle it completely by itself
(possibly by trying something else, or pretending nothing went wrong).

PyErr_NewException
==================
use it to create a new exception.

-------------------------------
Calling Python Functions from C
-------------------------------
when the C interface makes use of callbacks, the C callback will
need to call the Python callback.

PyObject_CallObject
===================
This function has two arguments, both pointers to arbitrary Python objects:
the Python function, and the argument list.

The argument list must always be a tuple object, whose length is the number of arguments.
To call the Python function with no arguments, pass in NULL, or an empty tuple;
to call it with one argument, pass a singleton tuple.

PyObject_Call
=============
You may also call a function with keyword arguments by using PyObject_Call(),
which supports arguments and keyword arguments.

---------------------
Extracting Parameters
---------------------

prototype
=========
int PyArg_ParseTuple(PyObject \*arg, char \*format, ...);

The arg argument must be a tuple object containing an argument list passed from Python to a C function.
The format argument must be a format string,
whose syntax is explained in Parsing arguments and building values in the Python/C API Reference Manual.
The remaining arguments must be addresses of variables whose type is determined by the format string.

Note that while PyArg_ParseTuple() checks that the Python arguments have the required types,
it cannot check the validity of the addresses of C variables passed to the call.

example
=======
::

    PyObject *cb;
    ok = PyArg_ParseTuple(args, "O:set_callback", &cb)

    long k;
    int i, j;
    const char *s;
    ok = PyArg_ParseTuple(args, "l(ii)s#", &k, &i, &j, &s, &size);
    /* the size of the string is also returned */
    /* Possible Python call: f(0, (1, 2), 'three') */

    const char *file;
    const char *mode = "r";
    int bufsize = 0;
    ok = PyArg_ParseTuple(args, "s|si", &file, &mode, &bufsize);
    /* A string, and optionally another string and an integer */
    /* Possible Python calls:
       f('spam')
       f('spam', 'w')
       f('spam', 'wb', 100000) */

    Py_complex c;
    ok = PyArg_ParseTuple(args, "D:myfunction", &c);
    /* a complex, also providing a function name for errors */
    /* Possible Python call: myfunction(1+2j) */

keyword parameters
==================

prototype
---------
int PyArg_ParseTupleAndKeywords(PyObject \*arg, PyObject \*kwdict,
                                char \*format, char \*kwlist[], ...);

The arg and format parameters are identical to those of the PyArg_ParseTuple() function.
The kwdict parameter is the dictionary of keywords received as the third parameter from
the Python runtime.
The kwlist parameter is a NULL-terminated list of strings which identify the parameters;
the names are matched with the type information from format from left to right.

On success, PyArg_ParseTupleAndKeywords() returns true,
otherwise it returns false and raises an appropriate exception.

Keyword parameters passed in which are not present in the kwlist will cause TypeError to be raised.

example
-------
::

    static PyObject *
    keywdarg_parrot(PyObject *self, PyObject *args, PyObject *keywds)
    {
        int voltage;
        char *state = "a stiff";
        char *action = "voom";
        char *type = "Norwegian Blue";

        static char *kwlist[] = {"voltage", "state", "action", "type", NULL};

        if (!PyArg_ParseTupleAndKeywords(args, keywds, "i|sss", kwlist,
                                         &voltage, &state, &action, &type))
            return NULL;

        printf("-- This parrot wouldn't %s if you put %i Volts through it.\n",
               action, voltage);
        printf("-- Lovely plumage, the %s -- It's %s!\n", type, state);

        Py_INCREF(Py_None);

        return Py_None;
    }

    static PyMethodDef keywdarg_methods[] = {
        /* The cast of the function is necessary since PyCFunction values
         * only take two PyObject* parameters, and keywdarg_parrot() takes
         * three.
         */
        {"parrot", (PyCFunction)keywdarg_parrot, METH_VARARGS | METH_KEYWORDS,
         "Print a lovely skit to standard output."},
        {NULL, NULL, 0, NULL}   /* sentinel */
    };

-------------------------
Building Arbitrary Values
-------------------------

prototype
=========
PyObject \*Py_BuildValue(char \*format, ...);

It recognizes a set of format units similar to the ones recognized by PyArg_ParseTuple(),
but the arguments (which are input to the function, not output) must not be pointers, just values.
It returns a new Python object, suitable for returning from a C function called from Python or
using as the argument for PyObject_CallObject/PyObject_Call.

One difference with PyArg_ParseTuple(): while the latter requires its first argument to be a tuple
(since Python argument lists are always represented as tuples internally),
Py_BuildValue() does not always build a tuple.

It builds a tuple only if its format string contains two or more format units.
If the format string is empty, it returns None;
if it contains exactly one format unit, it returns whatever object is described by that format unit.
To force it to return a tuple of size 0 or one, parenthesize the format string.

example
=======
::

    Py_BuildValue("")                        None
    Py_BuildValue("i", 123)                  123
    Py_BuildValue("iii", 123, 456, 789)      (123, 456, 789)
    Py_BuildValue("s", "hello")              'hello'
    Py_BuildValue("ss", "hello", "world")    ('hello', 'world')
    Py_BuildValue("s#", "hello", 4)          'hell'
    Py_BuildValue("()")                      ()
    Py_BuildValue("(i)", 123)                (123,)
    Py_BuildValue("(ii)", 123, 456)          (123, 456)
    Py_BuildValue("(i,i)", 123, 456)         (123, 456)
    Py_BuildValue("[i,i]", 123, 456)         [123, 456]
    Py_BuildValue("{s:i,s:i}", "abc", 123, "def", 456)    {'abc': 123, 'def': 456}
    Py_BuildValue("((ii)(ii)) (ii)", 1, 2, 3, 4, 5, 6)    (((1, 2), (3, 4)), (5, 6))

----------------
Reference Counts
----------------
Since Python makes heavy use of malloc() and free(), it needs a strategy to avoid memory leaks
as well as the use of freed memory. The chosen method is called reference counting.
The principle is simple: every object contains a counter,
which is incremented when a reference to the object is stored somewhere,
and which is decremented when a reference to it is deleted.  When the counter reaches zero,
the last reference to the object has been deleted and the object is freed.

automatic gc
=============
An alternative strategy is called automatic garbage collection.
(Sometimes, reference counting is also referred to as a garbage collection strategy,
hence my use of “automatic” to distinguish the two.)

The big advantage of automatic garbage collection is that the user doesn’t need to call
free() explicitly. (Another claimed advantage is an improvement in speed or memory usage -
this is no hard fact however.)

The disadvantage is that for C, there is no truly portable automatic garbage collector (portable
to different computer architectures), while reference counting can be implemented portably
(as long as the functions malloc() and free() are available — which the C Standard guarantees).

Py_INCREF and Py_DECREF
=======================

owned reference
---------------
Nobody “owns” an object; however, you can own a reference to an object.
An object’s reference count is now defined as the number of owned references to it.
The owner of a reference is responsible for calling Py_DECREF() when the reference is no longer needed.

Ownership of a reference can be transferred.
here are three ways to dispose of an owned reference: pass it on, store it, or call Py_DECREF().
Forgetting to dispose of an owned reference creates a memory leak.

borrowed reference
------------------
It is also possible to borrow a reference to an object.
The borrower of a reference should not call Py_DECREF().
The borrower must not hold on to the object longer than the owner from which it was borrowed.
Using a borrowed reference after the owner has disposed of it risks using freed memory and
should be avoided completely.

The advantage of borrowing over owning a reference is that you don’t need to take care of
disposing of the reference on all possible paths through the code — in other words,
with a borrowed reference you don’t run the risk of leaking when a premature exit is taken.

The disadvantage of borrowing over owning is that there are some subtle situations where
in seemingly correct code a borrowed reference can be used after the owner from which
it was borrowed has in fact disposed of it.

A borrowed reference can be changed into an owned reference by calling Py_INCREF().
This does not affect the status of the owner from which the reference was borrowed -
it creates a new owned reference, and gives full owner responsibilities
(the new owner must dispose of the reference properly, as well as the previous owner).

trap
++++
There are a few situations where seemingly harmless use of a borrowed reference can lead to problems.
These all have to do with implicit invocations of the interpreter,
which can cause the owner of a reference to dispose of it.

The first and most important case to know about is using Py_DECREF() on an unrelated object
while borrowing a reference to a list item. For instance:

The second case of problems with a borrowed reference is a variant involving threads.

ownership rules
===============
Whenever an object reference is passed into or out of a function,
it is part of the function’s interface specification whether ownership is transferred with
the reference or not.

Most functions that return a reference to an object pass on ownership with the reference.

When you pass an object reference into another function, in general, the function borrows
the reference from you — if it needs to store it, it will use Py_INCREF() to become an
independent owner. There are exactly two important exceptions to this rule:
PyTuple_SetItem() and PyList_SetItem(). These functions take over ownership of the item
passed to them — even if they fail!

When a C function is called from Python, it borrows references to its arguments from the caller.
The caller owns a reference to the object, so the borrowed reference’s lifetime is guaranteed
until the function returns. Only when such a borrowed reference must be stored or passed on,
it must be turned into an owned reference by calling Py_INCREF().

The object reference returned from a C function that is called from Python must be an owned reference
- ownership is transferred from the function to its caller.

NULL pointers
=============
In general, functions that take object references as arguments do not expect you to
pass them NULL pointers, and will dump core (or cause later core dumps) if you do so.
Functions that return object references generally return NULL only to indicate that
an exception occurred.

The reason for not testing for NULL arguments is that functions often pass the objects
they receive on to other function — if each function were to test for NULL,
there would be a lot of redundant tests and the code would run more slowly.

It is better to test for NULL only at the “source:” when a pointer that may be NULL is received,
for example, from malloc() or from a function that may raise an exception.

The macros Py_INCREF() and Py_DECREF() do not check for NULL pointers — however,
their variants Py_XINCREF() and Py_XDECREF() do.

The macros for checking for a particular object type (Pytype_Check()) don’t check for NULL pointers.

------------------------------------------
Providing a C API for an Extension Module
------------------------------------------
Portability therefore requires not to make any assumptions about symbol visibility.
This means that all symbols in extension modules should be declared static,
except for the module’s initialization function, in order to avoid name clashes with
other extension modules. And it means that symbols that should be accessible from
other extension modules must be exported in a different way.

Python provides a special mechanism to pass C-level information (pointers) from one
extension module to another one: Capsules. A Capsule is a Python data type which stores
a pointer (void \*). Capsules can only be created and accessed via their C API,
but they can be passed around like any other Python object.
In particular, they can be assigned to a name in an extension module’s namespace.
Other extension modules can then import this module, retrieve the value of this name,
and then retrieve the pointer from the Capsule.

