from distutils.core import setup, Extension

m = Extension('spam', sources = ['spammodule.c'])

setup(name = 'demo', version = '1.0', description = 'demo', ext_modules = [m])
