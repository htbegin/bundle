=====
sysfs
=====

--------------------
linux kernel version
--------------------
2.6.36.

--------------------
Kconfig and Makefile
--------------------

Kconfig
=======

fs/Kconfig
----------
::

    menu "Pseudo filesystems"

    source "fs/proc/Kconfig"
    source "fs/sysfs/Kconfig"

fs/sysfs/Kconfig
----------------
::

    config SYSFS
        bool "sysfs file system support" if EMBEDDED
        default y

It means if sysfs is built-in unless EMBEDDED is selected [#]_.

.. [#] the menu entry for sysfs doesn't appear when the option EMBEDDED is disabled.

dependency
----------
block subsystem::

    sysfs is currently used by the block subsystem to mount the root
    partition.  If sysfs is disabled you must specify the boot device on
    the kernel boot command line via its major and minor numbers.  For
    example, "root=03:01" for /dev/hda1.

Makefile
========

fs/Makefile
-----------
::

    obj-$(CONFIG_SYSFS)	+= sysfs/

fs/sysfs/Makefile
-----------------
::

    obj-y := inode.o file.o dir.o symlink.o mount.o bin.o group.o

sysfs.h
=======
struct sysfs_elem_dir

struct sysfs_elem_symlink
    it can only link to a directory.

struct sysfs_elem_attr

struct sysfs_elem_bin_attr
    buffers

struct sysfs_inode_attrs

struct sysfs_dirent
-------------------

s_count versus s_active
+++++++++++++++++++++++
the use case of the two field?

CONFIG_DEBUG_LOCK_ALLOC
+++++++++++++++++++++++
defined under lib/Kconfig.debug.

child
+++++
if it's a directory, it contains struct sysfs_elem_dir and there is children field in it.
if it's a symlink, attr, or bin_attr, it doesn't have a child.

inode
+++++
there is inode id for all sysfs file.

struct sysfs_addrm_cxt

struct sysfs_super_info
-----------------------

mount.c
=======

include directive
-----------------
::

    #include "sysfs.h"
    ""
    For files specified between angle brackets (<filename>), the preprocessor
    usually searches in certain system directories.
    For header files specified in quotation marks ("filename"), the preprocessor
    usually looks in the current directory first. If such a file is not found
    in the current directory, the preprocessor searches the system directories as well.
    ""
