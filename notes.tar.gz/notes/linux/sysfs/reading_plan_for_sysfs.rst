=======================
reading plan for sysfs
=======================

----------------
code about sysfs
----------------

path
====
under fs/sysfs/ directory.

deadline
========
2011.05.29

status
======

--------------
code about vfs
--------------

path
====
under fs/ directory.

status
======

--------------------------
code about usage of sysfs
--------------------------

path
====
under drivers/ directory.

selected target
===============

+ common sysfs file for linux kernel, such as module, filesystem.
+ common sysfs file for linux device driver model.
+ specific sysfs file for USB subsystem.

status
======

