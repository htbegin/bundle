questions about kernel
======================

kernel thread
-------------
Before the first usermode process init is spawned, is it possible
to start a new kernel thread by using workqueue or something else similar ?

mmap
----
driver how to get notified when the mmapped area is written by userspace application ?
