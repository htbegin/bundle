===
vim
===

session
=======

save session
------------
:mksession s.vim

restore session
---------------
:source s.vim 或者 vim -S s.vim

substitute cmd
==============

将匹配的数字加1
---------------
::

    :%s#, \([[:digit:]]\+\)#\=printf("%d", submatch(1)+1)#gc

将配置的词变为小写
------------------
::

:%s#RET_\([A-Z_]\+\).*#ftk_constants.RET_\1 : "\L\1\E",#gc

more info from :help sub-replace-special

copy & paste
============

在命令模式下粘贴
----------------
ctrl-R + register name

customize command
=================
自定义的命令的第一个字母必须大写。例如：

:command Utag !ctags -R --langmap=c:+.h --c-kinds=+px

define command sequence
=======================
打开与当前光标下的词语相对应的文件::

    map <F12> :let w=expand("<cword>")<CR>:exe "tabe "printf("ftk/%s.py", substitute(w, "ftk_", "", ""))""<CR>:exe "split "printf("../../src/%s.h", w)""<CR>
