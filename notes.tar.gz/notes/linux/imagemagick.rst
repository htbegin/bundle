===========
ImageMagick
===========

convert
=======

crop
----
convert -crop 700x500+0+0 large.jpeg small.jpeg

从(0,0)处裁剪出大小为700x500的图像。

format convert
--------------
convert -colorspace YUV -size 1920x1080 -depth 8 -sampling-factor 4:2:2 color.yuv color.bmp

将YUV422转化为BMP。

convert color.bmp -colorspace YUV -sampling-factor 4:2:2 color.yuv

将BMP转换为YUV422

resize
------
convert input.png -resize 64x64 output.png

缩放为64x64大小的图片，保持缩放比。最终大小可能不是64x64。

convert input.png -resize 64x64\! output.png

缩放为64x64大小的图片，不保持缩放比。最终大小是64x64。

canvas creation
---------------
convert -size 100x100 xc:blue canvas.png

生成100x100大小的全蓝色图片。

display
=======
display -colorspace RGB -size 1920x1080 -depth 8 -sampling-factor 4:2:2 color.yuv

显示YUV422的数据。
