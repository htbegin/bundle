========================
mount jffs2 on Linux PC
========================


--------------
jffs2 device
--------------
When the NAND Flash in embedded device is used as the backing file
for g_file_storage module, a mtdblock device is exported to the PC
as a jffs2 device, such as /dev/sdb.

Assume the erase-block size of the NAND Flash is 16KiB.

::

    modprobe jffs2
    modprobe mtdblock
    modprobe block2mtd block2mtd=/dev/sdb,16KiB
    mount -t jffs2 /dev/mtdblock0 /media/DM

    umount /dev/mtdblock0
    modprobe -r block2mtd
    modprobe -r mtdblock
    modprobe -r jffs2

.. Note::
    the block device and its eraseblock size can be changed dynamically:
        echo "/dev/sdb,16KiB" > /sys/module/block2mtd/parameters/block2mtd

    the corresponding mtdblockX is decided by the output of block2mtd:
        block2mtd: mtd0: [/dev/sdb] erase_size = 16KiB [16384]

    sometimes the /dev/mtdblockX device file doesn't be created automatically,
    so you need to create them manually: mknod /dev/mtdblock0 b 31 0

------------
jffs2 file
------------
The extra thing you need to do is to use /dev/loopx to replace the /dev/sdb.

::

    modprobe loop
    losetup /dev/loop0 rootfs.jffs2

    modprobe jffs2
    modprobe mtdblock
    modprobe block2mtd block2mtd=/dev/loop0,16KiB
    mount -t jffs2 /dev/mtdblock0 /media/DM

    umount /dev/mtdblock0
    modprobe -r block2mtd
    modprobe -r mtdblock
    modprobe -r jffs2
    losetup -d /dev/loop0
    modprobe -r loop

------------
more infos
------------

`Modifying the root image <https://wiki.maemo.org/Modifying_the_root_image>`_

