==========
PSR_I_BIT
==========

-----------------------------
arch/arm/kernel/crunch-bits.S
-----------------------------
CONFIG_CRUNCH is disabled.

-------------------------
arch/arm/kernel/iwmmxt.S
-------------------------
CONFIG_IWMMXT is disabled.

-----------------------------
arch/arm/kernel/head-nommu.S
-----------------------------
CONFIG_MMU is enabled.

----------------------
arch/arm/kernel/head.S
----------------------
stext, invoked by kernel loader.

secondary_startup CONFIG_SMP is disabled.

-----------------------------
arch/arm/kernel/entry-armv.S
-----------------------------
Data Abort handler: __dabt_svc
Interrupt handler: __irq_svc
Prefetch Abort handler: __pabt_svc

--------------------------
include/asm-arm/irqflags.h
--------------------------
raw_local_irq_save
raw_local_irq_disable

------------------------
arch/arm/kernel/setup.c
------------------------
cpu_init

----------------------
arch/arm/kernel/fiq.c
----------------------
set_fiq_regs

get_fiq_regs


IRQ handler
===========
How does the PSR_I_BIT been set ?

System Call
===========
__syscall(brk)

::

    #define __NR_OABI_SYSCALL_BASE	0x900000
    #define __NR_SYSCALL_BASE	__NR_OABI_SYSCALL_BASE
    #define __NR_brk			(__NR_SYSCALL_BASE+45)

    #define __sys2(x) #x
    #define __sys1(x) __sys2(x)

    #define __syscall(name) "swi\t" __sys1(__NR_##name) ""

"swi\t" "0x90002d" ""

?

vector_swi (disable_irq enable_irq)

Bug
====
The sequence of syscall in ARM926EJ-S ?

How does the __spin_lock_irq been invoked ?

Why __spin_lock_irq is invoked, but the PSR_I_BIT doesn't been set ?

dmesg
======
::

    VFS: Mounted root (nfs filesystem).
    *****************************************************************************
    *                                                                           *
    *  REMINDER, the following debugging options are turned on in your .config: *
    *                                                                           *
    *        CONFIG_DEBUG_RT_MUTEXES                                            *
    *        CONFIG_DEBUG_PREEMPT                                               *
    *        CONFIG_DEBUG_SLAB                                                  *
    *        CONFIG_LOCKDEP                                                     *
    *                                                                           *
    *  they may increase runtime overhead and latencies.                        *
    *                                                                           *
    *****************************************************************************
    Freeing init memory: 172K
    stopped custom tracer.
    default.hotplug/265[CPU#0]: BUG in check_flags at kernel/lockdep.c:2371
    [<c003891c>] (dump_stack+0x0/0x24) from [<c0048fe4>] (__WARN_ON+0x58/0x74)
    [<c0048f8c>] (__WARN_ON+0x0/0x74) from [<c0064090>] (check_flags+0xa8/0x23c)
     r8 = 00000000  r7 = 00000000  r6 = 00000000  r5 = C6354000
     r4 = 60000013
    [<c0063fe8>] (check_flags+0x0/0x23c) from [<c0067304>] (lock_acquire+0x58/0x98)
     r4 = 60000013
    [<c00672ac>] (lock_acquire+0x0/0x98) from [<c0061e20>] (compat_down_write+0x44/0x58)
    [<c0061ddc>] (compat_down_write+0x0/0x58) from [<c0086c74>] (sys_brk+0x30/0xfc)
     r5 = 000000FC  r4 = C6354000
    [<c0086c44>] (sys_brk+0x0/0xfc) from [<c0033fd8>] (__sys_trace_return+0x0/0x28)
     r8 = C0034008  r7 = 0000002D  r6 = 00001000  r5 = 000000FC
     r4 = 000B9000
    ---------------------------
    | preempt count: 00000001 ]
    | 1-level deep critical section nesting:
    ----------------------------------------
    .. [<c033df38>] .... __spin_lock_irqsave+0x30/0x64
    .....[<c0048fb4>] ..   ( <= __WARN_ON+0x28/0x74)

    irq event stamp: 5927
    hardirqs last  enabled at (5926): [<c0033cc4>] __irq_usr+0x84/0xa0
    hardirqs last disabled at (5927): [<c033ded0>] __spin_lock_irq+0x28/0x60
    softirqs last  enabled at (5925): [<c004dbb0>] __do_softirq+0x58/0x6c
    softirqs last disabled at (5902): [<c004e0b4>] irq_exit+0x60/0x74
    INIT: version 2.86 booting
    Starting the hotplug events dispatcher: udevd.
    Synthesizing the initial hotplug events...done.
    Waiting for /dev to be fully populated...done.
