firmware load mechanism in linux kernel
=======================================

kernel version
--------------
2.6.18

kernel cfg
----------
CONFIG_FW_LOADER

firmware load process
---------------------
1. device driver invoke request_firmware and its variants
2. the related hotplug event is passed to userspace
3. a userspace process writes the firmware to a sysfs file
4. device driver copy the firmware from the sysfs file and load it to the device

hotplug event
-------------
Linux provides two interfaces to hotplug: the kernel can spawn a usermode helper
process, or it can send a message to an existing daemon listening to a netlink
socket.

usermode helper
~~~~~~~~~~~~~~~
The default usermode process is /sbin/hotplug. The process can be changed
by writing a new path into /proc/sys/kernel/hotplug.

The information about the hotplug event is passed to the usermode process
by its enviroment variables.

The usermode helper mechanism can be disabled by writing a empty string to
/proc/sys/kernel/hotplug.

load firmware before init
+++++++++++++++++++++++++
It is possible using the usermode helper mechanism to implement loading
firmware from initramfs before the init process is spawned.

udev
~~~~
udev listening to the netlink socket receives a packet of data for each
hotplug event, containing the same information a usermode helper would receive
in environment variables.

udev rules
++++++++++
50-firmware.rules::

    # firmware-class requests, copies files into the kernel
    SUBSYSTEM=="firmware", ACTION=="add", RUN+="firmware --firmware=$env{FIRMWARE} --devpath=$env{DEVPATH}"

when there is firmware request from kernel, the usermode process firmware will be run
with its firmware and devpath options.

more information
----------------
*firmware_class*
    Documentation/firmware_class/

*hotplug*
    http://lwn.net/Articles/242046/
