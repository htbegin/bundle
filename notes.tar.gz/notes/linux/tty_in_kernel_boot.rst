=========
TTY Usage
=========

------
loader
------
arch/arm/boot/compressed/head.S

decompress_kernel in arch/arm/boot/compressed/misc.c

::

    Uncompressing Linux......................... done, booting the kernel.

-------
kernel
-------
arch/arm/kernel/head.S

start_kernel in init/main.c

::

    Linux version 2.6.18_pro500-davinci_evm-arm_v5t_le (work@localhost.localdomain) (gcc version 4.2.0 (MontaVista 4.2.0-16.0.32.0801914 2008-08-30)) #1 PREEMPT Sat Jun 18 11:07:38 CST 2011
    CPU: ARM926EJ-S [41069265] revision 5 (ARMv5TEJ), cr=00053177
    Machine: DaVinci EVM
    Memory policy: ECC disabled, Data cache writeback
    On node 0 totalpages: 30208
      DMA zone: 30208 pages, LIFO batch:7
    DaVinci DM6443 variant 0x0
    CPU0: D VIVT write-back cache
    CPU0: I cache: 16384 bytes, associativity 4, 32 byte lines, 128 sets
    CPU0: D cache: 8192 bytes, associativity 4, 32 byte lines, 64 sets
    Built 1 zonelists.  Total pages: 30208
    Kernel command line: mem=118M console=ttyS0,115200n8 root=/dev/nfs rw noinitrd nfsroot=192.168.1.90:/dm6446/nfs debug eth=08:00:27:05:A9:EB video=davincifb:vid0=0,3672K:vid1=0,3672K:osd0=720x576x16,1620K@0,0:osd1=720x576x4,1620K@0,0 ip=192.168.1.239:192.168.1.90:192.168.1.90:255.255.255.0
    TI DaVinci EMAC: Kernel Boot params Eth address: 08:00:27:05:A9:EB
    PID hash table entries: 512 (order: 9, 2048 bytes)
    Clock event device timer0_0 configured with caps set: 03
    Console: colour dummy device 80x30
    Lock dependency validator: Copyright (c) 2006 Red Hat, Inc., Ingo Molnar
    ... MAX_LOCKDEP_SUBCLASSES:    8
    ... MAX_LOCK_DEPTH:          30
    ... MAX_LOCKDEP_KEYS:        2048
    ... CLASSHASH_SIZE:           1024
    ... MAX_LOCKDEP_ENTRIES:     8192
    ... MAX_LOCKDEP_CHAINS:      8192
    ... CHAINHASH_SIZE:          4096
     memory used by lock dependency info: 696 kB
     per task-struct memory footprint: 1200 bytes
    ------------------------
    | Locking API testsuite:
    ----------------------------------------------------------------------------
                                     | spin |wlock |rlock |mutex | wsem | rsem |
      --------------------------------------------------------------------------
                         A-A deadlock:  ok  |  ok  |  ok  |  ok  |  ok  |  ok  |
                     A-B-B-A deadlock:  ok  |  ok  |  ok  |  ok  |  ok  |  ok  |
                 A-B-B-C-C-A deadlock:  ok  |  ok  |  ok  |  ok  |  ok  |  ok  |
                 A-B-C-A-B-C deadlock:  ok  |  ok  |  ok  |  ok  |  ok  |  ok  |
             A-B-B-C-C-D-D-A deadlock:  ok  |  ok  |  ok  |  ok  |  ok  |  ok  |
             A-B-C-D-B-D-D-A deadlock:  ok  |  ok  |  ok  |  ok  |  ok  |  ok  |
             A-B-C-D-B-C-D-A deadlock:  ok  |  ok  |  ok  |  ok  |  ok  |  ok  |
                        double unlock:  ok  |  ok  |  ok  |  ok  |  ok  |  ok  |
                      initialize held:  ok  |  ok  |  ok  |  ok  |  ok  |  ok  |
                     bad unlock order:  ok  |  ok  |  ok  |  ok  |  ok  |  ok  |
      --------------------------------------------------------------------------
                  recursive read-lock:             |  ok  |             |  ok  |
               recursive read-lock #2:             |  ok  |             |  ok  |
                mixed read-write-lock:             |  ok  |             |  ok  |
                mixed write-read-lock:             |  ok  |             |  ok  |
      --------------------------------------------------------------------------
         hard-irqs-on + irq-safe-A/12:  ok  |  ok  |  ok  |
         soft-irqs-on + irq-safe-A/12:  ok  |  ok  |  ok  |
         hard-irqs-on + irq-safe-A/21:  ok  |  ok  |  ok  |
         soft-irqs-on + irq-safe-A/21:  ok  |  ok  |  ok  |
           sirq-safe-A => hirqs-on/12:  ok  |  ok  |  ok  |
           sirq-safe-A => hirqs-on/21:  ok  |  ok  |  ok  |
             hard-safe-A + irqs-on/12:  ok  |  ok  |  ok  |
             soft-safe-A + irqs-on/12:  ok  |  ok  |  ok  |
             hard-safe-A + irqs-on/21:  ok  |  ok  |  ok  |
             soft-safe-A + irqs-on/21:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #1/123:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #1/123:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #1/132:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #1/132:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #1/213:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #1/213:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #1/231:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #1/231:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #1/312:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #1/312:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #1/321:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #1/321:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #2/123:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #2/123:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #2/132:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #2/132:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #2/213:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #2/213:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #2/231:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #2/231:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #2/312:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #2/312:  ok  |  ok  |  ok  |
        hard-safe-A + unsafe-B #2/321:  ok  |  ok  |  ok  |
        soft-safe-A + unsafe-B #2/321:  ok  |  ok  |  ok  |
          hard-irq lock-inversion/123:  ok  |  ok  |  ok  |
          soft-irq lock-inversion/123:  ok  |  ok  |  ok  |
          hard-irq lock-inversion/132:  ok  |  ok  |  ok  |
          soft-irq lock-inversion/132:  ok  |  ok  |  ok  |
          hard-irq lock-inversion/213:  ok  |  ok  |  ok  |
          soft-irq lock-inversion/213:  ok  |  ok  |  ok  |
          hard-irq lock-inversion/231:  ok  |  ok  |  ok  |
          soft-irq lock-inversion/231:  ok  |  ok  |  ok  |
          hard-irq lock-inversion/312:  ok  |  ok  |  ok  |
          soft-irq lock-inversion/312:  ok  |  ok  |  ok  |
          hard-irq lock-inversion/321:  ok  |  ok  |  ok  |
          soft-irq lock-inversion/321:  ok  |  ok  |  ok  |
          hard-irq read-recursion/123:  ok  |
          soft-irq read-recursion/123:  ok  |
          hard-irq read-recursion/132:  ok  |
          soft-irq read-recursion/132:  ok  |
          hard-irq read-recursion/213:  ok  |
          soft-irq read-recursion/213:  ok  |
          hard-irq read-recursion/231:  ok  |
          soft-irq read-recursion/231:  ok  |
          hard-irq read-recursion/312:  ok  |
          soft-irq read-recursion/312:  ok  |
          hard-irq read-recursion/321:  ok  |
          soft-irq read-recursion/321:  ok  |
    -------------------------------------------------------
    Good, all 218 testcases passed! |
    ---------------------------------
    Dentry cache hash table entries: 16384 (order: 4, 65536 bytes)
    Inode-cache hash table entries: 8192 (order: 3, 32768 bytes)
    Memory: 118MB = 118MB total
    Memory: 113152KB available (3569K code, 2662K data, 172K init)
    Calibrating delay loop... 147.04 BogoMIPS (lpj=735232)
    Security Framework v1.0.0 initialized
    Capability LSM initialized
    Mount-cache hash table entries: 512
    CPU: Testing write buffer coherency: ok
    NET: Registered protocol family 16
    DaVinci: 71 gpio irqs
    MUX: initialized SPI
    MUX: Setting register SPI
          PINMUX1 (0x01c40004) = 0x00000081 -> 0x00000181
    SCSI subsystem initialized
    usbcore: registered new driver usbfs
    usbcore: registered new driver hub
    NET: Registered protocol family 2
    IP route cache hash table entries: 1024 (order: 0, 4096 bytes)
    TCP established hash table entries: 4096 (order: 5, 163840 bytes)
    TCP bind hash table entries: 2048 (order: 4, 90112 bytes)
    TCP: Hash tables configured (established 4096 bind 2048)
    TCP reno registered
    Initializing RT-Tester: OK
    VFS: Disk quotas dquot_6.5.1
    Dquot-cache hash table entries: 1024 (order 0, 4096 bytes)
    squashfs: version 3.1 (2006/08/19) Phillip Lougher
    JFFS2 version 2.2. (NAND) (C) 2001-2006 Red Hat, Inc.
    yaffs Jun 18 2011 10:59:09 Installing. 
    SGI XFS with no debug enabled
    Initializing Cryptographic API
    io scheduler noop registered
    io scheduler anticipatory registered (default)
    LTT : ltt-facilities init
    LTT : ltt-facility-core init in kernel
    DAVINCI-WDT: DaVinci Watchdog Timer: heartbeat 60 sec
    Serial: 8250/16550 driver $Revision: 1.90 $ 2 ports, IRQ sharing disabled
    serial8250.0: ttyS0 at MMIO map 0x1c20000 mem 0xfec20000 (irq = 40) is a 16550A
    serial8250.0: ttyS1 at MMIO map 0x1c20400 mem 0xfec20400 (irq = 41) is a 16550A
    RAMDISK driver initialized: 1 RAM disks of 32768K size 1024 blocksize
    netconsole: not configured, aborting
    TI DaVinci EMAC: MAC address is 08:00:27:05:A9:EB
    TI DaVinci EMAC Linux version updated 4.0
    TI DaVinci EMAC: Installed 1 instances.
    Linux video capture interface: v2.00
    ch0 default output "COMPOSITE", mode "PAL"
    Trying to register davinci display video device.
    layer=c7572c00,layer->video_dev=c7572dc8
    Trying to register davinci display video device.
    layer=c7572800,layer->video_dev=c75729c8
    davinci_init:DaVinci V4L2 Display Driver V1.0 loaded
    i2c /dev entries driver
    nand_davinci nand_davinci.0: Using 1-bit hardware ECC
    NAND device: Manufacturer ID: 0xec, Chip ID: 0x36 (Samsung NAND 64MiB 1,8V 8-bit)
    Scanning device for bad blocks
    Creating 4 MTD partitions on "nand_davinci.0":
    0x00000000-0x00040000 : "bootloader"
    0x00040000-0x00060000 : "params"
    0x00060000-0x00460000 : "kernel"
    0x00460000-0x04000000 : "filesystem"
    nand_davinci nand_davinci.0: hardware revision: 2.1
    Initializing USB Mass Storage driver...
    usbcore: registered new driver usb-storage
    USB Mass Storage support registered.
    usbcore: registered new driver usbhid
    drivers/usb/input/hid-core.c: v2.6:USB HID core driver
    musb_hdrc: version 6.0/dbg, cppi-dma, peripheral, debug=1
    DaVinci OTG revision 00147900 phy 1f0 control 00
    musb_hdrc musb_hdrc: No DMA interrupt line
    musb_hdrc: ConfigData=0x06 (UTMI-8, dyn FIFOs, SoftConn)
    musb_hdrc: MHDRC RTL version 1.300 
    musb_hdrc: setup fifo_mode 2
    musb_hdrc: 7/9 max ep, 2624/4096 memory
    musb_hdrc: hw_ep 0shared, max 64
    musb_hdrc: hw_ep 1tx, max 512
    musb_hdrc: hw_ep 1rx, max 512
    musb_hdrc: hw_ep 2tx, max 512
    musb_hdrc: hw_ep 2rx, max 512
    musb_hdrc: hw_ep 3shared, max 256
    musb_hdrc: hw_ep 4shared, max 256
    musb_hdrc: USB Peripheral mode controller at c7860000 using DMA, IRQ 12
    musb_init_controller 2114: PERIPHERAL mode, status 0, dev98
    Registered /proc/driver/musb_hdrc
    mice: PS/2 mouse device common for all mice
    rtc_davinci_evm rtc_davinci_evm: rtc intf: proc
    rtc_davinci_evm rtc_davinci_evm: rtc intf: dev (254:0)
    rtc_davinci_evm rtc_davinci_evm: rtc core: registered rtc_davinci_evm as rtc0
    rtc0: hours 12-23 are misreported as duplicate hours 00-11
    davinci-mmc davinci-mmc.0: Supporting 4-bit mode
    davinci-mmc davinci-mmc.0: Using DMA mode
    Advanced Linux Sound Architecture Driver Version 1.0.12rc1 (Thu Jun 22 13:55:50 2006 UTC).
    ASoC version 0.13.1
    MUX: initialized MCBSP
    MUX: Setting register MCBSP
          PINMUX1 (0x01c40004) = 0x00000181 -> 0x00000581
    AIC23 Audio Codec 0.1
    i2c_davinci i2c_davinci.1: remote error
    ALSA device list:
      No soundcards found.
    IPv4 over IPv4 tunneling driver
    TCP bic registered
    NET: Registered protocol family 1
    NET: Registered protocol family 17
    Time: timer0_1 clocksource has been installed.
    Clock event device timer0_0 configured with caps set: 08
    Switched to high resolution mode on CPU 0
    davincifb davincifb.0: dm_osd0_fb: Initial window configuration is invalid.
    davincifb davincifb.0: dm_osd0_fb: 720x576x16@0,0 with framebuffer size 1620KB
    davincifb davincifb.0: dm_vid0_fb: 0x0x16@0,0 with framebuffer size 3672KB
    davincifb davincifb.0: dm_osd1_fb: Initial window configuration is invalid.
    davincifb davincifb.0: dm_osd1_fb: 720x576x4@0,0 with framebuffer size 1620KB
    davincifb davincifb.0: dm_vid1_fb: 0x0x16@0,0 with framebuffer size 3672KB
    rtc_davinci_evm rtc_davinci_evm: hctosys: invalid date/time
    IP-Config: Complete:
          device=eth0, addr=192.168.1.239, mask=255.255.255.0, gw=192.168.1.90,
         host=192.168.1.239, domain=, nis-domain=(none),
         bootserver=192.168.1.90, rootserver=192.168.1.90, rootpath=
    Looking up port of RPC 100003/2 on 192.168.1.90
    Looking up port of RPC 100005/1 on 192.168.1.90
    VFS: Mounted root (nfs filesystem).
    *****************************************************************************
    *                                                                           *
    *  REMINDER, the following debugging options are turned on in your .config: *
    *                                                                           *
    *        CONFIG_DEBUG_RT_MUTEXES                                             *
    *        CONFIG_DEBUG_PREEMPT                                               *
    *        CONFIG_DEBUG_SLAB                                                  *
    *        CONFIG_LOCKDEP                                                     *
    *                                                                           *
    *  they may increase runtime overhead and latencies.                        *
    *                                                                           *
    *****************************************************************************
    Freeing init memory: 172K
