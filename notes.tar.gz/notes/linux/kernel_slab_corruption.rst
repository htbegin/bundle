=====================
debug slab corruption
=====================

-------
causes
-------

* over-running the allocated memory - writing to address ahead of the end of the allocated memory
* under-running the allocated memory - writing to address before the start of the allocated memory
* using memory after freeing it

-----------------
check_poison_obj
-----------------

poison value
=============

* POISON_FREE 0xb6
* POISON_END 0xa5

inovocation
===========

slab_destroy_objs
-----------------
::

    > slab_destroy
    >> drain_freelist
    >>> __cache_shrink

    >>> cache_reap

    >>> cpuup_callback

    >> free_block
    >>> __drain_alien_cache

    >>> cache_free_alien

    >>> cpuup_callback

    >>> __do_drain

    >>> cache_flusharray

    >>> alloc_kmemlist

    >>> do_tune_cpucache

    >>> drain_array

cache_alloc_debugcheck_after
-----------------------------
::

    > __cache_alloc
    >> [kmem_cache_alloc]

    >> [kmem_cache_zalloc]

    >> __do_kmalloc
    >>> [__kmalloc]

    >>> [__kmalloc_track_caller]

    > [kmem_cache_alloc_node]
    >> [kmalloc_node]

    >> alloc_slabmgmt
    >>> cache_grow
    >>>> cache_alloc_refill

    >>>> __cache_alloc_node

