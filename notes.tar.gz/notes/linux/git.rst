===
git
===

config
======
git config --system core.quotepath false

git config --global user.name htbegin

git config --global user.email hotforest@gmail.com

git config color.ui never

alias
=====
git config --global alias.ci "commit"

git config --global alias.co "checkout"

fetch + merge
=============
git fetch /home/bob/repo master

fetch版本仓库/home/bob/repo的master分支

git log -p HEAD..FETCH_HEAD

查看fetch过来的remote branch的修改日志

show
====
git show dc5a460a1bfa:sound/soc/davinci/davinci-evm.c

显示指定修订版本号中的一个文件的内容

log
===
git log --since=yesterday

查看今天的修改日志

git log -n 1 --reverse

查看最旧的一个日志

push
====
在.git/config对应的remote段中添加：
push = +refs/heads/\*:refs/remotes/rt_110_bu/\*

运行git push将自动将本地的修改push到远程分支rt_110_bu。

unresolved
==========
在第一次提交时，如何使用git diff查看添加的内容(git diff --cached无效)

对过长的一行git diff不会换行

查看本地分支追踪的远程分支

