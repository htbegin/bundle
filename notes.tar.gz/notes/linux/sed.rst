===
sed
===

deletion
========

deletion the following lines
----------------------------
删除以import unittest开始的行，以及接下来的一行：

sed -i '/^import unittest/,+1d'
