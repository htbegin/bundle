================
System Rescue CD
================

----------------
update initramfs
----------------

Extract
=======
mkdir tempdir
cd tempdir
cat /path/to/initram.igz | /usr/bin/unlzma | cpio -id

Recreate
=========
cd tempdir
find . | cpio -H newc -o | /usr/bin/lzma -9 | > /path/to/initram.igz

