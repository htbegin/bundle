=============
USB Subsystem
=============

------------
Addressing
------------

Each addressable unit in a USB device is called an endpoint.
The address assigned to an endpoint is called an endpoint address.
Each endpoint address has an associated data transfer type.
If an endpoint is responsible for bulk data transfer, for example, it's called a bulk endpoint.

Endpoint address 0 is used exclusively for device configuration.
A control pipe is attached to this endpoint for device enumeration.

An endpoint can be associated with upstream or downstream data transfer.
Data arriving upstream from a device is called an IN transfer,
whereas data flowing downstream to a device is an OUT transfer.
IN and OUT transfers own separate address spaces.
So, you can have a bulk IN endpoint and a bulk OUT endpoint answering to the same address.

-------------------
USB Request Blocks
-------------------

USB Request Block (URB) is the centerpiece of the USB data transfer mechanism.

There are three steps to using a URB: create, populate, and submit.

To create a URB, use usb_alloc_urb().
This function allocates and zeros-out URB memory, initializes a kobject associated with the URB,
and initializes a spinlock to protect the URB.

To populate a URB, use the following helper routines offered by the USB core::

    void usb_fill_[control|int|bulk]_urb(
           struct urb *urb,              /* URB pointer */
           struct usb_device *usb_dev,   /* USB device structure */
           unsigned int pipe,            /* Pipe encoding */
           unsigned char *setup_packet,  /* For Control URBs only! */
           void *transfer_buffer,        /* Buffer for I/O */
           int buffer_length,            /* I/O buffer length */
           usb_complete_t completion_fn, /* Callback routine */
           void *context,                /* For use by completion_fn */
           int interval);                /* For Interrupt URBs only! */

These helper routines are available to control, interrupt, and bulk URBs but not to isochronous ones.

To submit a URB for data transfer, use usb_submit_urb(). URB submission is asynchronous.

usb_free_urb() is used to free a reference to a completed URB,
whereas usb_unlink_urb() cancels a pending URB operation.

The USB core also offers wrapper interfaces that provide a façade of synchronous URB submission::

    int usb_[control|interrupt|bulk]_msg(struct usb_device *usb_dev,
                                         unsigned int pipe, ...);

-------
Pipes
-------
A URB is associated with an abstraction called a pipe.

While referring to a URB, it's often qualified by the transfer type of the associated pipe.
If a URB is attached to a bulk pipe, for example, it's called a bulk URB.

A pipe is an integer encoding of a combination of the following:

* The endpoint address
* The direction of data transfer (IN or OUT)
* The type of data transfer (control, interrupt, bulk, or isochronous)

A pipe is the address element of each USB data transfer and is an important field in the URB structure.
To help populate this field, the USB core provides the following helper macros::

    usb_[rcv|snd][ctrl|int|bulk|isoc]pipe(struct usb_device *dev, unsigned int endpoint);

----------------------
Descriptor Structures
----------------------

The USB specification defines a series of descriptors to hold information about a device.
Descriptors are of four types:

 * Device descriptors contain general information such as the product ID and vendor ID of the device.
   usb_device_descriptor is the structure corresponding to device descriptors.
 * Configuration descriptors are used to describe different configuration modes such as bus-powered
   and self-powered operation.
   usb_config_descriptor is the data structure associated with configuration descriptors.
 * Interface descriptors allow USB devices to support multiple functions.
   usb_interface_descriptor defines interface descriptors.
 * Endpoint descriptors carry information associated with the final endpoints of a device.
   usb_endpoint_descriptor is the structure in question.

---------------
Gadget Drivers
---------------
The USB controller at the host side is called a host controller, and its driver
is HCD(Host Controller Driver). The correspond USB device driver is client driver.

The USB controller at the device side is variously called a device controller,
peripheral controller, client controller, or function controller.

The terms gadget and gadget driver are commonly used rather than
the heavily overloaded words device and device driver.

USB gadget support is now part of the mainline kernel and contains the following:

 * Drivers for USB device controllers integrated into SoC.
   These drivers additionally provide a gadget API that gadget drivers can use.
 * Gadget drivers for device classes such as storage, networking, and serial converters.
   These drivers answer to their class when they receive enumeration requests from host-side software.
 * A skeletal gadget driver, drivers/usb/gadget/zero.c.
   you may use it to test device controller drivers.
