============================================
Solution for Write Timeout in g_file_storage
============================================

--------------------
the Root of All Evil
--------------------
The write speed of SD card is too slow. It's about 70KB/s.

It leads to the timeout of a scsi command in host side when the kthread
file-storage-gadget needs to submit about 14499 pages to block layer
in client side.

It also leads to the timeout of restoration of the USB configuration and
the USB reconfiguration after logical disconnection.

-------
Details
-------
When the number of dirty pages equals with 12083 (118*1024/4*40/100),
the process starts to submit 14499 pages (118*1024/4*32/100*1.5) to
block device subsystem.

Submitting of the 14499 pages to block device subsystem spend about 76 seconds.

------------------
Host Side Solution
------------------
Update the /sys/block/sdX/device/timeout from 30 seconds to 80 seconds or more.

The sysfs file is used to set the timeout for scsi command request timeout.
When write this file, struct request_queue::rq_timeout is set.

The implementation is at drivers/scsi/scsi_sysfs.c file.

------------
Device Side
------------
Update sysfs files under directory /proc/sys/vm/.

If the setting could ensure that the process doesn't need to flush dirty pages itself,
the settting is valid. Because once the process needs to flush dirty pages itself,
it's sure that the write will be time-out.

The implementation is at mm/pdflush.c, fs/fs-writeback.c, mm/page-writeback.c and
kernel/sysctl.c.

dirty_ratio
============
It's a ratio to 100.

During the vfs_write of a process, if the dirty page of global system is greater than
the ratio, some dirty pages should be submitted to block device blockedly by the process.

If change dirty_ratio to a greater value, the time cames later on which the process
need to flush the dirty pages.

dirty_background_ratio
=======================
It's a ratio to 100.

During the vfs_write of a process, if the dirty page of global system is greater than
the ratio, some dirty pages should be submitted to block device subsystem non-blockedly
by the pdflush kthread.

If change dirty_background_ratio to a smaller value, the pdflush kthreads
used for background will start earlier.

The ratio of background write is about 48 pages/time, but the ratio
of dirty page is about 850 pages/time. So it's impossible to decrease dirty_background_ratio
to prevent the process from submitting dirty pages itself.

dirty_expire_centisecs
======================
The expire time of dirty page, its unit is 1/100 second.

When an pdflush kthread starts, it checks whether the dirty page has been marked as dirty
dirty_expire_centisecs ms ago, it will submit the dirty page non-blockedly if the dirty page
has been expired.

dirty_writeback_centisecs
=========================
The launch period of pdflush kthread, its unit is 1/100 second.

The ratio of flush of dirty page is almost the same with the ratio of background write.

