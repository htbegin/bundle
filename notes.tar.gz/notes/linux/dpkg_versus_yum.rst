===============
dpkg versus yum
===============

===========================  =======================================  =================================
action                       dpkg                                     yum
===========================  =======================================  =================================
update                       apt-get update && apt-get upgrade -y     yum makecache && yum update -y
install                      apt-get install pkg                      yum install pkg
remove                       apt-get install remove pkg               yum erase pkg
remove pkg+cfg               apt-get purge pkg                        None
get info                     dpkg -s pkg                              yum info pkg
provided files               dpkg -L pkg                              rpm -ql pkg
owner of file                dpkg -S pkg                              rpm -qf pkg
auto remove                  apt-get autoremove                       None
source of pkg                apt-get source pkg                       None
clean cache                  apt-get clean                            yum clean all
search pkg                   apt-cache search pattern                 yum search pattern
===========================  =======================================  =================================
