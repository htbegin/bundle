================================
disk operation related commands
================================

---------------
file as a disk
---------------

create file
============
::

    bash# dd bs=1M count=64 if=/dev/zero of=pseudo_disk
    64+0 records in
    64+0 records out

partition file
===============

heads, sectors, and cylinders
------------------------------
::

    bash# fdisk pseudo_disk
    Device contains neither a valid DOS partition table, nor Sun or SGI disklabel
    Building a new DOS disklabel. Changes will remain in memory only,
    until you decide to write them. After that, of course, the previous
    content won't be recoverable.

    You must set heads sectors and cylinders.
    You can do this from the extra functions menu.

    Command (m for help): x

    Expert command (m for help): s
    Number of sectors (1-63): 8
    Warning: setting sector offset for DOS compatiblity

    Expert command (m for help): h
    Number of heads (1-256): 16

    Expert command (m for help): c
    Number of cylinders (1-131071): 1024

    Expert command (m for help): r

create a partition
-------------------
::

    Command (m for help): n
    Command action
       e   extended
       p   primary partition (1-4)
    p
    Partition number (1-4): 1
    First cylinder (1-1024, default 1):
    Using default value 1
    Last cylinder or +size or +sizeM or +sizeK (1-1024, default 1024):
    Using default value 1024

    Command (m for help): t
    Partition number (1-4): 1
    Hex code (type L to list codes): b
    Changed system type of partition 1 to b (Win95 FAT32)

    Command (m for help): p

    Disk pseudo_disk: 16 heads, 8 sectors, 1024 cylinders
    Units = cylinders of 128 * 512 bytes

                      Device Boot    Start       End    Blocks   Id  System
    pseudo_disk1             1      1024     65532    b  Win95 FAT32

    Command (m for help): w
    The partition table has been altered!

    Calling ioctl() to re-read partition table.
    Syncing disks.

create a filesystem
--------------------
For this to work, you have to know what the partition's offset is.

If you followed the partitioning scheme given above then the offset will always be 4096.
If not, you can use fdisk to find the correct offset value:

::

    # fdisk -lu pseudo_disk
    You must set cylinders.
    You can do this from the extra functions menu.

    Disk data: 0 MB, 0 bytes
    16 heads, 8 sectors/track, 0 cylinders, total 0 sectors
    Units = sectors of 1 * 512 = 512 bytes

                       Device Boot      Start         End      Blocks   Id  System
     pseudo_disk1               8        8191        4092    b  Win95 FAT32

Ignore the bogus data at the top and concentrate on the table at the bottom.
The number you want is the value in the "Start" column.
It gives the offset in sectors;
to convert to bytes you must multiply by 512. So we see that the offset is 8 x 512 = 4096 bytes.
You use the losetup program to set up the loop device driver with the proper offset::

    # losetup -o 4096 /dev/loop0 pseudo_disk

Now /dev/loop0 is mapped to the partition within the backing storage.
You can create a filesystem on it::

    # mkfs.vfat /dev/loop0

and then you can mount it::

    # mount -t vfat /dev/loop0 /mnt/loop

Now you can transfer files back and forth to your heart's content!
When you're done, be sure to unmount and detach the loop device::

    # umount /dev/loop0
    # losetup -d /dev/loop0

