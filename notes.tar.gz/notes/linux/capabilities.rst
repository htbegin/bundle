=======================
Linux Capabilities
=======================

author: htbegin <hotforest@gmail.com>

date: 2011/05/04

Extended Attributes
===================
一个扩展属性是与文件或者目录相关联的一个name:value对。
属性名是由0结束的字符串，它的格式为namespace.attribute。现在使用的namespace包括security, system, trusted 和user。

使用扩展属性需要文件系统的支持。Linux下的ext2, ext3, ext4, XFS, JFS和reiserfs都提供了对扩展属性的支持。

security namespace
------------------
内核使用security.capability来存储能力信息。

更多信息
--------
使用man 5 attr查看更多信息。

Introducation
=============
从Linux Kernel 2.2开始，Linux将超级用户所拥有的特权划分为多个不同类别的单元，这些单元称之为能力。
每一种能力都可以单独的启用和禁用。能力是每一个线程都有的属性。

Implementation
==============
A full implementation of capabilities requires that:

1. For all priviledge operations, the kernel must check whether the thread has
   the required capability in its effective set.

2. The kernel must provide system calls allowing a thread's capability sets to be
   changed and retrieved.

3. The file system must support attaching capabilities to an executable file, so that
   a process gains those capabilities when the file is executed.

Before kernel 2.6.24, only the first two of these requirements are met;
since kernel 2.6.24, all three requirements are met.

Thread Capabilities Sets
========================
A  child created via fork(2) inherits copies of its parent's capability sets.

Using capset(2), a thread may manipulate its own capability sets.

Permitted
---------
This a a limiting superset for the effective capabilities that the thread may assume.
It is also a limiting superset for the capabilities that may be added to the inheritable set
by a thread that does not have the CAP_SETPCAP capabilities in its effective set.

If a thread drops a capability from its permitted set, it can never reacquire that
capability (unless it execve(2)s either a set-user-ID-root program, or a program
whose associated file capabilities grant that capability).

Inheritable
-----------
This is a set of capabilities preserved across an execve(2). It provides a mechanism for
a process to assign capabilities to the permitted set of the new program during an execve(2).

Effective
---------
This is the set of capabilities used by the kernel to perform permission checks for the thread.

File Capabilities
=================
Since kernel 2.6.24, the kernel supports associating capability sets with
an executable file using setcap(8).

The file capability sets are stored in an extended attribute named security.capability.
Writing to this extended attribute requires the CAP_SETFCAP capability.

The file capability sets, in conjunction with the capability sets of the thread,
determine the capabilities of a thread after an execve(2).

Permitted
---------
These capabilities are automatically permitted to the thread,
regardless of the thread's inheritable capabilities.

Inheritable
-----------
This set is ANDed with the thread's inheritable set to determine which inheritable capabilities
are enabled in the permitted set of the thread after the execve(2).

Effective
---------
This is not a set, but rather just a single bit. If this bit is set, then during an execve(2)
all of the new permitted capabilities for the thread are also raised in the effective set.
If this bit is not set, then after an execve(2), none of the new permitted capabilities is
in the new effective set.

Therefore, when assigning capabilities to a file, if we specify the effective flag
as being enabled for any capability, then the effective flag must also be specified
as enabled for all other capabilities for which the corresponding permitted or inheritable
flags is enabled.

Transformation of Capabilities During execve(2)
===============================================
During an execve(2), the kernel calculates the new capabilities of the process
using the following algorithm:

P'(permitted) = (P(inheritable) & F(inheritable)) | (F(permitted) & cap_bset)

P'(effective) = F(effective) ? P'(permitted) : 0

P'(inheritable) = P(inheritable) [i.e., unchanged]

where:

P denotes the value of a thread capability set before the execve(2)

P' denotes the value of a capability set after the execve(2)

F denotes a file capability set

cap_bset is the value of the capability bounding set

Capabilities and execution of programs by root
==============================================
In order to provide an all-powerful root using capability sets, during an execve(2):

1. If a set-user-ID-root program is being executed, or the real user ID of the process is 0 (root)
then the file inheritable and permitted sets are defined to be all ones (i.e., all capabilities
enabled).

2. If a set-user-ID-root program is being executed, then the file effective bit is defined to be
one (enabled).

The upshot of the above rules, combined with the capabilities transformations described above, is
that when a process execve(2)s a set-user-ID-root program, or when a process with an effective UID
of 0 execve(2)s a program, it gains all capabilities in its permitted and effective capability
sets (the effective capability is 0 when the real user ID of the process is 0),
except those masked out by the capability bounding set. This provides semantics that are the
same as those provided by traditional Unix systems.

Capabilities Bounding Set
=========================
The capability bounding set is a security mechanism that can be used to limit the capabilities
that can be gained during an execve(2).

The bounding set is used in the following ways:

* During an execve(2), the capability bounding set is ANDed with the file permitted capability set,
  and the result of this operation is assigned to the thread's permitted capability set. The capa‐
  bility bounding set thus places a limit on the permitted capabilities that may be granted by an
  executable file.

* (Since Linux 2.6.25) The capability bounding set acts as a limiting superset for the capabilities
  that a thread can add to its inheritable set using capset(2). This means that if a capability is
  not in the bounding set, then a thread can't add this capability to its inheritable set, even if
  it was in its permitted capabilities, and thereby cannot have this capability preserved in its
  permitted set when it execve(2)s a file that has the capability in its inheritable set.

Depending on the kernel version, the capability bounding set is either a system-wide attribute,
or a per-thread attribute.

From Linux 2.6.25, the capability bounding set is a per-thread attribute.

The bounding set is inherited at fork(2) from the thread's parent, and is preserved across an
execve(2).

A thread may remove capabilities from its capability bounding set using the prctl(2)
PR_CAPBSET_DROP operation, provided it has the CAP_SETPCAP capability.
Once a capability has been dropped from the bounding set, it cannot be restored to that set.
A thread can determine if a capability is in its bounding set
using the prctl(2) PR_CAPBSET_READ operation.

More Info
=========
man 7 capabilities

