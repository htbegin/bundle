=============
dsplink Oops
=============

----------
phonomenon
----------
* A SyncSemObject-typed object is free
* Access another object in this object
* Oops 0xc79ce038

-----------
stack dump
-----------
DRV_Ioctl

PMGR_MSGQ_get

LDRV_MSGQ_get

SYNC_WaitSEM

-------------
SYNC_WaitSEM
-------------
::

            DECLARE_WAITQUEUE (wait, current) ;
            /* Add the current process to wait queue */
            add_wait_queue_exclusive (&semObj->list, &wait) ;
            do {
                set_current_state (TASK_INTERRUPTIBLE) ;
                preempt_disable ();
                /* Oops here */
                if (semObj->value != 0) {
                    if (semObj->semType == SyncSemType_Binary) {
                        semObj->value = 0u ;
                        preempt_enable ();
                    }
                    else {
                        semObj->value-- ;
                        preempt_enable ();
                    }
                    break;
                }
                preempt_enable ();
                osStatus = schedule_timeout (MAX_SCHEDULE_TIMEOUT) ;
                /* Take the lock */
                if (osStatus == 0) { /* Timedout? */
                    status = DSP_ETIMEOUT ;
                    SET_FAILURE_REASON ;
                    break ;
                }
                if (osStatus == -ERESTARTSYS) { /* Interrupted? huh? */
                    status = -ERESTARTSYS ;
                    SET_FAILURE_REASON ;
                    break ;
                }
                if (signal_pending(current)) {
                    /* Restart the operation, we don't quit as
                     * application must do a clean exit
                     */
                    flush_signals(current);
                }
            } while (1);
            /* Remove from wait list */
            remove_wait_queue (&semObj->list, &wait) ;
            /* Set the current task status as running */
            set_current_state (TASK_RUNNING) ;


---------------
SYNC_SignalSEM
---------------

----------------------------------
SYNC_CreateSEM and SYNC_DeleteSEM
----------------------------------

SYNC_DeleteSEM
==============

LDRV_MSGQ_close
----------------

LDRV_MSGQ_open
++++++++++++++

PMGR_MSGQ_close
+++++++++++++++

DRV_CallAPI
~~~~~~~~~~~~
DRV_Ioctl

CMD_MSGQ_CLOSE
***************

CMD_PROC_CLEANUP
*****************
DSPLINK_atExitHandler

    DSPLINK_sigHandler
        DRV_Invoke
            PROC_setup
                startupDSP
                    main (process)
                procCreate
                    daemon (pthread)
                        Processor_init

    atexit(&DSPLINK_atExitHandler)

ZCPYMQT_locate
--------------

DCPYMQT_locate
--------------

UEVENT_AddNewProcess
--------------------

UEVENT_RemoveUserProcess
-------------------------

-----------
How to Fix
-----------
DRV_Open and DRV_Release do nothing.

Who new, and he delete.

PMGR_MSGQ_close --> DRV_CallAPI (CMD_MSGQ_CLOSE) --> MSGQ_close --> Comm_delete
PMGR_MSGQ_open --> DRV_CallAPI (CMD_MSGQ_OPEN) --> MSGQ_open --> Comm_create

