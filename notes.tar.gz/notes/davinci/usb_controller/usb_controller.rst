=====================================================
Davinci DM644x Universal Serial Bus (USB) Controller
=====================================================

-------------
introducation
-------------
The controller supports high-speed USB peripheral mode and high-speed limited host-mode operations.
On-The-Go (OTG) capability are not supported on the DM644x devices.

The USB controller can be operated by ARM through the memory-mapped registers.

The USB controller supports data throughput rates up to 480 Mbps.

Features Supported
===================
• Supports USB 2.0 peripheral [#]_ at High Speed (480 Mbps) and Full Speed (12 Mbps)
• Supports USB 2.0 host [#]_ at High Speed (480 Mbps), Full Speed (12 Mbps), and Low Speed (1.5 Mbps)
• Supports four simultaneous RX and TX endpoints, more can be supported by dynamically switching
• Each endpoint can support all transfer types (control, bulk, interrupt, and isochronous)
• Includes a 4K endpoint FIFO RAM, and supports programmable FIFO sizes
• External 5V power supply for VBUS can be controlled through I2C
• Includes a DMA controller that supports four TX and four RX DMA channels
• Supports USB extensions for Session Request (SRP) and Host Negotiation (HNP)
• Includes RNDIS mode of DMA for accelerating RNDIS type protocols
  using short packet termination over USB

Features Not Supported
=======================
• High Bandwidth Isochronous Transfer.
• High Bandwidth Interrupt Transfer.
• Automatic Amalgamation [#]_ of Bulk Packets
  (CPPI DMA will indirectly handle this feature and is not supported at the core level).
• Automatic Splitting of Bulk Packets
  (CPPI DMA will indirectly handle this feature and is not supported at the core level).

Functional Block Diagram
=========================
.. image:: images/block_diagram.png


.. [#] the usb controller as a peripheral.
.. [#] the usb controller as a host.
.. [#] amalgamation  [əˌmælgəˈmeiʃən] 合并

-----------------------
Peripheral Architecture
-----------------------

Clock Control
=============
Clocks for USB are generated based on a crystal oscillator on the M24XI and M24XO pins.

The oscillator is enabled by bit OSCPDWN of the USBPHY_CTL register in the system module.

.. image:: images/system_control_module_registers.png
.. image:: images/usbphy_ctl_register.png

Signal Descriptions
====================
The USB controller provides the following I/O signals.

.. image:: images/usb_pins.png

USB_VBUS
--------
5V input that signifies that **VBUS** is connected.

USB_ID
-------
USB operating mode identification pin.

For Host mode operation, pull down this pin to ground (V\ :sub:`SS`) via an external 1.5-kΩ resistor.

For Device mode operation, pull up this pin to DV\ :sub:`DD33` rail via an external 1.5-kΩ resistor.

USB_DP and USB_DM
------------------
USB_DP (D+) and USB_DM (D-) are USB bi-directional Data Differential signal pair.

Indexed and Non-Indexed Registers
=================================
USB controller provides two mechanism of accessing the endpoint control and status registers:

• Indexed Endpoint Control/Status Registers – These registers are memory-mapped
  at offset 410h to 41Fh.
  The endpoint is selected by programming the INDEX register of the controller.
• Non-indexed Endpoint Control/Status Registers – These registers are memory-mapped
  at offset 500h to 54Fh.
  Registers at offset 500h-50Fh map to Endpoint 0; offset 510h-51Fh map to Endpoint 1, and so on.

The base address of the USB controller register is 01C6-4000h.

USB PHY Initialization
======================
The USB PHY and its interface to the USB controller, UTMI Interface, and interface to the bus require a
low jitter clock, sourced external to the device, for PHY operation.

The input clock frequency can either be 12 MHz or 24 MHz. The PLL within the PHY is used to generate
the clock required for the UTMI interface and for the bit clock. The clock frequency supplied is selected
using the System Module USBPHY_CTL.CLK01SEL bit (0 = 24 MHz; 1 = 12 MHz).

This clock source can either be an oscillator or a crystal.
If using an oscillator, you are advised to disable the internal oscillator.
If using a crystal, you are required to enable the internal oscillator.
The oscillator control is handled using the USBPHY_CTL.OSCPDWN bit
(0 = internal oscillator is powered; 1 = internal oscillator is disabled).

The PLL state is controlled using the USBPHY_CTL.PHYPLLON bit (0 = PLL is enabled; 1 = PLL is disabled).
The PHY control is handled using the USBPHY_CTL.PHYPDWN bit (0 = powered on; 1 = powered off).
Once the PHY is supplied with the desired input clock source and is powered up
(USBPHY_CTL.PHYPDWN = 0), the firmware should wait until the PLL locks prior to usage.
The PLL lock status is communicated to you using the USBPHY_CTL.PHYCLKGD status bit
(0 = PLL is not locked; 1 = PLL is locked).

In addition to providing the input clock, you are also responsible for enabling the voltage comparators
within the PHY. The OTG controller expects to observe different levels of voltages depending upon the
role it assumes and its operation state. Voltage comparators within the PHY exist to identify the voltage
level on the VBUS line and communicate the level to the USB controller. The voltage comparators status
is communicated using the USBPHY_CTL.VBDTCTEN and USBPHY_CTL_SESNDEN bits
(0 = comparator is disabled; 1 = comparator is enabled).

Dynamic FIFO Sizing
====================
The USB controller supports a total of 4K RAM to dynamically allocate FIFO to endpoint 1 to 4.
Endpoint 0 FIFO has a fixed size (64 bytes) and a fixed location (start address 0).

The allocation of FIFO space to the different endpoints requires the specification
for each Tx and Rx endpoint of:

• The start address of the FIFO within the RAM block
• The maximum size of packet to be supported
• Whether double-buffering is required.

These details are specified through four registers, which are added to the indexed area of the memory
map. That is, the registers for the desired endpoint are accessed after programming the INDEX register
with the desired endpoint value. These four registers are: TXFIFOSZ, RXFIFOSZ, TXFIFOADDR, RXFIFOADDR.

.. Note:: It is the responsibility of the firmware to ensure that all the Tx and Rx endpoints
   that are active in the current USB configuration have a block of RAM assigned exclusively
   to that endpoint that is at least as large as the maximum packet size set for that endpoint.

-----------------------------------
Host and Peripheral Modes Operation
-----------------------------------

Working Mode
============
It can be used as either a high-speed or a full-speed USB peripheral device attached to
a conventional USB host (such as a PC).

*It can be used as either host or peripheral device in point-to-point data transfers with
another peripheral device - or, if the other device also contains a Dual-Role Controller,
the two devices can switch roles as required.* [#]_

It can be used as the host to a range of such peripheral devices in a multi-point setup. [#]_

Whether the controller expects to behave as a host or as a peripheral device depends on
the way the devices are cabled together. Each USB cable has an A end and a B end.
If the A end of the cable is plugged into the controller, it will take the role of
the Host device and go into host mode.
If the B end of the cable is plugged in, the controller will go instead into peripheral mode.

.. [#] (On-The-Go) OTG capability ?
.. [#] what does "a multi-point setup" mean ?

Peripheral Mode Operation
=========================

Soft connect
------------

Entry into suspend mode
-----------------------

Resume Signaling
----------------

Initiating a remote wakeup
--------------------------

Reset Signaling
---------------

Control Transcations
--------------------
Endpoint 0 is the main control endpoint of the core.
The software is required to handle all the standard device requests that may be sent or received
via endpoint 0. These are described in Universal Serial Bus Specification, Revision 2.0, Chapter 9.

The Standard Device Requests received by a USB peripheral device can be divided into three categories:

. Zero Data Requests (in which all the information is included in the command)
. Write Requests (in which the command will be followed by additional data)
. Read Requests (in which the device is required to send data back to the host)

Zero Data Requests
~~~~~~~~~~~~~~~~~~
Zero data requests have all their information included in the 8-byte command and
require no additional data to be transferred.

Examples of Zero Data standard device requests are:
* SET_FEATURE
* CLEAR_FEATURE
* SET_ADDRESS
* SET_CONFIGURATION
* SET_INTERFACE

The sequence of events will begin, as with all requests, when the software receives an endpoint 0
interrupt. The 8-byte command should then be read from the endpoint 0 FIFO, decoded and the
appropriate action taken.

When the host moves to the status stage [#]_ of the request, a second endpoint 0 interrupt
will be generated to indicate that the request has completed.
No further action is required from the software.
The second interrupt is just a confirmation that the request completed successfully.

.. [#] what about the other stages fo the request ?

.. Note:: DMA is not supported for endpoint 0, so the command should be read by accessing the
   endpoint 0 FIFO register.

Write Requests
~~~~~~~~~~~~~~~
Write requests involve an additional packet (or packets) of data being sent
from the host after the 8-byte command.

An example of a Write standard device request is: SET_DESCRIPTOR.

Read Requests
~~~~~~~~~~~~~
Read requests have a packet (or packets) of data sent
from the function to the host after the 8-byte command.

Examples of Read Standard Device Requests are:
* GET_CONFIGURATION
* GET_INTERFACE
* GET_DESCRIPTOR
* GET_STATUS
* SYNCH_FRAME

Endpoint 0 States
~~~~~~~~~~~~~~~~~~
When the USB controller is operating as a peripheral device, the endpoint 0 control
needs three modes: IDLE, TX and RX -- corresponding to the different phases of
the control transfer and the states endpoint 0 enters for the different phases of the transfer.

The default mode on power-up or reset should be IDLE.
RXPKTRDY bit of PERI_CSR0 (bit 0) becoming set when endpoint 0 is in IDLE state
indicates a new device request.

Once the device request is unloaded from the FIFO, the controller decodes the descriptor
to find whether there is a data phase.
Depending on the direction of the data phase, endpoint 0 goes into either TX state or RX state.
If there is no Data phase, endpoint 0 remains in IDLE state to accept the next device request.

.. image:: images/ep0_control_cpu_actions_1.png

.. image:: images/ep0_control_cpu_actions_2.png

Interrupt Handling
==================
The USB controller interrupts the ARM on completion of the data transfer on any of the endpoints or
on detecting reset, resume, suspend, connect, disconnect, or SOF on the bus.

When the ARM is interrupted with a USB interrupt, it needs to read the interrupt status register to
determine the endpoints that have caused the interrupt and jump to the appropriate routine.
If multiple endpoints have caused the interrupt, endpoint 0 should be serviced first,
followed by the other endpoints. The suspend interrupt should be serviced last.

---------------
speed statistic
---------------

======  =======  =======  =======  =======  ==================
date    s_time   e_time   s_page   e_page   speed (page/hour)
======  =======  =======  =======  =======  ==================
05.22   16:27    17:59    014      023      6.5
05.22   19:50    21:39    024      027      2.2
======  =======  =======  =======  =======  ==================

-------
revison
-------

=======  ==========  ===============================  ================
version  date        author                           note
=======  ==========  ===============================  ================
0.1      2011-05-22  htbegin <hotforest@gmail.com>    initial version
=======  ==========  ===============================  ================
