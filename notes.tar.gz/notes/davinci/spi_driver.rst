=========================
Davinci SPI Master Driver
=========================

important struct
================

struct davinci_spi_platform_data
--------------------------------
code::

    /**
     * davinci_spi_platform_data - Platform data for SPI master device on DaVinci
     *
     * @version:	version of the SPI IP. Different DaVinci devices have slightly
     *		varying versions of the same IP.
     * @num_chipselect: number of chipselects supported by this SPI master
     * @intr_line:	interrupt line used to connect the SPI IP to the ARM interrupt
     *		controller withn the SoC. Possible values are 0 and 1.
     * @chip_sel:	list of GPIOs which can act as chip-selects for the SPI.
     *		SPI_INTERN_CS denotes internal SPI chip-select. Not necessary
     *		to populate if all chip-selects are internal.
     * @cshold_bug:	set this to true if the SPI controller on your chip requires
     *		a write to CSHOLD bit in between transfers (like in DM355).
     * @dma_event_q: DMA event queue to use if SPI_IO_TYPE_DMA is used for any
     *		device on the bus.
     */
    struct davinci_spi_platform_data {
        u8			version;
        u8			num_chipselect;
        u8			intr_line;
        u8			*chip_sel;
        bool			cshold_bug;
        enum dma_event_q	dma_event_q;
    };

struct davinci_spi_config
-------------------------
code::


    /**
     * davinci_spi_config - Per-chip-select configuration for SPI slave devices
     *
     * @wdelay:	amount of delay between transmissions. Measured in number of
     *		SPI module clocks.
     * @odd_parity:	polarity of parity flag at the end of transmit data stream.
     *		0 - odd parity, 1 - even parity.
     * @parity_enable: enable transmission of parity at end of each transmit
     *		data stream.
     * @io_type:	type of IO transfer. Choose between polled, interrupt and DMA.
     * @timer_disable: disable chip-select timers (setup and hold)
     * @c2tdelay:	chip-select setup time. Measured in number of SPI module clocks.
     * @t2cdelay:	chip-select hold time. Measured in number of SPI module clocks.
     * @t2edelay:	transmit data finished to SPI ENAn pin inactive time. Measured
     *		in number of SPI clocks.
     * @c2edelay:	chip-select active to SPI ENAn signal active time. Measured in
     *		number of SPI clocks.
     */
    struct davinci_spi_config {
        u8	wdelay;
        u8	odd_parity;
        u8	parity_enable;
    #define SPI_IO_TYPE_INTR 0
    #define SPI_IO_TYPE_POLL 1
    #define SPI_IO_TYPE_DMA  2
        u8	io_type;
        u8	timer_disable;
        u8	c2tdelay;
        u8	t2cdelay;
        u8	t2edelay;
        u8	c2edelay;
    };

struct davinci_spi_dma
----------------------
code::

    /* We have 2 DMA channels per CS, one for RX and one for TX */
    struct davinci_spi_dma {
        int			tx_channel;
        int			rx_channel;
        int			dummy_param_slot;
        enum dma_event_q	eventq;
    };

struct davinci_spi
------------------
code::

    /* SPI Controller driver's private data. */
    struct davinci_spi {
        struct spi_bitbang	bitbang;
        struct clk		*clk;

        u8			version;
        /* physical address, used by DMA */
        resource_size_t		pbase;
        /* virtual address */
        void __iomem		*base;
        u32			irq;
        struct completion	done;

        const void		*tx;
        void			*rx;
    #define SPI_TMP_BUFSZ	(SMP_CACHE_BYTES + 1)
        u8			rx_tmp_buf[SPI_TMP_BUFSZ];
        int			rcount;
        int			wcount;
        struct davinci_spi_dma	dma;
        struct davinci_spi_platform_data *pdata;

        void			(*get_rx)(u32 rx_data, struct davinci_spi *);
        u32			(*get_tx)(struct davinci_spi *);

        u8			bytes_per_word[SPI_MAX_CHIPSELECT];
    };

important function
==================

davinci_spi_setup
-----------------
master->setup = davinci_spi_setup

davinci_spi_chipselect
----------------------
dspi->bitbang.chipselect = davinci_spi_chipselect

davinci_spi_setup_transfer
--------------------------
dspi->bitbang.setup_transfer = davinci_spi_setup_transfer

davinci_spi_bufs
----------------
dspi->bitbang.txrx_bufs = davinci_spi_bufs

davinci_spi_irq
---------------
code::

    request_irq(dspi->irq, davinci_spi_irq, 0, dev_name(&pdev->dev), dspi);

EDMA
----
dspi->dma.eventq
dspi->dma.rx_channel
dspi->dma.tx_channel
dspi->dma.dummy_param_slot

davinci_spi_request_dma
davinci_spi_dma_callback

edma_alloc_channel (RX and TX)
edma_free_channel
edma_alloc_slot (only TX)
edma_free_slot
edma_link
edma_write_slot
edma_start
edma_stop

dmap_map_single
dmap_unmap_single

davinci_spi_bufs
~~~~~~~~~~~~~~~~

SPIDAT1
~~~~~~~
re-write CSHOLD bit if the cshold bug exists.

SPIINT
~~~~~~
after the completion of dma cfg, enable DMA.

after the completion of dma transmit and receive, disable DMA

davinci_spi_rx|tx_buf_u8|u16
----------------------------
dspi->get_rx = davinci_spi_rx_buf_u8|u16
dspi->get_tx = davinci_spi_tx_buf_u8|u16

spi cfg sequence
================

davinci_spi_probe
-----------------

SPIGCR0
~~~~~~~
reset and out-of-reset

SPIPC0
~~~~~~
enable DI, DO and CLK pin function

SPILVL
~~~~~~
use SPIINT0 or SPIINT1 for receive/receive overrun/transmit bit error interrupt.

SPIDEF
~~~~~~
set to the default values: SPI_EN[0|1] is driven to logic 1 when
no transaction is in progress.

SPIGCR1
~~~~~~~
enable SPI clock mode and master mode.
power down SPI module.

davinci_spi_setup
-----------------

SPIPC0
~~~~~~
enable chip select pin function

SPIGCR1
~~~~~~~
enable/disable loopback mode.

davinci_spi_setup_transfer
--------------------------

SPIFMT0
~~~~~~~
set prescale, bpp, lsb/msb first mode, clock polarity, clock phase.

davinci_spi_chipselect
----------------------

SPIDAT1
~~~~~~~
enable chip select 0 or 1, select data format 0, and disable cs hold mode.

davinci_spi_bufs
----------------

SPIGCR1
~~~~~~~
before read/write, power up SPI and activate SPI module.
after read/write, deactivate SPI module and power down SPI.

SPIINT
~~~~~~

after read/write, disable all interrupts and disable EDMA request.

interrupt mode
++++++++++++++
before read/write, enable all interrupts: receive interrupt,
receive overrun interrupt, transmit bit erorr interrupt.

SPIDAT1
~~~~~~~

poll mode
+++++++++
read the cfg and write a word.

interrupt mode
++++++++++++++
read the cfg and write the first word.

SPIBUF
~~~~~~

poll mode
+++++++++
check whether data has been received. If new data is arrived, then read a word.

check whether transmit data buffer is full. If it is empty, then write a word.

SPIFLG
~~~~~~

poll mode
+++++++++
check whether receive overrun and transmit bit-error have occured.

davinci_spi_irq
---------------

SPIBUF
~~~~~~
read the data if needed and there is available new data.

check whether the transmit data buffer is full.

SPIFLG
~~~~~~
check for transmit bit error and receive overrun error.

SPIDAT1
~~~~~~~
write the data if needed and the transmit data buffer is empty.

SPIINT
~~~~~~
if there is any error during read/write, all interrupts are disabled.

question
========

dspi->rcount/dspi->wcount
-------------------------
code::

	/* convert len to words based on bits_per_word */
	data_type = dspi->bytes_per_word[spi->chip_select];

	dspi->tx = t->tx_buf;
	dspi->rx = t->rx_buf;
	dspi->wcount = t->len / data_type;
	dspi->rcount = dspi->wcount;

the read only condition is permitted. because the write is necessary to
keep the serial clock going on.

the write only condition is not permitted.

write the first word
--------------------
why not check the TXFULL bit SPIBUF register when write the first word ?

Is it sure that the TXFULL bit is 0 after writing the last word in the former transmission ?

Is it possible that there is some data in SPIBUF bit in SPIBUF register before the first write ?

davinci_spi_remove
------------------
it doesn't free the allocated EDMA tx/rx channel and EDMA slot.

the master whose type is struct spi_master also not be freed.
