===========
davinci spi
===========

author: htbegin <hotforest@gmail.com>

introducation
=============
The SPI is a high-speed synchronous serial input/output port that allows
a serial bit stream of programmed length (1 to 16 bits) to be shifted
into and out of the device at a programmed bit-transfer rate.

The SPI is normally used for communication between the TMS320DM644x DMSoC
and external peripherals.
Typical applications include an interface to external I/O or peripheral expansion
via devices such as shift registers, display drivers, SPI EPROMs and
analog-to-digital converters.

block diagram
=============

feature
-------

* 16-bit shift register
* Receive buffer register
* 8-bit clock prescaler
* Programmable SPI clock frequency range
* Programmable character length (2 to 16 bits)
* Programmable clock phase (delay or no delay)
* Programmable clock polarity (high or low)
* Two chip select signals (SPI_EN0 and SPI_EN1) provide the ability to control two slave devices

terminal
--------
pins of SPI all default to GPIO pins when not enabled.

Set PINMUX1.SPI to "1" and PINMUX0.HDIREN to enable all SPI bins.

===========  ==================================
signal name  description
===========  ==================================
SPI_EN0      output, SPI slave device 0 enable
SPI_EN1      output, SPI slave device 1 enable
SPI_CLK      output, SPI clock
SPI_DO       output, SPI data
SPI_DI       input, SPI data
===========  ==================================

revison
=======

=======  ==========  =======  ==============================
version  date        author   note
=======  ==========  =======  ==============================
0.1      2010-12-11  htbegin  initial version
=======  ==========  =======  ==============================
