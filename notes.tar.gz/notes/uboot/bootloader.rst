======
U-Boot
======
------------------------------------
Embedded Bootloader and U-Boot
------------------------------------

author: htbegin <hotforest@gmail.com>

date: 2011/04/09

Embedded Bootloader
===================

Desktop versus Embedded
-----------------------

*Desktop Linux Boot Sequence*
    BIOS -> GRUB -> Linux Kernel -> Application

*Embedded Linux Boot Sequence*
    [RBL -> UBL -> U-Boot] -> Linux Kernel -> Application

Functionalities
---------------
主要功能是获取和启动内核。

在此之前还需要完成基本的CPU和硬件平台的初始化。
硬件平台的初始化中比较重要的有：SDRAM控制器的配置。

在SDRAM控制器初始化之前，Bootloader是在On-Chip RAM中运行，
在SDRAM控制器初始化完成后，再将自己移到SDRAM中去。

Code::

    /* cpu/arm926ejs/start.S */
    relocate:				/* relocate U-Boot to RAM	    */
        adr	r0, _start		/* r0 <- current position of code   */
        ldr	r1, _TEXT_BASE		/* test if we run from flash or RAM */
        cmp     r0, r1                  /* don't reloc during debug         */
        beq     stack_setup

        ldr	r2, _armboot_start
        ldr	r3, _bss_start
        sub	r2, r3, r2		/* r2 <- size of armboot            */
        add	r2, r0, r2		/* r2 <- source end address         */

    copy_loop:
        ldmia	r0!, {r3-r10}		/* copy from source address [r0]    */
        stmia	r1!, {r3-r10}		/* copy to   target address [r1]    */
        cmp	r0, r2			/* until source end addreee [r2]    */
        ble	copy_loop

Using the U-Boot Bootloader
===========================

Build
-----
首先配置U-Boot：make davinci_config，与该配置对应的文件为include/configs/davinci.h。

然后是构建：make ARCH=arm CROSS_COMPILE=arm_vt5_le- u-boot.bin。

首先生成的是 **ELF** 格式的u-boot，然后使用arm_v5t_le-objcopy生成 **binary** 格式的u-boot.bin。

Install
-------
如果开发板上已经运行有U-Boot，那么可以使用U-Boot Shell下的命令来更新U-Boot。

如果没有U-Boot，则需要使用硬件的编程设备来安装U-Boot。

在Davinci DM6446下可以通过串口来安装U-Boot。
首先让Davinci从串口启动，然后通过串口将U-Boot复制到内存中运行，最后通过在内存中运行的
U-Boot来将另一个U-Boot安装到Flash中。

U-Boot Environment Variables
----------------------------
使用环境变量的名称来引用该环境变量的值。

显示环境变量
~~~~~~~~~~~~
printenv

新建/修改
~~~~~~~~~
setenv

Example::

    setenv bootargs rootfstype=jffs2 root=/dev/mtdblock4 console=ttyS0,115200

引用
~~~~
使用$var或者${var}来引用已定义的环境变量。

setenv splashimage 'nand read.e $splash_addr splash $splash_size; \


mkimage Script
--------------

Write Kernel to Flash
---------------------

Updating U-Boot
---------------

U-Boot Internal
===============

Building Internal
-----------------

Board Related Cfg
-----------------

Memory Map
----------

Source Code Layout
------------------

from Zero to U-Boot Shell
-------------------------

No Embedded Bootloader
======================

