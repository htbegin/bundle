#include <stdio.h>
#include <string.h>

==============
bit field in c
==============

---------
example A
---------
::

    struct all_in_one {
        unsigned char type : 2;
        unsigned char flags : 6;
        unsigned char state;
    };

**sizeof(all_in_one)** is 2 bytes.

if set the first byte to 0x5A, then **type** will be 2 (0x5A & ((1 << 2) - 1)),
**flags** will be 22 (0x5A >> 2)

---------
example B
---------
::

    struct one_by_one {
        unsigned char type : 2;
        unsigned char flags : 7;
        unsigned char state;
    };

**sizeof(one_by_one)** is 3 bytes.

if set the first byte to 0x5A, the others bytes to 0,
then **type** will be 2 (0x5A & ((1 << 2) - 1)), **flags** will be 0.

if set the first byte to 0x5A, the sec bytes to 0x5A,
then **type** will be 2 (0x5A & ((1 << 2) - 1)), **flags** will be 90 (0x5A & ((1 << 7) - 1)).

----
code
----
::

    #include <stdio.h>
    #include <string.h>

    struct all_in_one {
        unsigned char type : 2;
        unsigned char flags : 6;
        unsigned char state;
    };

    struct one_by_one {
        unsigned char type : 2;
        unsigned char flags : 7;
        unsigned char state;
    };

    int main()
    {
        struct all_in_one f_obj = {0};

        memset(&f_obj, 0x5A, sizeof(struct all_in_one));
        printf("size of %s is %d\n", "all_in_one", sizeof(struct all_in_one));
        printf("type: %d, flags: %d\n", f_obj.type, f_obj.flags);

        struct one_by_one s_obj = {0};

        printf("size of %s is %d\n", "one_by_one", sizeof(struct one_by_one));

        memset(&s_obj, 0x5A, 1);
        printf("type: %d, flags: %d\n", s_obj.type, s_obj.flags);

        memset(&s_obj, 0x5A, sizeof(struct one_by_one));
        printf("type: %d, flags: %d\n", s_obj.type, s_obj.flags);

        return 0;
    }

