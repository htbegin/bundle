==========
const in c
==========

----
rule
----
\* 左边的const用于修饰这种指针所指向的类型。
\* 右边的const用于修饰这种指针类型。

-------
example
-------
::

    #include <stdio.h>

    int main(int argc, char **argv)
    {
        char a = 'a';
        /* OR char const *a_ptr */
        const char *a_ptr = &a;
        /* error: assignment of read-only location '*a_ptr' */
        *a_ptr = 'a';

        char b = 'b';
        char * const b_ptr = &b;
        /* error: assignment of read-only variable 'b_ptr' */
        b_ptr = NULL;

        char c = 'c';
        const char *c_ptr = &c;
        /* OR const char **c_ptr_ptr = &c_ptr;
        const char **c_ptr_ptr = &c_ptr;

        /* error: assignment of read-only location '**c_ptr_ptr' */
        **c_ptr_ptr = 'c';

        char d = 'd';
        char * const d_ptr = &d;
        char * const *d_ptr_ptr = &d_ptr;

        /* error: assignment of read-only location ‘*d_ptr_ptr */
        *d_ptr_ptr = NULL;

        char e = 'e';
        char * const e_ptr = &e;
        char ** const e_ptr_ptr = &e_ptr;

        /* error: assignment of read-only location ‘e_ptr_ptr */
        e_ptr_ptr = NULL;

        return 0;
    }


