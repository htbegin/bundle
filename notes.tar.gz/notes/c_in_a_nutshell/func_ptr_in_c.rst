=====================
function pointer in c
=====================

--------
examples
--------

a function pointer
==================
int (\*cb)(void \*ctx);

or

typedef int (\*cb_func)(void \*ctx);

cb_func cb;

an array of function pointer
============================
int (\*cb[10])(void \*ctx);

or

typedef int (\*cb_func)(void \*ctx);

cb_func cb[10];

an array of pointer to function pointer
=======================================
int (\**cb[10])(void \*ctx);

or

typedef int (\*cb_func)(void \*ctx);

cb_func \*cb[10];

a pointer to an array of function pointer
=========================================
int (\*(\*cb)[10])(void \*ctx);
or

typedef int (\*cb_func)(void \*ctx);

cb_func (\*cb)[10];

-----------------------------------
with typedef versus without typedef
-----------------------------------

with typedef
============
typedef void (\*sighandler_t)(int);

sighandler_t signal(int signum, sighandler_t handler);

without typedef
===============
void (\*signal(int signum, void (\*handler)(int signum)))(int signum);

----
code
----
::

    #include <stdio.h>

    static int func(int input)
    {
        return input;
    }

    typedef int (*func_ptr)(int input);

    int main()
    {
        int (*array_one[10])(int input);
        func_ptr array_two[10];

        int (**ptr_one)(int input);
        func_ptr *ptr_two;

        array_one[0] = func;
        ptr_one = &array_one[0];
        array_two[0] = func;
        ptr_two = &array_two[0];

        printf("array_one: %d\n", array_one[0](10));
        printf("ptr_one: %d\n", (*ptr_one)(10));
        printf("array_two: %d\n", array_two[0](10));
        printf("ptr_two: %d\n", (*ptr_two)(10));

        int (**ptr_array_one[10])(int input);
        func_ptr *ptr_array_two[10];

        ptr_array_one[0] = ptr_one;
        ptr_array_two[0] = ptr_two;

        printf("ptr_array_one: %d\n", (*ptr_array_one[0])(10));
        printf("ptr_array_two: %d\n", (*ptr_array_two[0])(10));

        int (*(*array_ptr_one)[10])(int input) = &array_one;
        func_ptr (*array_ptr_two)[10] = &array_two;

        printf("array_ptr_one: %d\n", (*array_ptr_one)[0](10));
        printf("array_ptr_two: %d\n", (*array_ptr_two)[0](10));

        return 0;
    }

